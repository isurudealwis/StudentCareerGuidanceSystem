<?php
class HigherStudiesController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('HigherStudiesModel');
    }
    
    //Student-Subject Page Functions
    public function HigherStudies() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {   
        //load table
            $dbresult['data']=$this->HigherStudiesModel->FetchData();
            $this->load->view('navbar');
            $this->load->view('HigherStudiesPage',$dbresult);

        //clear button
            if ($this->input->post('clear')) {
                $_SESSION['keyword']="";
                $_SESSION['column'] ="";
                redirect('HigherStudiesController/HigherStudies');
            }

        //Find Button
            else if ($this->input->post('find')) {
                $_SESSION['keyword'] = $this->input->post('keyword');
                $_SESSION['column'] = $this->input->post('column');
                redirect('HigherStudiesController/HigherStudies');
            }

        //Insert Record Button
            else if($this->input->post('insert')) {
                redirect('HigherStudiesController/insert');
            }

            //Back Button
            else if ($this->input->post('back')) {
                redirect('HigherStudiesController/HigherStudies');
            }
        }
    }

    //Insert Record
    public function insert() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {   
            $data['id'] = $this->HigherStudiesModel->newid();
            $data['mulintlist'] = $this->HigherStudiesModel->getmulintlist();
            $this->load->view('navbar');
            $this->load->view('HigherStudiesInsert',$data);

        //If 'Insert' button is pressed...
            if($this->input->post('save')) {
                $id = $this->input->post('HighStd_ID');
                $name = $this->input->post('HighStd_Name');
                $desc = $this->input->post('HighStd_Desc');
                $mulint = $this->input->post('MulInt_ID');

                $result=$this->HigherStudiesModel->insert($id, $name, $desc, $mulint);

                echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";          
            }
        }
    }


    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {   
            $id = $this->input->get('HighStd_ID');
            $data['record'] = $this->HigherStudiesModel->getrecord($id);
            $data['mulintlist'] = $this->HigherStudiesModel->getmulintlist();
            $this->load->view('navbar');
            $this->load->view('HigherStudiesUpdate',$data);

        //If 'Update' button is pressed...
            if($this->input->post('update')) {
                $id = $this->input->post('HighStd_ID');
                $name = $this->input->post('HighStd_Name');
                $desc = $this->input->post('HighStd_Desc');
                $mulint = $this->input->post('MulInt_ID');

                $result = $this->HigherStudiesModel->update($id,$name,$desc, $mulint);

                echo "<script language='javascript'>alert(\"$result\");location=\"HigherStudies\"</script>";
        }
    }
    }

    public function delete() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {   
            $id = $this->input->get('HighStd_ID');
            $data['record'] = $this->HigherStudiesModel->getrecord($id);

            $result = $this->HigherStudiesModel->delete($id);

            echo "<script language='javascript'>alert(\"$result\");location=\"HigherStudies\"</script>";
        }
    }

}