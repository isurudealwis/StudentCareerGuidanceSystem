<?php
class MultipleIntelligencesController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('MultipleIntelligencesModel');
    }
    
    //Student-Subject Page Functions
    public function multipleintelligences() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {   

        //load table
            $dbresult['data']=$this->MultipleIntelligencesModel->FetchData();
            $this->load->view('navbar');
            $this->load->view('MultipleIntelligencesPage',$dbresult);

        //clear button
            if ($this->input->post('clear')) {
                $_SESSION['keyword']="";
                $_SESSION['column'] ="";
                redirect('MultipleIntelligencesController/multipleintelligences');
            }

        //Find Button
            else if ($this->input->post('find')) {
                $_SESSION['keyword'] = $this->input->post('keyword');
                $_SESSION['column'] = $this->input->post('column');
                redirect('MultipleIntelligencesController/multipleintelligences');
            }

        //Insert Record Button
            else if($this->input->post('insert')) {
                redirect('MultipleIntelligencesController/insert');
            }

            //Back Button
            else if ($this->input->post('back')) {
                redirect('MultipleIntelligencesController/multipleintelligences');
            }
        }
    }

    //Insert Record
    public function insert() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $data['id'] = $this->MultipleIntelligencesModel->newid();
            $this->load->view('navbar');
            $this->load->view('MultipleIntelligencesInsert',$data);

        //If 'Insert' button is pressed...
            if($this->input->post('save')) {
                $id = $this->input->post('MulInt_ID');
                $name = $this->input->post('MulInt_Name');
                $desc = $this->input->post('MulInt_Desc');

                $result=$this->MultipleIntelligencesModel->insert($id, $name, $desc);

                echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";        
            }
        }
    }

    //Update Record
    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $id = $this->input->get('MulInt_ID');
            $data['record'] = $this->MultipleIntelligencesModel->getrecord($id);
            $this->load->view('navbar');
            $this->load->view('MultipleIntelligencesUpdate',$data);

        //If 'Update' button is pressed...
            if($this->input->post('update')) {
                $id = $this->input->post('MulInt_ID');
                $name = $this->input->post('MulInt_Name');
                $desc = $this->input->post('MulInt_Desc');

                $result = $this->MultipleIntelligencesModel->update($id,$name,$desc);

                echo "<script language='javascript'>alert(\"$result\");location=\"multipleintelligences\"</script>";
            }
        }
    }

    public function delete() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $id = $this->input->get('MulInt_ID');
            $result = $this->MultipleIntelligencesModel->delete($id);
            echo "<script language='javascript'>alert(\"$result\");location=\"multipleintelligences\"</script>";
        }
    }

}