	<?php
class SummaryStudentReportController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('SummaryStudentReportModel');
    }
    
    //Student-Subject Page Functions
    public function SummaryStudentReport() {

        //load table
        $data['Overall_Details'] = $this->SummaryStudentReportModel->Overall_Details();
        $data['Exam_Details'] = $this->SummaryStudentReportModel->Exam_Details();
        $data['ExtCur_Details'] = $this->SummaryStudentReportModel->ExtCur_Details();
        $data['Overall_Higher_Studies'] = $this->SummaryStudentReportModel->Overall_Higher_Studies();
        $data['Overall_Career_Options'] = $this->SummaryStudentReportModel->Overall_Career_Options();
        $this->load->view('SummaryStudentReportView',$data);

        if ($this->input->post('Home')) {
            redirect('main/loadmain');
        }
    }


    public function ShowReport() {
        

        
    }


}
