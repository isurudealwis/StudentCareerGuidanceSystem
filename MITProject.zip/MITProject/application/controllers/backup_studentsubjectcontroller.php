<?php
class studentsubjectcontroller extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('StudentSubjectModel');
    }
    
   //--------------------------------------------------------------------Student-Subject Main Page
    public function studentsubject() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
        //Get All Distinct Years
            $dbresult['yearlist'] = $this->StudentSubjectModel->GetDropDownFields('yearlist');        

            $dbresult['keyword'] = $this->input->post('find');
            $dbresult['ColumnSelected'] = $this->input->post('searchtype');
            $dbresult['year'] = $this->input->post('year');

        //load table
            $dbresult['data']=$this->StudentSubjectModel->FetchStudentSubjectData($dbresult);
            $this->load->view('navbar');
            $this->load->view('studentsubject',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
                $dbresult['ColumnSelected'] = '';
                $dbresult['year'] = '';
            }

        //Input button
            else if ($this->input->post('insertrecord')) {
                redirect("studentsubjectcontroller/insertstudentsubject");
            }

        //Find Students Button
            else if ($this->input->post('findstudents')) {
                $dbresult['subject'] = $this->input->post('subject');
                $dbresult['year'] = $this->input->post('year');

                $dbresult['keyword'] = '';
                $dbresult['ColumnSelected'] = '';

                $dbresult['data']=$this->StudentSubjectModel->FetchStudentSubjectData($dbresult);
            }

        //back button
            elseif ($this->input->post('back')) {
                redirect("studentsubjectcontroller/studentsubject");
            }
        }
    }

//------------------------------------------------------------------------Student-Subject Record Insert
    public function insertstudentsubject() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $data['current']=$this->StudentSubjectModel->fetchstudentsubjectid();
            $data['subjectlist']=$this->StudentSubjectModel->GetDropDownFields('subjectlist');
            $data['admission_no']=$this->input->post('Stu_Index_No');
            $data['Stu_ID']=$this->input->post('Stu_ID');
            $data['Stu_Full_Name']=$this->input->post('Stu_Full_Name');
            $data['Stu_Init_Name']=$this->input->post('Stu_Init_Name');
            $this->load->view('navbar');
            $this->load->view('insertstudentsubject',$data);

        //Save Button
            if ($this->input->post('save')) {
                $ssid = $this->input->post('StuSub_ID');
                $stuid = $this->input->post('Stu_ID');
                $subid = $this->input->post('Sub_ID');
                $ssyear = $this->input->post('StuSub_Year');
                
                $result=$this->StudentSubjectModel->insertstudentsubject($ssid, $ssyear, $stuid, $subid);
                echo "<script language='javascript'>alert(\"$result\");location=\"studentsubject\"</script>";
            }
        }
    }

    public function getStudent(){
        $indexno = $this->input->post('Stu_Index_No');
        $data = $this->StudentSubjectModel->fetchstudentdata($indexno);
        echo json_encode($data);
    }

//------------------------------------------------------------------------Student-Subject Record Update
    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $dbresult['subjectlist']=$this->StudentSubjectModel->GetDropDownFields('subjectlist');
            $id['keyword']=$this->input->get('StuSub_ID');
            $id['ColumnSelected']='tbl_student_subject.StuSub_ID';
            $id['year']='';
            $dbresult['record']=$this->StudentSubjectModel->FetchUpdateData($id);
            
            $this->load->view('navbar');
            $this->load->view('updatestudentsubject',$dbresult);
            if ($this->input->post('update')) {
                $ssid = $this->input->post('StuSub_ID');
                $stuid = $this->input->post('Stu_ID');
                $subid = $this->input->post('Sub_ID');
                $ssyear = $this->input->post('StuSub_Year');
                $result=$this->StudentSubjectModel->update($ssid, $ssyear, $stuid, $subid);
              echo "<script language='javascript'>alert(\"$result\");location=\"studentsubject\"</script>";
            }
        }
    }


//------------------------------------------------------------------------Student-Subject Record Delete
    public function delete() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $sid=$this->input->get('StuSub_ID');
            $result=$this->StudentSubjectModel->deletestudentsubjectrecord($sid);
            echo "<script language='javascript'>alert(\"$result\");location=\"studentsubject\"</script>";
        }
    }

}