	<?php
class TeacherReportController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('TeacherReportModel');
    }
    
    //Student-Subject Page Functions
    public function TeacherReport() {

        //Fetch Teacher details
        $data['TeacherList'] = $this->TeacherReportModel->getteacherlist();
        //load table
        $this->load->view('teacherreportpage',$data);

        if($this->input->post('getteacher')) {
        	$Tea_ID = $this->input->post('Teacher');
        		$_SESSION['Tea_ID'] = $Tea_ID;
        		redirect('TeacherReportController/ShowReport');
        }

        if ($this->input->post('Home')) {
            redirect('main/loadmain');
        }
    }


    public function ShowReport() {
        $Tea_ID = $_SESSION['Tea_ID'];
        $data['Teacher_Details'] = $this->TeacherReportModel->FetchTeacherData($Tea_ID);
        $data['OverallPerformance'] = $this->TeacherReportModel->FetchData($Tea_ID,'GetOverallPerformance');
        $data['YearlyPerformance'] = $this->TeacherReportModel->FetchData($Tea_ID,'GetYearlyPerformance');
        $data['L3EP'] = $this->TeacherReportModel->FetchData($Tea_ID,'L3EP');
        $data['L3EP2'] = $this->TeacherReportModel->FetchData($Tea_ID,'L3EP2');
        $data['DistinctSubjects'] = $this->TeacherReportModel->FetchData($Tea_ID,'DistinctSubjects');
        $data['MIAttributes'] = $this->TeacherReportModel->FetchData($Tea_ID,'MIAttributes');
        $data['DistinctYear'] = $this->TeacherReportModel->FetchData($Tea_ID,'DistinctYear');
        $data['DistinctMI'] = $this->TeacherReportModel->FetchData($Tea_ID,'DistinctMI');
        $data['YearTerm'] = $this->TeacherReportModel->FetchData($Tea_ID,'YearTerm');


        $this->load->view('TeacherReportDetail',$data);

        if($this->input->post('back')) {
            redirect("TeacherReportController/TeacherReport");
        }

        
    }


}
