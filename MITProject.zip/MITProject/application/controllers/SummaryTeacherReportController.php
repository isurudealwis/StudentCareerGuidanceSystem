	<?php
class SummaryTeacherReportController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('SummaryTeacherReportModel');
    }
    
    //Student-Subject Page Functions
    public function SummaryTeacherReport() {

        //Fetch Teacher details
        $data['OverallPerformance'] = $this->SummaryTeacherReportModel->FetchData('GetOverallPerformance');
        $data['YearlyPerformance'] = $this->SummaryTeacherReportModel->FetchData('GetYearlyPerformance');
        $data['LYP'] = $this->SummaryTeacherReportModel->FetchData('LYP');
        $data['SWP'] = $this->SummaryTeacherReportModel->FetchData('SWP');
        $data['DistinctSubjects'] = $this->SummaryTeacherReportModel->FetchData('DistinctSubjects');
        $data['MIAttributes'] = $this->SummaryTeacherReportModel->FetchData('MIAttributes');
        $data['DistinctYear'] = $this->SummaryTeacherReportModel->FetchData('DistinctYear');
        $data['DistinctMI'] = $this->SummaryTeacherReportModel->FetchData('DistinctMI');
        $data['YearTerm'] = $this->SummaryTeacherReportModel->FetchData('YearTerm');

        $this->load->view('SummaryTeacherReportView', $data);

        if ($this->input->post('Home')) {
            redirect('main/loadmain');
        }
    }
}
