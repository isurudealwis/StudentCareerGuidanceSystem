<?php
class TSCController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('TSCModel');
    }
    
    //Student-Subject Page Functions
    public function TSC() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {

        //load table
            $dbresult['data']=$this->TSCModel->FetchData();
            $this->load->view('navbar');
            $this->load->view('TSCPage',$dbresult);

        //clear button
            if ($this->input->post('clear')) {
                $_SESSION['keyword']="";
                $_SESSION['column'] ="";
                redirect('TSCController/TSC');
            }

        //Find Button
            else if ($this->input->post('find')) {
                $_SESSION['keyword'] = $this->input->post('keyword');
                $_SESSION['column'] = $this->input->post('column');
                redirect('TSCController/TSC');
            }

        //Insert Record Button
            else if($this->input->post('insert')) {
                redirect('TSCController/insert');
            }

        //Back Button
            else if ($this->input->post('back')) {
                redirect('TSCController/TSC');
            }
        }
    }

    //Insert Record
    public function insert() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $data['id'] = $this->TSCModel->newid();
            $data['subjectlist'] = $this->TSCModel->getsubjectlist();
            $data['classlist'] = $this->TSCModel->getclasslist();
            $data['teacherlist'] = $this->TSCModel->getteacherlist();
            $this->load->view('navbar');
            $this->load->view('TSCinsert',$data);

        //If 'Insert' button is pressed...
            if($this->input->post('save')) {
                $id = $this->input->post('TeaSub_ID');
                $year = $this->input->post('TeaSub_Year');
                $teaid = $this->input->post('Tea_ID');
                $subid = $this->input->post('Sub_ID');
                $clsid = $this->input->post('Cls_ID');

                $result=$this->TSCModel->insert($id, $year, $teaid, $subid, $clsid);
                echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";
            }
        }
    }


    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $id = $this->input->get('TeaSub_ID');
            $data['record'] = $this->TSCModel->getrecord($id);
            $data['subjectlist'] = $this->TSCModel->getsubjectlist();
            $data['classlist'] = $this->TSCModel->getclasslist();
            $data['teacherlist'] = $this->TSCModel->getteacherlist();
            $this->load->view('navbar');
            $this->load->view('TSCUpdate',$data);

        //If 'Update' button is pressed...
            if($this->input->post('update')) {
                $id = $this->input->post('TeaSub_ID');
                $year = $this->input->post('TeaSub_Year');
                $teaid = $this->input->post('Tea_ID');
                $subid = $this->input->post('Sub_ID');
                $clsid = $this->input->post('Cls_ID');

                $result=$this->TSCModel->update($id, $year, $teaid, $subid, $clsid);

                echo "<script language='javascript'>alert(\"$result\");location=\"TSC\"</script>";      
            }
        }
    }


    public function delete() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $id = $this->input->get('TeaSub_ID');
            $data['record'] = $this->TSCModel->getrecord($id);
            $result = $this->TSCModel->delete($id);
            echo "<script language='javascript'>alert(\"$result\");location=\"TSC\"</script>";
        }
    }
}
