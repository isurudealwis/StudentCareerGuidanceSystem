<?php
class ExamController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('ExamModel');
    }
    
    //Exam Page Functions
    public function exam() {
        //Check whether the user is admin
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            //Get All Distinct Years
            $dbresult['yearlist'] = $this->ExamModel->GetDropDownFields('yearlist');        

            //Check to see whether the user entered something to search
            $dbresult['keyword'] = $this->input->post('find');
            $dbresult['ColumnSelected'] = $this->input->post('searchcolumn');
            $dbresult['year'] = $this->input->post('year');

            //Get all data from table
            $dbresult['data']=$this->ExamModel->FetchExamData($dbresult);

            //Load the exam page view
            $this->load->view('navbar');
            $this->load->view('ExamPage',$dbresult);

            
            //If the user press the clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
                $dbresult['ColumnSelected'] = '';
                $dbresult['year'] = '';
            }


            //If the user press the 'Insert Record' button
            else if ($this->input->post('insertrecord')) {
                redirect("ExamController/insert");
            }

            //If the user press the 'Find Exam' Button
            else if ($this->input->post('findexam')) {
                $dbresult['year'] = $this->input->post('year');
                $dbresult['keyword'] = $this->input->post('find');
                $dbresult['ColumnSelected'] = $this->input->post('searchcolumn');
                $dbresult['data']=$this->ExamModel->FetchExamData($dbresult);
            }

            //If the user press the 'Back' button
            elseif ($this->input->post('back')) {
                redirect("examcontroller/exam");
            }
        }
    }

    //Exam Record Insert
    public function insert() {
        //Check whether the user is admin
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            //Get the last entered Exam_ID
            $data['current']=$this->ExamModel->fetchexamid();

            //Get the Dropdown List data
            $data['subjectlist']=$this->ExamModel->GetDropDownFields('subjectlist');
            $data['mulintlist']=$this->ExamModel->GetDropDownFields('mulintlist');
            
            //Load the Insert view page
            $this->load->view('navbar');
            $this->load->view('ExamInsert',$data);

            //If the user press the 'Save Record' Button
            if ($this->input->post('save')) {
                $Exam_ID=$this->input->post('Exam_ID');
                $Exam_Year=$this->input->post('Exam_Year');
                $Exam_Term=$this->input->post('Exam_Term');
                $Sub_ID=$this->input->post('Sub_ID');
                $MulInt_ID=$this->input->post('MulInt_ID');

                $result=$this->ExamModel->insertrecord($Exam_ID,$Exam_Year,$Exam_Term,$Sub_ID,$MulInt_ID);
                echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";
            }
        }
    }


  //Exam Record Update
    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {

            //Get the relevant Exam_ID from the exam page
            $Exam_ID=$this->input->get('Exam_ID');

            //Get the Dropdown List data
            $data['subjectlist']=$this->ExamModel->GetDropDownFields('subjectlist');
            $data['mulintlist']=$this->ExamModel->GetDropDownFields('mulintlist');

            //Get record data from the table
            $data['record']=$this->ExamModel->FetchUpdateData($Exam_ID);

            //Load the Exam update page
            $this->load->view('navbar');
            $this->load->view('ExamUpdate',$data);

            //When the user press the 'update' button
            if ($this->input->post('update')) {

                //Obtain values from update page to variables
                $Exam_ID=$this->input->post('Exam_ID');
                $Exam_Year=$this->input->post('Exam_Year');
                $Exam_Term=$this->input->post('Exam_Term');
                $Sub_ID=$this->input->post('Sub_ID');
                $MulInt_ID=$this->input->post('MulInt_ID');

                //Send the values to the database model
                $result=$this->ExamModel->update($Exam_ID,$Exam_Year,$Exam_Term,$Sub_ID,$MulInt_ID);

                //Show the result
                echo "<script language='javascript'>alert(\"$result\");location=\"exam\"</script>";
            }  

        }
    }

//Student-Subject Record Delete
    public function delete() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $examid=$this->input->get('Exam_ID');
            $result=$this->ExamModel->examdelete($examid);
            echo "<script language='javascript'>alert(\"$result\");location=\"exam\"</script>";
        }

    }
}