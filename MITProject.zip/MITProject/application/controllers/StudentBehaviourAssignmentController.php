<?php
class StudentBehaviourAssignmentController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('StudentBehaviourAssignmentModel');
    }
    
    //Student-Subject Page Functions
    public function StudentBehaviourAssignment() {
        $_SESSION['StuExt_ID']='';
        $_SESSION['Stu_Index_No']='';

        //load table
        $dbresult['data']=$this->StudentBehaviourAssignmentModel->FetchData();
        $this->load->view('navbar');
        $this->load->view('StudentBehaviourAssignmentPage',$dbresult);

        //clear button
        if ($this->input->post('clear')) {
            $_SESSION['keyword']="";
            $_SESSION['column'] ="";
            redirect('StudentBehaviourAssignmentController/StudentBehaviourAssignment');
        }

        //Find Button
        else if ($this->input->post('find')) {
            $_SESSION['keyword'] = $this->input->post('keyword');
            $_SESSION['column'] = $this->input->post('column');
            redirect('StudentBehaviourAssignmentController/StudentBehaviourAssignment');
        }

        //Insert Record Button
        else if($this->input->post('insert')) {
            redirect('StudentBehaviourAssignmentController/insert');
        }

        //Update Record Button
        else if($this->input->get('update')) {
            redirect('StudentBehaviourAssignmentController/update');
        }
    }

    //Insert Record
    public function insert() {
        $data['id'] = $this->StudentBehaviourAssignmentModel->newid();
        //Get Behavioural Activities Table Data
        $data['behlist'] = $this->StudentBehaviourAssignmentModel->FetchBehaviouralActivity();
        $AdmissionNo = $this->input->post('admission_no');
        $data['record'] = $this->StudentBehaviourAssignmentModel->FetchStudent($AdmissionNo);
        $this->load->view('navbar');
        $this->load->view('StudentBehaviourAssignmentInsert',$data);

        if($this->input->post('GetStudent')) {
            $_SESSION['Stu_Index_No'] = $this->input->post('admission_no');
            $data['record'] = $this->StudentBehaviourAssignmentModel->FetchStudent();
            redirect('StudentBehaviourAssignmentController/insert');
        }

        //If 'Insert' button is pressed...
        else if($this->input->post('save')) {
            $id = $this->input->post('StuExt_ID');
            $sid = $this->input->post('Stu_ID');
            $aid = $this->input->post('BehAct_ID');
            $points = $this->input->post('StuExt_Points');
            $tid = $_SESSION['user'];

            $result=$this->StudentBehaviourAssignmentModel->insert($id, $sid, $aid, $points, $tid);

            echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";                
        }
    }

 //Update Record
    public function update() {
        //Get Behavioural Activities Table Data
        $data['behlist'] = $this->StudentBehaviourAssignmentModel->FetchBehaviouralActivity();

        $StuExt_ID =$this->input->get('StuExt_ID');
        $data['record'] = $this->StudentBehaviourAssignmentModel->FetchRecord($StuExt_ID);
        
        $this->load->view('navbar');
        $this->load->view('StudentBehaviourAssignmentUpdate',$data);

        //If 'Update' button is pressed...
        if($this->input->post('update')) {
            $id = $this->input->post('StuExt_ID');
            $sid = $this->input->post('Stu_ID');
            $aid = $this->input->post('BehAct_ID');
            $points = $this->input->post('StuExt_Points');
            $tid = $_SESSION['user'];

            $result=$this->StudentBehaviourAssignmentModel->update($id, $sid, $aid, $points, $tid);

            echo "<script language='javascript'>alert(\"$result\");location=\"StudentBehaviourAssignment\"</script>";     
        }
    }

    public function delete() {
        $id = $this->input->get('StuExt_ID');
        $result = $this->StudentBehaviourAssignmentModel->delete($id);
        echo "<script language='javascript'>alert(\"$result\");location=\"StudentBehaviourAssignment\"</script>";      
    }

    public function fetchstudentdetails($AdmissionNo) {
        if($this->input->post('GetStudent')) {
            $data['record'] = $this->StudentBehaviourAssignmentModel->FetchStudent($AdmissionNo);
            return $data;
        }
    }

}