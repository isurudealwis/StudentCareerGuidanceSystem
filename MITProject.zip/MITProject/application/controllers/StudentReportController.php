	<?php
class StudentReportController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('StudentReportModel');
    }
    
    //Student-Subject Page Functions
    public function StudentReport() {

        //load table
        $this->load->view('studentreportpage');

        if($this->input->post('getstudent')) {
        	$Stu_Index_No = $this->input->post('Stu_Index_No');
        		$_SESSION['Stu_Index_No'] = $Stu_Index_No;
        		redirect('StudentReportController/ShowReport');
        }

        if ($this->input->post('Home')) {
            redirect('main/loadmain');
        }
    }


    public function ShowReport() {
        $Stu_Index_No = $_SESSION['Stu_Index_No'];
        $data['Student_Details'] = $this->StudentReportModel->FetchStudentData($Stu_Index_No);
        $data['Overall_Details'] = $this->StudentReportModel->FetchOverallData($Stu_Index_No);
        $data['Exam_Details'] = $this->StudentReportModel->FetchExamData($Stu_Index_No);
        $data['ExtCur_Details'] = $this->StudentReportModel->FetchExtcurData($Stu_Index_No);
        $this->load->view('studentreportdetail',$data);

        if($this->input->post('back')) {
            redirect("StudentReportController/StudentReport");
        }

        
    }


}
