<?php
class main extends CI_Controller {
    function __construct() {
        parent::__construct();
        $data['record']='';
    }

    
    //User Login Function
    public function login() {
        
        //Loading the login page
        $this->load->view( 'loginpage' );

        //When the user press the 'Login' button...
        if ( $this->input->post( 'login' ) ) {
            //Get the user ID and the password from the form.
            $data[ 'userid' ] = $this->input->post( 'LoginID' );
            $data[ 'password' ] = $this->input->post( 'pw' );

            //Send it to the Database
            $user = $this->MODELDB->login( $data );

            //Runs if the user credentials are correct.
            if(!empty($user)) {
                //Save the database result in sessions
                foreach($user as $u) {
                    php.session_start();
                    $_SESSION['user'] = $u->Tea_ID;
                    $_SESSION['userfname'] = $u->Tea_First_Name;
                    $_SESSION['userlname'] = $u->Tea_Last_Name;
                    $_SESSION['isadmin'] = $u->Tea_StaffAdmin;
                    redirect('main/loadmain'); 
                }
            }

            //Runs if the user cannot find from the Database
            else {
                echo "<script language='javascript'>alert(\"Invalid Teacher ID/Password. Please re-check.\");</script>";
            }   
        }
    }

    public function loadmain() {

        //Check whether the user is logged in.
        if(empty($_SESSION['user'])) {
            $this->load->view( 'loginpage' );
        }
        else {
            
            $this->load->view('navbar');
            $this->load->view('home');

            if( $this->input->post('logout')){
                session_unset();
                session_destroy();
                redirect('main/login');;
            }

            elseif ($this->input->post('home')) {
                redirect('main/loadmain');
            }
            elseif ( $this->input->post('students')){
                redirect('studentscontroller/student');
            }
            elseif ( $this->input->post('teachers')) {
                redirect('teacherscontroller/teacher');
            }
            elseif ( $this->input->post('subjects')) {
                redirect('classesandsubjectscontroller/subject');
            }
            elseif ( $this->input->post('classes')) {
                redirect('classesandsubjectscontroller/class');
            }
            elseif ( $this->input->post('studentclass')) {
                redirect('studentclasscontroller/studentclass');
            }
            elseif ( $this->input->post('studentsubject')) {
                redirect('studentsubjectcontroller/studentsubject');
            }
            elseif ( $this->input->post('examinations')) {
                redirect('ExamController/exam');
            }
            elseif ( $this->input->post('marks')) {
                redirect('markscontroller/marks');
            }

            elseif( $this->input->post('multipleintel')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('MultipleIntelligencesController/multipleintelligences');
            }

            elseif( $this->input->post('behactivities')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('BehaviouralActivitiesController/behaviouralactivities');
            }

            elseif ($this->input->post('behactassignment')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('StudentBehaviourAssignmentController/StudentBehaviourAssignment');
            }

            elseif ($this->input->post('HigherStudies')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('HigherStudiesController/HigherStudies');
            }

            elseif ($this->input->post('CareerOptions')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('CareerOptionsController/CareerOptions');
            }

            elseif ($this->input->post('teachersubject')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('TSCController/TSC');
            }

            elseif ($this->input->post('StudentReport')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('StudentReportController/StudentReport');

            }

            elseif ($this->input->post('TeacherReport')) {
                $_SESSION['column'] = "";
                $_SESSION['keyword'] = "";
                redirect('TeacherReportController/TeacherReport');
            }

            elseif ($this->input->post('SummaryTeacherReport')) {
                redirect('SummaryTeacherReportController/SummaryTeacherReport');
            }

            elseif ($this->input->post('SummaryStudentReport')) {
                redirect('SummaryStudentReportController/SummaryStudentReport');
            }

        }
    }
}

?>

