<?php
class CareerOptionsController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('CareerOptionsModel');
    }
    
    //Student-Subject Page Functions
    public function CareerOptions() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {

        //load table
        $dbresult['data']=$this->CareerOptionsModel->FetchData();
        $this->load->view('navbar');
        $this->load->view('CareerOptionsPage',$dbresult);

        //clear button
        if ($this->input->post('clear')) {
            $_SESSION['keyword']="";
            $_SESSION['column'] ="";
            redirect('CareerOptionsController/CareerOptions');
        }

        //Find Button
        else if ($this->input->post('find')) {
            $_SESSION['keyword'] = $this->input->post('keyword');
            $_SESSION['column'] = $this->input->post('column');
            redirect('CareerOptionsController/CareerOptions');
        }

        //Insert Record Button
        else if($this->input->post('insert')) {
            redirect('CareerOptionsController/insert');
        }

            //Back Button
        else if ($this->input->post('back')) {
            redirect('CareerOptionsController/CareerOptions');
        }
    }
    }

    //Insert Record
public function insert() {
    if($_SESSION["isadmin"]=="No") {
        $this->load->view('navbar');
        $this->load->view('errorpage');
    }
    else {
        $data['id'] = $this->CareerOptionsModel->newid();
        $data['mulintlist'] = $this->CareerOptionsModel->getmulintlist();
        $this->load->view('navbar');
        $this->load->view('CareerOptionsInsert',$data);

        //If 'Insert' button is pressed...
        if($this->input->post('save')) {
            $id = $this->input->post('CarPath_ID');
            $name = $this->input->post('CarPath_Name');
            $desc = $this->input->post('CarPath_Desc');
            $mulint = $this->input->post('MulInt_ID');

            $result=$this->CareerOptionsModel->insert($id, $name, $desc, $mulint);

            echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";          
        }
    }
}


public function update() {
    if($_SESSION["isadmin"]=="No") {
        $this->load->view('navbar');
        $this->load->view('errorpage');
    }
    else {
        $id = $this->input->get('CarPath_ID');
        $data['record'] = $this->CareerOptionsModel->getrecord($id);
        $data['mulintlist'] = $this->CareerOptionsModel->getmulintlist();
        $this->load->view('navbar');
        $this->load->view('CareerOptionsUpdate',$data);

        //If 'Update' button is pressed...
        if($this->input->post('update')) {
            $id = $this->input->post('CarPath_ID');
            $name = $this->input->post('CarPath_Name');
            $desc = $this->input->post('CarPath_Desc');
            $mulint = $this->input->post('MulInt_ID');

            $result = $this->CareerOptionsModel->update($id,$name,$desc, $mulint);

            echo "<script language='javascript'>alert(\"$result\");location=\"CareerOptions\"</script>";         
        }
    }
}

public function delete() {
    if($_SESSION["isadmin"]=="No") {
        $this->load->view('navbar');
        $this->load->view('errorpage');
    }
    else{
        $id = $this->input->get('CarPath_ID');
        $data['record'] = $this->CareerOptionsModel->getrecord($id);

        $result = $this->CareerOptionsModel->delete($id);

        echo "<script language='javascript'>alert(\"$result\");location=\"CareerOptions\"</script>";
    }

}

}