<?php
class studentscontroller extends CI_Controller {
    function __construct() {
        parent::__construct();
    }
    
    //Student Page Functions
    public function student() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $dbresult['keyword'] = $this->input->post('find');
            $dbresult['ColumnSelected'] = $this->input->post('searchtype');

        //load table
            $dbresult['data']=$this->MODELDB->FetchStudentData($dbresult);
            $this->load->view('navbar');
            $this->load->view('studentpage',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
                $dbresult['ColumnSelected'] = '';
            }

        //Input button
            else if ($this->input->post('insert')) {
                redirect("studentscontroller/insert");
            }

        //Search Button
            else if ($this->input->post('findrecord')) {
            //Get the text value from the search box
                $dbresult['keyword'] = $this->input->post('find');

            //Get the selected value from the 'Search Type' list box
                $dbresult['ColumnSelected'] = $this->input->post('searchtype');
                
            //Send data to the ModelDB
                $dbresult['data']=$this->MODELDB->FetchStudentData($dbresult);
            }

            elseif ($this->input->post('back')) {
                redirect("studentscontroller/student");
            }
        }
    }


    //Student Record Insert
    public function insert() {
        //Check whether the user is admin
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $stuid['current']=$this->MODELDB->fetchstudentid();
            $this->load->view('navbar');
            $this->load->view('insertstudent',$stuid);

            if ($this->input->post('save')) {

                $sid = $this->input->post('Stu_ID');
                $sfname = $this->input->post('Stu_Full_Name');
                $siname = $this->input->post('Stu_Init_Name');
                $sindno = $this->input->post('Stu_Index_No');
                $sdob = $this->input->post('Stu_DOB');
                $stelhome = $this->input->post('Stu_Home_Tel');
                $stelmob = $this->input->post('Stu_Mobile_Tel');
                $semail = $this->input->post('Stu_Email');
                
                //Check Student Index number is already added.
                $indexnochecker = $this->MODELDB->fetchstudentindexno($sindno);
                if(!empty($indexnochecker)){
                    echo "<script language='javascript'>alert(\"Student Admission Number is already added. Please Re-check.\");</script>";
                }
                else {
                    $result=$this->MODELDB->insert($sid, $sfname, $siname, $sindno, $sdob, $stelhome, $stelmob, $semail);

                    echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";  
                }
            }
        }
    }


  //Student Record Update
    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $id=$this->input->get('Stu_ID');
            $dbresult['record']=$this->MODELDB->fetchstudentrecord($id);
            $this->load->view('navbar');
            $this->load->view('updatestudent',$dbresult);

            if ($this->input->post('update')) {
                $sid = $this->input->post('Stu_ID');
                $sfname = $this->input->post('Stu_Full_Name');
                $siname = $this->input->post('Stu_Init_Name');
                $sindno = $this->input->post('Stu_Index_No');
                $sdob = $this->input->post('Stu_DOB');
                $stelhome = $this->input->post('Stu_Home_Tel');
                $stelmob = $this->input->post('Stu_Mobile_Tel');
                $semail = $this->input->post('Stu_Email');

                //Get the current Student Admission Number from Database
                $CurrentIndexNo = $this->MODELDB->currentstudentindexno($sid);

                //Checking whether the updating Index No is equal to the actual Index Number (comparing using the Stu_ID)
                if($CurrentIndexNo == $sindno) {
                    $result=$this->MODELDB->update($sid, $sfname, $siname, $sindno, $sdob, $stelhome, $stelmob, $semail);
                    echo "<script language='javascript'>alert(\"$result\");location=\"student\"</script>";
                }

                else {
                //Check Student Index number is already added.
                    $indexnochecker = $this->MODELDB->fetchstudentindexno($sindno);
                    if(!empty($indexnochecker)){
                        echo "<script language='javascript'>alert(\"Student Admission Number is already added. Please Re-check.\"); location=\"student\"</script>";
                    }

                    else {

                        $result=$this->MODELDB->update($sid, $sfname, $siname, $sindno, $sdob, $stelhome, $stelmob, $semail);
                       echo "<script language='javascript'>alert(\"$result\");location=\"student\"</script>";
                    }
                }
            }
        }
    }


//Student Record Delete
    public function delete() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $sid=$this->input->get('Stu_ID');
            $this->MODELDB->delete($sid);
            echo "<script language='javascript'>alert(\"$result\");location=\"student\"</script>";
        }
    }
}
?>