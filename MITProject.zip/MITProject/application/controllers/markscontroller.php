<?php
$dbresult['yearlist']='';
$dbresult['termlist']='';
$dbresult['classlist']='';
$dbresult['subjectlist']='';


class MarksController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('MarksModel');
        $this->load->library('session');
    }
    
    //Marks page function
    public function marks() {

            //Get All Distinct Years (to load to the 'Year' Dropdown List)
        $dbresult['yearlist'] = $this->MarksModel->GetDropDownFields('yearlist');

            //Get all Distinct Terms (to load to the 'Terms' Dropdown List)
        $dbresult['termlist'] = $this->MarksModel->GetDropDownFields('termlist');

            //Get all Distinct Classes (to load to the 'Class' Dropdown List)
        $dbresult['classlist'] = $this->MarksModel->GetDropDownFields('classlist');

            //Get all Distinct Subjects (to load to the 'Subjects' Dropdown List)
        $dbresult['subjectlist'] = $this->MarksModel->GetDropDownFields('subjectlist');

        $this->load->view('navbar');
        $this->load->view('markspage',$dbresult);


        if($this->input->post('getstudents')) {

                //Get the Selected Years from the 'Year' Dropdown List
            $_SESSION['YearSelected'] = $this->input->post('Year');

            //Get the Selected Terms from the 'Term' Dropdown List
            $_SESSION['TermSelected'] = $this->input->post('Term');

            //Get the Selected Classes from the 'Class' Dropdown List
            $_SESSION['ClassSelected'] = $this->input->post('Class');

            //Get the Selected Subjects from the 'Subjects' Dropdown List
            $_SESSION['SubjectSelected'] = $this->input->post('Subject');
            
            redirect('markscontroller/marksdetails');
        }
    }


    public function marksdetails() {

            //Get the Selected Years from the 'Year' Dropdown List
        $data['YearSelected'] = $_SESSION['YearSelected'];

            //Get the Selected Terms from the 'Term' Dropdown List
        $data['TermSelected'] = $_SESSION['TermSelected'];

            //Get the Selected Classes from the 'Class' Dropdown List
        $data['ClassSelected'] = $_SESSION['ClassSelected'];

            //Get the Selected Subjects from the 'Subjects' Dropdown List
        $data['SubjectSelected'] = $_SESSION['SubjectSelected'];

            //Send the data to the getstudents function in marksmodel and obtain the result in 'data'
        $data['students']=$this->MarksModel->getstudents($data);

            //Load the marksdetails view
        $this->load->view('navbar');
        $this->load->view('marksdetails',$data);

        if($this->input->post('selection')) {
            redirect("markscontroller/marks");
        }

        if($this->input->post('delete')) {
            redirect('markscontroller/deletemarks');
        }

    }


    public function insertupdatemark() {
        if(empty($_SESSION['user'])) {
            $this->load->view( 'loginpage' );
        }
        else {

            if($this->input->post('homepage')) {
                redirect("main/loadmain");
            }

            $Exam_ID = $_GET['examid'];
            $StuSub_ID = $_GET['stusubid'];
            $Mrk_Mark = $_GET['mark'];
            $Mrk_ID = $_GET['markid'];
                //Get the Teachers_ID
            $Tea_ID = $_SESSION['user'];

                //Send it to the database to see whether the relevant mark_ID is available
            $data['markidresult'] = $this->MarksModel->fetchmarksid($StuSub_ID, $Exam_ID);

                //If the Mark_ID is available, it will update the data
            if(($data['markidresult'])) {
                $data['markinputresult'] = $this->MarksModel->updatemarks($Exam_ID, $StuSub_ID, $Mrk_Mark, $Tea_ID, $Mrk_ID);
            }
                //Else, it will add new Mark_ID record
            else {
                $data['markinputresult'] = $this->MarksModel->insertmarks($Exam_ID, $StuSub_ID, $Mrk_Mark, $Tea_ID);
            }

            redirect('markscontroller/marksdetails');
        }
    }
}
?>