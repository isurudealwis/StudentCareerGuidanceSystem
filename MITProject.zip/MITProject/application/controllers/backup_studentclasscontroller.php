<?php
class studentclasscontroller extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('StudentClassModel');
    }
    
   //---------------------------------------------------------------------Student-Class Page Home Page
    public function studentclass() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
        //Get All Table Headers
            $dbresult['tableheaders'] = $this->StudentClassModel->GetDropDownFields('tableheaders');

        //Get All Distinct Years
            $dbresult['yearlist'] = $this->StudentClassModel->GetDropDownFields('yearlist');        

            $dbresult['keyword'] = $this->input->post('find');
            $dbresult['ColumnSelected'] = $this->input->post('searchtype');
            $dbresult['year'] = $this->input->post('year');

        //load table
            $dbresult['data']=$this->StudentClassModel->FetchStudentClassData($dbresult);
            $this->load->view('navbar');
            $this->load->view('studentclass',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
                $dbresult['ColumnSelected'] = '';
                $dbresult['year'] = '';
            }

        //Input button
            else if ($this->input->post('insertrecord')) {
                redirect("studentclasscontroller/insertstudentclass");
            }

        //Find Students Button
            else if ($this->input->post('findstudents')) {
                $dbresult['class'] = $this->input->post('class');
                $dbresult['year'] = $this->input->post('year');

                $dbresult['keyword'] = '';
                $dbresult['ColumnSelected'] = '';

                $dbresult['data']=$this->StudentClassModel->FetchStudentClassData($dbresult);
            }
                    //back button
            elseif ($this->input->post('back')) {
                redirect("studentclasscontroller/studentclass");
            }
        }
    }

    //----------------------------------------------------------------------Student-Class Record Insert
    public function insertstudentclass() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $data['current']=$this->StudentClassModel->fetchstudentclassid();
            $data['classlist']=$this->StudentClassModel->GetDropDownFields('classlist');
            $data['admission_no']=$this->input->post('admission_no');
            $data['Stu_ID']=$this->input->post('Stu_ID');
            $data['Stu_Full_Name']=$this->input->post('Stu_Full_Name');
            $data['Stu_Init_Name']=$this->input->post('Stu_Init_Name');
            $data['record']=$this->StudentClassModel->fetchstudentclassrecord($data['admission_no']);

            $this->load->view('navbar');
            $this->load->view('insstudentclass',$data);

        //Save Button
            if ($this->input->post('save')) {
                $scid = $this->input->post('StuCls_ID');
                $sid = $this->input->post('Stu_ID');
                $scyear = $this->input->post('year');
                $cid = $this->input->post('class');
                    
                $result=$this->StudentClassModel->insertstudentclass($scid, $scyear, $sid, $cid);
                echo "<script language='javascript'>alert(\"$result\");location=\"insertstudentclass\"</script>";
                }
            }
        }
    

    public function getStudent(){
        $indexno = $this->input->post('Stu_Index_No');
        $data = $this->StudentClassModel->fetchstudentdata($indexno);
        echo json_encode($data);
    }

  //------------------------------------------------------------------------Student-Class Record Update
    public function update() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $dbresult['classlist']=$this->StudentClassModel->GetDropDownFields('classlist');
            $id['keyword']=$this->input->get('StuCls_ID');
            $id['ColumnSelected']='tbl_student_class.StuCls_ID';
            $id['year']='';
            $dbresult['record']=$this->StudentClassModel->FetchUpdateData($id);

            $this->load->view('navbar');
            $this->load->view('updatestudentclass',$dbresult);

            if ($this->input->post('update')) {
                $scid = $this->input->post('StuCls_ID');
                $sid = $this->input->post('Stu_ID');
                $scyear = $this->input->post('StuCls_Year');
                $cid = $this->input->post('Cls_ID');

                $result=$this->StudentClassModel->updatestudentclassrecord($scid, $scyear, $sid, $cid);
                echo "<script language='javascript'>alert(\"$result\");location=\"studentclass\"</script>";
            }
        }
    }


//------------------------------------------------------------------------Student-Class Record Delete
    public function delete() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $sid=$this->input->get('StuCls_ID');
            $result=$this->StudentClassModel->deletestudentclassrecord($sid);
            echo "<script language='javascript'>alert(\"$result\");location=\"studentclass\"</script>";
        }
    }
}