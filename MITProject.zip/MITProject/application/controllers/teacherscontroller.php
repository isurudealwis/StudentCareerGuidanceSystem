<?php
class teacherscontroller extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('TeacherDB');
    }
    

    //Teacher Page Functions
    public function teacher() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $dbresult['keyword'] = $this->input->post('find');
            $dbresult['ColumnSelected'] = $this->input->post('searchtype');

        //load table
            $dbresult['data']=$this->TeacherDB->FetchTeacherData($dbresult);
            $this->load->view('navbar');
            $this->load->view('teacherpage',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
                $dbresult['ColumnSelected'] = '';
            }

        //Input button
            else if ($this->input->post('insert')) {
                redirect("teacherscontroller/insert");
            }

        //Search Button
            else if ($this->input->post('findrecord')) {
            //Get the text value from the search box
                $dbresult['keyword'] = $this->input->post('find');

            //Get the selected value from the 'Search Type' list box
                $dbresult['ColumnSelected'] = $this->input->post('searchtype');

            //Send data to the TeacherDB
                $dbresult['data']=$this->TeacherDB->FetchTeacherData($dbresult);
            }

            elseif ($this->input->post('back')) {
                redirect("teacherscontroller/teacher");
            }
        }
    }


    //Teacher Record Insert
    public function insert() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $teaid['current']=$this->TeacherDB->fetchteacherid();
            $this->load->view('navbar');
            $this->load->view('insertteacher',$teaid);

            if ($this->input->post('save')) {
                $tid = $this->input->post('Tea_ID');
                $tfname = $this->input->post('Tea_First_Name');
                $tlname = $this->input->post('Tea_Last_Name');
                $tnicno = $this->input->post('Tea_NIC_No');
                $tdob = $this->input->post('Tea_DOB');
                $ttelhome = $this->input->post('Tea_Home_Tel');
                $ttelmob = $this->input->post('Tea_Mobile_Tel');
                $temail = $this->input->post('Tea_Email');
                $tpw = $this->input->post('Tea_Pass');
                $tadmin = $this->input->post('Tea_StaffAdmin');
                
                $result=$this->TeacherDB->insert($tid, $tfname, $tlname, $tnicno, $tdob, $ttelhome, $ttelmob, $temail, $tadmin, $tpw);

                echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";  
            }
        }
    }


  //Teacher Record Update
    public function update() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $id=$this->input->get('Tea_ID');
            $dbresult['record']=$this->TeacherDB->fetchteacherrecord($id);

            $this->load->view('navbar');
            $this->load->view('updateteacher',$dbresult);
            if ($this->input->post('update')) {
                $tid = $this->input->post('Tea_ID');
                $tfname = $this->input->post('Tea_First_Name');
                $tlname = $this->input->post('Tea_Last_Name');
                $tdob = $this->input->post('Tea_DOB');
                $ttelhome = $this->input->post('Tea_Home_Tel');
                $ttelmob = $this->input->post('Tea_Mobile_Tel');
                $temail = $this->input->post('Tea_Email');
                $tpw = $this->input->post('Tea_Password');
                $tadmin = $this->input->post('Tea_StaffAdmin');

                $result=$this->TeacherDB->update($tid, $tfname, $tlname, $tdob, $ttelhome, $ttelmob, $temail, $tpw, $tadmin);
                echo "<script language='javascript'>alert(\"$result\");location=\"teacher\"</script>";
            }
        }
    }


//Student Record Delete
    public function delete() {
        $tid=$this->input->get('Tea_ID');
        $result=$this->TeacherDB->delete($tid);
        echo "<script language='javascript'>alert(\"$result\");location=\"teacher\"</script>";
    }


}