<?php
class ReportController extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('ReportModel');
    }
    
    //Student-Subject Page Functions
    public function Report() {

        $dbresult['data']=$this->ReportModel->FetchStudent();
        $this->load->view('ReportView',$dbresult);
}
}
    