<?php
class studentclasscontroller extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('StudentClassModel');
    }
    
    //Student-Class Page Functions
    public function studentclass() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
        //Get All Distinct Years
            $dbresult['yearlist'] = $this->StudentClassModel->GetDropDownFields('yearlist');        
            $dbresult['keyword'] = $this->input->post('find');
            $dbresult['ColumnSelected'] = $this->input->post('searchtype');
            $dbresult['year'] = $this->input->post('year');

        //load table
            $dbresult['data']=$this->StudentClassModel->FetchStudentClassData($dbresult);
            $this->load->view('navbar');
            $this->load->view('studentclass',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
                $dbresult['ColumnSelected'] = '';
                $dbresult['year'] = '';
            }

        //Input button
            else if ($this->input->post('insertrecord')) {
                redirect("studentclasscontroller/insert");
            }

        //Find Students Button
            else if ($this->input->post('findstudents')) {
                //$dbresult['class'] = $this->input->post('class');
                $dbresult['year'] = $this->input->post('year');

                $dbresult['keyword'] = '';
                $dbresult['ColumnSelected'] = '';

                $dbresult['data']=$this->StudentClassModel->FetchStudentClassData($dbresult);
            }
                    //back button
            elseif ($this->input->post('back')) {
                redirect("studentclasscontroller/studentclass");
            }
        }

    }

    //Student-Class Record Insert
    public function insert() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $data['current']=$this->StudentClassModel->fetchstudentclassid();
            $data['classlist']=$this->StudentClassModel->GetDropDownFields('classlist');
            $data['admission_no']=$this->input->post('admission_no');
            $data['Stu_ID']=$this->input->post('Stu_ID');
            $data['Stu_Full_Name']=$this->input->post('Stu_Full_Name');
            $data['Stu_Init_Name']=$this->input->post('Stu_Init_Name');
            $data['record']=$this->StudentClassModel->fetchstudentclassrecord($data['admission_no']);
            $this->load->view('navbar');
            $this->load->view('insstudentclass',$data);

      //get student button
            if ($this->input->post('getstudent')) {
                $indexno = $this->input->post('admission_no');
                $data['record'] = $this->StudentClassModel->fetchstudentdata($indexno);
            }

        //Save Button
            if ($this->input->post('save')) {
                $scid = $this->input->post('StuCls_ID');
                $sid = $this->input->post('Stu_ID');
                $scyear = $this->input->post('year');
                $cid = $this->input->post('class');

                $threshold = $this->StudentClassModel->fetchclassthrehold($cid);
                $t="";
                foreach($threshold as $r) {
                    $t=$r->Cls_Threshold;
                }
                $studentcount = $this->StudentClassModel->studentcount($cid,$scyear);
                $c="";
                foreach($studentcount as $s){
                    $c=$s->COUNT;
                }

                if($c>=$t) {
                    $result = "Classroom limit reached. Please select another class";
                    echo "<script language='javascript'>alert(\"$result+$t\");location=\"insert\"</script>";         
                }
                else{

                    if(!empty($scid) && !empty($scyear) && !empty($sid) && !empty($cid)) {
                        $result = $this->StudentClassModel->insert($scid, $scyear, $sid, $cid);
                        echo "<script language='javascript'>alert(\"$result\");location=\"insert\"</script>";     
                    }
                }
            }
        }
    }


  //Student-Class Record Update
    public function update() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {

            $dbresult['classlist']=$this->StudentClassModel->GetDropDownFields('classlist');
            $id['keyword']=$this->input->get('StuCls_ID');
            $id['ColumnSelected']='tbl_student_class.StuCls_ID';
            $id['year']='';
            $dbresult['record']=$this->StudentClassModel->FetchUpdateData($id);
            $this->load->view('navbar');
            $this->load->view('updatestudentclass',$dbresult);
            if ($this->input->post('update')) {
                $scid = $this->input->post('StuCls_ID');
                $sid = $this->input->post('Stu_ID');
                $scyear = $this->input->post('StuCls_Year');
                $cid = $this->input->post('Cls_ID');

                if(!empty($scid) && !empty($scyear) && !empty($sid) && !empty($cid)) {
                    $result=$this->StudentClassModel->update($scid, $scyear, $sid, $cid);
                    echo "<script language='javascript'>alert(\"$result\");location=\"studentclass\"</script>";    
                }
            }
        }
    }


//Student-Class Record Delete
    public function delete() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }
        else {
            $sid=$this->input->get('StuCls_ID');
            $result=$this->StudentClassModel->delete($sid);
            echo "<script language='javascript'>alert(\"$result\");location=\"studentclass\"</script>";   
        }
    }

}