<?php
class classesandsubjectscontroller extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('classesandsubjectsdb');
    }
    

    //Class Page Functions
    public function class() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $dbresult['keyword'] = $this->input->post('find');

        //Class Load table
            $dbresult['data']=$this->classesandsubjectsdb->FetchClassData($dbresult);
            $this->load->view('navbar');
            $this->load->view('classespage',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
            }

        //Class Input button
            else if ($this->input->post('insertclass')) {
                redirect("classesandsubjectscontroller/insertclassrecord");
            }

        //Class Search Button
            else if ($this->input->post('findrecord')) {
            //Get the text value from the search box
                $dbresult['keyword'] = $this->input->post('find');

            //Send data to the classesandsubjectsdb
                $dbresult['data']=$this->classesandsubjectsdb->FetchClassData($dbresult);
            }

            elseif ($this->input->post('back')) {
                redirect("classesandsubjectscontroller/class");
            }
        }


    }


    //Class Record Insert
    public function insertclassrecord() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $clsid['current']=$this->classesandsubjectsdb->fetchclassid();
            $this->load->view('navbar');
            $this->load->view('insertclass',$clsid);

            if ($this->input->post('savedata')) {
                $cid = $this->input->post('Cls_ID');
                $cname = $this->input->post('Cls_Name');
                $cgrade = $this->input->post('Cls_Grade');
                $cthreshold = $this->input->post('Cls_Threshold');
                $result=$this->classesandsubjectsdb->insertclassrecord($cid, $cname, $cgrade, $cthreshold);
                echo "<script language='javascript'>alert(\"$result\");location=\"class\"</script>";
            }
        }
    }


  //Class Record Update
    public function updateclassrecord() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {

            $id=$this->input->get('Cls_ID');
            $dbresult['record']=$this->classesandsubjectsdb->fetchclassrecord($id);

            $this->load->view('navbar');
            $this->load->view('updateclass',$dbresult);
            if ($this->input->post('update')) {
                $cid = $this->input->post('Cls_ID');
                $cname = $this->input->post('Cls_Name');
                $cgrade = $this->input->post('Cls_Grade');
                $cthreshold = $this->input->post('Cls_Threshold');
                $result=$this->classesandsubjectsdb->updateclassrecord($cid, $cname, $cgrade, $cthreshold);
                echo "<script language='javascript'>alert(\"$result\");location=\"class\"</script>";
            }
        }
    }


//Class Record Delete
    public function deleteclassrecord() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {

            $cid=$this->input->get('Cls_ID');
            $this->classesandsubjectsdb->deleteclassrecord($cid);
            redirect("classesandsubjectscontroller/class");
        }

    }



 //Subject Page Functions
    public function subject() {

        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {

            $dbresult['keyword'] = $this->input->post('find');

        //Subject Load table
            $dbresult['data']=$this->classesandsubjectsdb->FetchSubjectData($dbresult);
            $this->load->view('navbar');
            $this->load->view('subjectspage',$dbresult);

        //clear button
            if ($this->input->post('clearsearch')) {
                $dbresult['keyword']="";
            }

        //Subject Input button
            else if ($this->input->post('insertsubject')) {
                redirect("classesandsubjectscontroller/insertsubjectrecord");
            }

        //Subject Search Button
            else if ($this->input->post('findrecord')) {
            //Get the text value from the search box
                $dbresult['keyword'] = $this->input->post('find');

            //Send data to the classesandsubjectsdb
                $dbresult['data']=$this->classesandsubjectsdb->FetchSubjectData($dbresult);
            }
            elseif ($this->input->post('back')) {
                redirect("classesandsubjectscontroller/subject");
            }
        }
    }


    //Subject Record Insert
    public function insertsubjectrecord() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {

            $subid['current']=$this->classesandsubjectsdb->fetchsubjectid();
            $this->load->view('navbar');
            $this->load->view('insertsubject',$subid);

            if ($this->input->post('savedata')) {
                $subid = $this->input->post('Sub_ID');
                $subname = $this->input->post('Sub_Name');
                $result=$this->classesandsubjectsdb->insertsubjectrecord($subid, $subname);
                echo "<script language='javascript'>alert(\"$result\");location=\"subject\"</script>";
            }
        }
    }


  //Subject Record Update
    public function updatesubjectrecord() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $id=$this->input->get('Sub_ID');
            $dbresult['record']=$this->classesandsubjectsdb->fetchsubjectrecord($id);

            $this->load->view('navbar');
            $this->load->view('updatesubject',$dbresult);
            if ($this->input->post('update')) {
                $subid = $this->input->post('Sub_ID');
                $subname = $this->input->post('Sub_Name');
                $result=$this->classesandsubjectsdb->updatesubjectrecord($subid, $subname);
                echo "<script language='javascript'>alert(\"$result\");location=\"subject\"</script>";
            }
        }
    }


//Subject Record Delete
    public function deletesubjectrecord() {
        if($_SESSION["isadmin"]=="No") {
            $this->load->view('navbar');
            $this->load->view('errorpage');
        }

        else {
            $subid=$this->input->get('Sub_ID');
            $this->classesandsubjectsdb->deletesubjectrecord($subid);
            redirect("classesandsubjectscontroller/subject");
        }
    }
}
