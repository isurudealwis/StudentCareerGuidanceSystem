<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
</head>


<body id="page-top" class="body">
    <form method="post" action="<?php echo base_url() . 'index.php/main/loadmain' ?>">
        <div class="container-fluid">
            <div class="d-sm-flex justify-content-between align-items-center mb-6">
                
                <h3 class="text-dark mb-0">Dashboard</h3>
                <h5 class="text-dark mb-0">Current User: <?php echo $_SESSION['userfname'] . " " . $_SESSION['userlname'] ?></h5>
            </div>

            <div class="row">
                <?php if($_SESSION['isadmin']=="Yes") {?>
                    <div class="col-md-6 col-xl-3 mb-4">
                        <div class="card shadow border-start-primary py-2">
                            <div class="card-body">
                                <div class="row align-items-center no-gutters">
                                    <div class="col me-2">
                                        <input type="submit" name="students" value="students" class="btn btn-primary">
                                        <div class="text-dark fw-bold h6 mb-0"><span>Manage Students Details</span></div>
                                    </div>
                                    <div class="col-auto"><i class="fas fa-calendar fa-2x text-gray-300"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }?>
                <?php if($_SESSION['isadmin']=="Yes") {?>
                    <div class="col-md-6 col-xl-3 mb-4">
                        <div class="card shadow border-start-success py-2">
                            <div class="card-body">
                                <div class="row align-items-center no-gutters">
                                    <div class="col me-2">
                                        <input type="submit" name="classes" value="Classes" class="btn btn-warning">
                                        <input type="submit" name="subjects" value="Subjects" class="btn btn-warning">
                                        <div class="text-dark fw-bold h6 mb-0"><span>Manage Classes and Subjects</span></div>
                                    </div>
                                    <div class="col-auto"><i class="fas fa-dollar-sign fa-2x text-gray-300"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }?>
                <?php if($_SESSION['isadmin']=="Yes") {?>
                    <div class="col-md-6 col-xl-3 mb-4">
                        <div class="card shadow border-start-success py-2">
                            <div class="card-body">
                                <div class="row align-items-center no-gutters">
                                    <div class="col me-2">
                                        <input type="submit" name="teachers" value="teachers" class="btn btn-warning">
                                        <input type="submit" name="teachersubject" value="Assign Subjects" class="btn btn-success">
                                        <div class="text-dark fw-bold h6 mb-0"><span>Manage Teachers Details</span></div>
                                    </div>
                                    <div class="col-auto"><i class="fas fa-dollar-sign fa-2x text-gray-300"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }?>
                <?php if($_SESSION['isadmin']=="Yes") {?>
                    <div class="col-md-6 col-xl-3 mb-4">
                        <div class="card shadow border-start-success py-2">
                            <div class="card-body">
                                <div class="row align-items-center no-gutters">
                                    <div class="col me-2">
                                        <input type="submit" name="studentclass" value="Assign Students to Classes" class="btn btn-success">
                                        <input type="submit" name="studentsubject" value="Assign Students to Subjects" class="btn btn-warning">
                                        <div class="text-dark fw-bold h6 mb-0"><span>Assignments</span></div>
                                    </div>
                                    <div class="col-auto"><i class="fas fa-dollar-sign fa-2x text-gray-300"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }?>
                <div class="col-md-6 col-xl-3 mb-4">
                    <div class="card shadow border-start-info py-2">
                        <div class="card-body">
                            <div class="row align-items-center no-gutters">
                                <div class="col me-2">
                                    <?php if($_SESSION['isadmin']=="Yes") {?>
                                        <input type="submit" name="examinations" value="Examinations" class="btn btn-primary">
                                    <?php }?>
                                    <input type="submit" name="marks" value="Marks Management" class="btn btn-secondary">
                                    <div class="row g-0 align-items-center">
                                        <div class="col-auto">
                                            <div class="text-dark fw-bold h6 mb-0"><span>Manage Examinations</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-auto"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($_SESSION['isadmin']=="Yes") {?>
                    <div class="col-md-6 col-xl-3 mb-4">
                        <div class="card shadow border-start-warning py-2">
                            <div class="card-body">
                                <div class="row align-items-center no-gutters">
                                    <div class="col me-2">
                                       <input type="submit" name="multipleintel" value="Multiple Intelligences" class="btn btn-danger">
                                       <div class="text-dark fw-bold h6 mb-0"><span>Manage Multiple Intelligences</span></div>
                                   </div>
                                   <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                               </div>
                           </div>
                       </div>
                   </div>
               <?php }?>
               <div class="col-md-6 col-xl-3 mb-4">
                <div class="card shadow border-start-warning py-2">
                    <div class="card-body">
                        <div class="row align-items-center no-gutters">
                            <div class="col me-2">
                                <?php if($_SESSION['isadmin']=="Yes") {?>
                                    <input type="submit" name="behactivities" value="Manage Behavioural Activities" class="btn btn-primary">
                                <?php }?>
                                <input type="submit" name="behactassignment" value="Assign Behavioural Activities" class="btn btn-secondary">
                                <div class="text-dark fw-bold h6 mb-0"><span>Manage Behavioural Activities</span></div>
                            </div>
                            <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($_SESSION['isadmin']=="Yes") {?>
              <div class="col-md-6 col-xl-3 mb-4">
                <div class="card shadow border-start-warning py-2">
                    <div class="card-body">
                        <div class="row align-items-center no-gutters">
                            <div class="col me-2">
                                <input type="submit" name="HigherStudies" value="Manage Higher Studies" class="btn btn-primary">
                                <input type="submit" name="CareerOptions" value="Manage Career Options" class="btn btn-danger">
                                <div class="text-dark fw-bold h6 mb-0"><span>Manage Higher Education and Career Options</span></div>
                            </div>
                            <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }?>

        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-warning py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <input type="submit" name="StudentReport" value="Get Student Report" class="btn btn-primary">
                            <hr>
                            <?php if($_SESSION['isadmin']=="Yes") {?>
                                <input type="submit" name="TeacherReport" value="Get Teacher Evaluation Report" class="btn btn-secondary">
                                <input type="submit" name="SummaryTeacherReport" value="Summary Teachers Report" class="btn btn-secondary">
                            <?php }?>
                            <input type="submit" name="SummaryStudentReport" value="Summary Students Report" class="btn btn-secondary">
                            <div class="text-dark fw-bold h6 mb-0"><span>Generate Reports</span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="bg-white sticky-footer">
    <div class="container my-auto">
        <div class="text-center my-auto copyright"><span>MIT3201 Project - W I S J DE ALWIS</span></div>
    </div>
</footer>
<div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
</div>
</form>
</body>
</html>