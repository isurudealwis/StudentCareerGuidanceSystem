
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<nav class="navbar navbar-expand-lg navbar-light bg-light justify-content-between py-2">

  <form method="post" action="<?php echo base_url() . 'index.php/main/loadmain' ?>">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
      
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <input type="submit" name="home" value="Home" class="dropdown-item">

      <?php if($_SESSION['isadmin']=="Yes") {?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Classes & Subjects</a>
        
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <input type="submit" name="classes" value="Manage Classes" class="dropdown-item">
          <div class="dropdown-divider"></div>
          <input type="submit" name="subjects" value="Manage Subjects" class="dropdown-item">
        </div>
      </li>
    <?php }?>


     <?php if($_SESSION['isadmin']=="Yes") {?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Students</a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <input type="submit" name="students" value="Manage Student Details" class="dropdown-item">
          <div class="dropdown-divider"></div>
          <input type="submit" name="studentclass" value="Assign Students to Classes" class="dropdown-item">
          <input type="submit" name="studentsubject" value="Assign Students to Subjects" class="dropdown-item">
        </div>
      </li>
    <?php }?>


      <?php if($_SESSION['isadmin']=="Yes") {?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Teachers</a>
        
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <input type="submit" name="teachers" value="Manage Teacher Details" class="dropdown-item">
          <div class="dropdown-divider"></div>
          <input type="submit" name="teachersubject" value="Assign Teachers to Subjects" class="dropdown-item">
        </div>
      </li>
    <?php }?>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Examinations</a>
        
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <?php if($_SESSION['isadmin']=="Yes") {?>
          <input type="submit" name="examinations" value="Manage Examinations" class="dropdown-item">
          <div class="dropdown-divider"></div>
        <?php }?>
          <input type="submit" name="marks" value="Manage Marks" class="dropdown-item">
        </div>
      </li>

      <?php if($_SESSION['isadmin']=="Yes") {?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Multiple Intelligences</a>
        
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <input type="submit" name="multipleintel" value="Manage Multiple Intelligences" class="dropdown-item">
        </div>
      </li>
      <?php }?>


      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Behavioural Activities</a>
        
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <?php if($_SESSION['isadmin']=="Yes") {?>
          <input type="submit" name="behactivities" value="Manage Behavioural Activities" class="dropdown-item">
          <div class="dropdown-divider"></div>
        <?php }?>
          <input type="submit" name="behactassignment" value="Assign Behavioural Activities to Students" class="dropdown-item">
        </div>
      </li>


      <?php if($_SESSION['isadmin']=="Yes") {?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Higher Studies & Career Options</a>
        
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <input type="submit" name="HigherStudies" value="Manage Higher Studies" class="dropdown-item">
          <div class="dropdown-divider"></div>
          <input type="submit" name="CareerOptions" value="Manage Career Options" class="dropdown-item">
        </div>
      </li>
    <?php }?>


      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Reports</a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <input type="submit" name="StudentReport" value="Get Student Report" class="dropdown-item">
      <?php if($_SESSION['isadmin']=="Yes") {?>
          <input type="submit" name="TeacherReport" value="Get Teacher Report" class="dropdown-item">
        <?php }?>
          <div class="dropdown-divider"></div>
          <input type="submit" name="SummaryStudentReport" value="Summary Student Report" class="dropdown-item">
      <?php if($_SESSION['isadmin']=="Yes") {?>
          <input type="submit" name="SummaryTeacherReport" value="Summary Teacher Report" class="dropdown-item">
      <?php }?>
        </div>
      </li>
    </form>
    <div class="container"></div>
    <div class="container"></div>
    </ul>
    <form method="post" action="<?php echo base_url().'index.php/main/loadmain'?>">
      <input class="btn btn-outline-success my-2 my-sm-0" type="submit" name="logout" value="Log Out">
    </form>
  </div>

</nav>