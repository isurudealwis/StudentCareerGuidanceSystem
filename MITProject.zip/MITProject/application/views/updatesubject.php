
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Update Subject</title>
				    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Update Subject </h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<?php foreach($record as $r) {?>
						<form method="post" action="<?php echo base_url().'index.php/classesandsubjectscontroller/updatesubjectrecord'?>">
							<div class=".form-group">
								<table class="table table-borderless table-sm">
									<tbody>
										<div class="row">
											<tr>
												<div class="col">
													<td>Subject ID: </td>
												</div>
												<div class="col">
													<td><input type="text" name="Sub_ID" id="textfield2" value="<?php echo $r->Sub_ID?>" readonly class="form-control">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Subject Name</td>
												</div>
												<div class="col">
													<td><input type="text" name="Sub_Name" id="textfield2" value="<?php echo $r->Sub_Name?>" class="form-control" required>
													</td>
												</div>
											</tr>
										</div>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td width="250"><input type="submit" name="update" id="BUpdate" value="Update Record" class="btn btn-success" onclick="return confirm('Are you sure you want to update the Record? (Press OK to continue, Cancel to return.)')">
												</td>
											</div>
										</form>
										<div class="col">
											<form method="post" action="<?php echo base_url().'index.php/classesandsubjectscontroller/subject'?>">
												<td><input type="submit" name="back" id="BBack" value="Back" class="btn btn-secondary">
												</td>
											</form>
										</div>
									</tr>
								</div>
							</tbody>
						</table>
					</div>
				</form>
			<?php } ?>
		</div>
		<div class="col"></div>
	</div>
</div>
</body>

</html>