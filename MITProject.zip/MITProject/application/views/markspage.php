<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Examination Marks</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

	</head>

	<body>
		<div class="container">
			<div class="row">
				<hr>
				<div class="col">

					<h2>Examination Marks Page</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/markscontroller/marks'?>">
					</div>
				</div>
			</div>
			<hr>

			<div class="container">
				<div class="row">
					<div class="col">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Select Year</td>
											</div>
											<div class="col">
												<td><select name="Year" id="selectyear" class="form-control" required>
													<option value='' selected disabled>Select Year</option>
													<?php
													foreach ( $yearlist as $listitem ) {
														echo "<option value='" . $listitem->Exam_Year . "'>" . $listitem->Exam_Year . "</option>";
													}
													?>
												</select>
											</td>
										</div>
									</tr>
								</div>
								<div class="row">
										<tr>
											<div class="col">
												<td>Select Term</td>
											</div>
											<div class="col">
												<td><select name="Term" id="selectyear" class="form-control" required>
													<option value='' selected disabled>Select Term</option>
													<?php
													foreach ( $termlist as $listitem ) {
														echo "<option value='" . $listitem->Exam_Term . "'>" . $listitem->Exam_Term . "</option>";
													}
													?>
												</select>
											</td>
										</div>
									</tr>
								</div>
								<div class="row">
										<tr>
											<div class="col">
												<td>Select Class</td>
											</div>
											<div class="col">
												<td><select name="Class" id="selectyear" class="form-control" required>
													<option value='' selected disabled>Select Class</option>
													<?php
													foreach ( $classlist as $listitem ) {
														echo "<option value='" . $listitem->Cls_ID . "'>" . $listitem->Cls_Name . "</option>";
													}
													?>
												</select>
											</td>
										</div>
									</tr>
								</div>
								<div class="row">
										<tr>
											<div class="col">
												<td>Select Subject</td>
											</div>
											<div class="col">
												<td><select name="Subject" class="form-control" required>
													<option value='' selected disabled>Select Subject</option>
													<?php
													foreach ( $subjectlist as $listitem ) {
														echo "<option value='" . $listitem->Sub_ID . "'>" . $listitem->Sub_Name . "</option>";
													}
													?>
												</select>
											</td>
										</div>
									</tr>
								</div>
								<div class="row">
								<tr>
									<div class="col">
										<td>
											<input type="submit" name="getstudents" value="Get Students" class="btn btn-success">

								</tbody>
							</table>







								</div>



							</form>
						</body>
						</html>