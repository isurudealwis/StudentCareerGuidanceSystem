
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Update Student-Subject</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Update Student-Subject</h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form id="insertstudent" method="post" action="<?php echo base_url().'index.php/studentsubjectcontroller/update'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<tr>
												<div class="col">
													<td>Serial No: </td>
												</div>
												<div class="col">
													<td><input type="text" name="StuSub_ID" id="textfield2" value="<?php foreach ($record as $r) { echo $r->StuSub_ID;}?>" readonly class="form-control">
													</td>
												</div>
											</tr>
									<div class="row">
								<tr>
									<div class="col">
										<td>Student Admission No.</td>
									</div>
									<div class="col">
										<td><input type="text" name="Stu_Index_No" id="Stu_Index_No" value="<?php foreach ($record as $r) { echo $r->Stu_Index_No;}?>" class="form-control" readonly>
										</td>
									</div>
								</tr>
							</div>
							<div class="row">
								<tr>
									<div class="col">
										<td>Student ID</td>
									</div>
									<div class="col">
										<td><input type="text" name="Stu_ID" id="textfield2" value="<?php foreach ($record as $r) { echo $r->Stu_ID;}?>" class="form-control" readonly required>
										</td>
									</div>
								</tr>
							</div>

							<div class="row">
								<tr>
									<div class="col">
										<td>Student Full Name</td>
									</div>
									<div class="col">
										<td><input type="text" name="Stu_Full_Name" id="textfield2" value="<?php foreach ($record as $r) { echo $r->Stu_Full_Name;}?>" class="form-control" readonly>
										</td>
									</div>
								</tr>
							</div>
							<div class="row">
								<tr>
									<div class="col">
										<td>Name with Initials</td>
									</div>
									<div class="col">
										<td><input type="text" name="Stu_Init_Name" id="textfield2" value="<?php foreach ($record as $r) { echo $r->Stu_Init_Name;}?>" class="form-control" readonly>
										</td>
									</div>
								</tr>
							</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Year</td>
											</div>
											<div class="col">
												<div class="col">
												<td><select name="StuSub_Year" class="form-control">
													<option value="" disabled required>Select the year</option>
													<?php
													$c=date("Y");
													while($c>=date("Y")-14)
													{
														foreach ($record as $r) {
															if ($r->StuSub_Year==$c) {
																echo "<option value='".$c."' selected>".$c."</option>;";		
															}
															else {
																echo "<option value='".$c."'>".$c."</option>;";
															}
														}
														$c--;
													}
													?>
												</select>
											</td>
											</div>
										</div>
									</tr>
								</div>
								<div class="row">
									<tr>
										<div class="col">
											<td>Select Subject</td>
										</div>
										<div class="col">
											<td><select name="Sub_ID" class="form-control">
												<option value='' selected disabled required>Subject</option>
												<?php
												foreach ( $subjectlist as $listitem ) {
													foreach ($record as $r) {
														if ($listitem->Sub_ID == $r->Sub_ID) {
														echo "<option value='" . $listitem->Sub_ID . "' selected>" . $listitem->Sub_Name . "</option>";	
													}
													else {
														echo "<option value='" . $listitem->Sub_ID . "'>" . $listitem->Sub_Name . "</option>";
													}
												}
												}
												?>
											</select>
										</td>
									</div>
								</tr>
							</div>
						</div>
						<div class="row">
							<tr>
								<div class="col">
										<td></td>
									</div>
									<div class="col">
										<td width="600"><input type="submit" name="update" id="BUpdate" value="Update Record" class="btn btn-success" onclick="return confirm('Are you sure you want to update the Record? (Press OK to continue, Cancel to return.)')">

										</td>
									</div>
								</form>
								<form method="post" action="<?php echo base_url().'index.php/studentsubjectcontroller/studentsubject'?>">
									<div class="col">
										<td width="100"><input type="submit" name="back" value="Back" class="btn btn-secondary">
										</td>
									</div>
								</form>
							</tr>
						</div>
					</tbody>
				</table>
			</div>
		</form>

		<script>
		</script>
	</body>
	</html>