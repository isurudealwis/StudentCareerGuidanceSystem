<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Multiple Intelligences Management</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
				document.getElementById("selecttype").value="";
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Multiple Intelligences Management</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/MultipleIntelligencesController/multipleintelligences'?>">
					</div>
				</div>
				<div class="row"><br><hr></div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col">
						<input type="text" class="form-control" name="keyword" placeholder="Enter Keyword..." value="<?php echo $_SESSION['keyword'] ?>">
					</div>
					<div class="col-sm-3">
						<select name="column" class="form-control">
							<option value=''>From Entire Table</option>
							<option value='MulInt_ID'>Multiple Intelligence ID</option>
							<option value='MulInt_Name'>Multiple Intelligence Name</option>
							<option value='MulInt_Desc'>Multiple Intellignece Description</option>
						</select>
					</div>
					<div class="col">
						<input type="submit" name="find" value="Find Record" class="btn btn-primary"> </div>
						<div class="col">
							<input type="submit" name="clear" value="Clear Search" class="btn btn-light" onclick="cleartabs()"></div>
							<div class="col">
								<input type="submit" name="insert" value="Insert Record" class="btn btn-primary"> </div>
							</div>
						</div>
					</form>
						<hr>
						<div class="container">
							<div class="form-group">
								<div class="table-responsive-sm">
									<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
										<thead class="thead-dark">
											<tr>
												<th scope="col">Mult.Int. ID</th>
												<th scope="col">Name</th>
												<th scope="col">Description</th>
												<th scope="col" colspan="2">Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(empty($data)) {
												echo "<td> No record found. </td>";
											}
											else {
												foreach ( $data as $row ) {?>
													<?php echo "<tr>";
													echo "<td scope=\"row\">" . $row->MulInt_ID . "</td>";
													echo "<td>" . $row->MulInt_Name . "</td>";
													echo "<td>" . $row->MulInt_Desc . "</td>";
													echo "<td><a href='update?MulInt_ID=".$row->MulInt_ID."'>
													<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></td>";
													echo "<td><a href='delete?MulInt_ID=".$row->MulInt_ID."'>
													<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->MulInt_ID."?')) {return false}\"></a></td>";
													echo "</tr>";
												}
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</form>
				</body>
				</html>

?>