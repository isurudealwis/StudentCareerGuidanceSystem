
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Insert Student Record</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4 class="h2">Insert Student Record</h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
						<form method="post" action="<?php echo base_url().'index.php/studentscontroller/insert'?>">
							<div class=".form-group">
								<table class="table table-borderless table-sm">
									<tbody>
										<div class="row">
											<tr>
												<div class="col">
													<td>Serial No: </td>
												</div>
												<div class="col">
													<?php
													if(empty($current)) {
													$newid='S0001';
												}
												else {
													foreach($current as $r)
													{
														$id=substr($r->Stu_ID,1);
     													$newvalue=$id+1;
     													$newid='S'.str_pad($newvalue,4,"0",STR_PAD_LEFT);
     												}
     											}?>
													<td><input type="text" name="Stu_ID" id="txt_Stu_ID" value="<?php echo $newid?>" readonly class="form-control">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Student Full Name</td>
												</div>
												<div class="col">
													<td><input type="text" name="Stu_Full_Name" id="txt_Stu_FullName" value="" class="form-control" required placeholder="Ex: AARACHCHIGE RANUKA SANJEEWA">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Student Name with Initials</td>
												</div>
												<div class="col">
													<td><input type="text" name="Stu_Init_Name" id="txt_Stu_InitName" value="" class="form-control" required placeholder="Ex: A R SANJEEWA">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Student Admission No.</td>
												</div>
												<div class="col">
													<td><input type="text" name="Stu_Index_No" id="Stu_AdmNo" value="" class="form-control" required maxlength='5' minlength='5' placeholder="Ex: 12345">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Date of Birth</td>
												</div>
												<div class="col">
													<td><input type="date" name="Stu_DOB" id="Stu_DOB" value="" min='2000-01-01' max='' class="form-control" required>
													</td>
												</div>
											</tr>
										</div>

										<div class="row">
											<tr>
												<div class="col">
													<td>Telephone No. (Home)</td>
												</div>
												<div class="col">
													<td><input type="tel" name="Stu_Home_Tel" id="txt_Stu_HomeTel" value="" pattern="[0-9]{9}" class="form-control" required maxlength="9" placeholder="Ex: 112345678">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Telephone No. (Mobile)</td>
												</div>
												<div class="col">
													<td><input type="tel" name="Stu_Mobile_Tel" id="txt_Stu_MobTel" value="" pattern="[0-9]{9}" class="form-control" required maxlength="9" placeholder="Ex: 777123456">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Email Address</td>
												</div>
												<div class="col">
													<td><input type="text" name="Stu_Email" id="txt_StuEmail" value="" class="form-control" required placeholder="Ex: abc@gmail.com">
													</td>
												</div>
											</tr>
										</div>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td width="250"><input type="submit" name="save" id="BInsert" value="Insert Record" class="btn btn-success" onclick="return confirm('Are you sure you want to add the Record? (Press OK to continue, Cancel to return.)')">
												</td>
											</div>
											<div class="col">
												<td width="400"><input type="reset" class="btn btn-secondary">
												</td>
											</div>
										</form>
										<div class="col">
											<form method="post" action="<?php echo base_url().'index.php/studentscontroller/student'?>">
												<td><input type="submit" name="back" id="BBack" value="Back" class="btn btn-secondary">
												</td>
											</form>
										</div>
										</tr>
									</div>
								</tbody>
							</table>
						</div>
			</div>
			<div class="col"></div>
		</div>
	</div>
</body>
</html>

<script type="text/javascript">
	var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
   dd = '0' + dd;
}

if (mm < 10) {
   mm = '0' + mm;
} 
    
today = yyyy + '-' + mm + '-' + dd;
document.getElementById("Stu_DOB").setAttribute("max", today);
</script>