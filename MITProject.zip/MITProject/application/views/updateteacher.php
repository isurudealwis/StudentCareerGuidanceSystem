
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Update Teacher Record</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Update Teacher Record </h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<?php foreach($record as $r) {?>
						<form method="post" action="<?php echo base_url().'index.php/teacherscontroller/update'?>">
							<div class=".form-group">
								<table class="table table-borderless table-sm">
									<tbody>
										<div class="row">
											<tr>
												<div class="col">
													<td>Serial No: </td>
												</div>
												<div class="col">
													<td><input type="text" name="Tea_ID" id="textfield2" value="<?php echo $r->Tea_ID?>" readonly class="form-control">
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>First Name</td>
												</div>
												<div class="col">
													<td><input type="text" name="Tea_First_Name" id="textfield2" value="<?php echo $r->Tea_First_Name?>" class="form-control" required>
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Last Name</td>
												</div>
												<div class="col">
													<td><input type="text" name="Tea_Last_Name" id="textfield2" value="<?php echo $r->Tea_Last_Name?>" class="form-control" required>
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>NIC No.</td>
												</div>
												<div class="col">
													<td><input type="text" name="Tea_NIC_No" id="textfield2" value="<?php echo $r->Tea_NIC_No?>" class="form-control" disabled>
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Date of Birth</td>
												</div>
												<div class="col">
													<td><input type="date" name="Tea_DOB" id="textfield2" value="<?php echo $r->Tea_DOB?>" class="form-control" required>
													</td>
												</div>
											</tr>
										</div>

										<div class="row">
											<tr>
												<div class="col">
													<td>Telephone No. (Home)</td>
												</div>
												<div class="col">
													<td><input type="text" name="Tea_Home_Tel" id="textfield2" value="<?php echo $r->Tea_Home_Tel?>" class="form-control" maxlength="9" required>
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Telephone No. (Mobile)</td>
												</div>
												<div class="col">
													<td><input type="text" name="Tea_Mobile_Tel" id="textfield2" value="<?php echo $r->Tea_Mobile_Tel?>" class="form-control" maxlength="9" required>
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Email Address</td>
												</div>
												<div class="col">
													<td><input type="email" name="Tea_Email" id="textfield2" value="<?php echo $r->Tea_Email?>" class="form-control" required>
													</td>
												</div>
											</tr>
										</div>
										<div class="row">
												<tr>
													<div class="col">
														<td>New Password</td>
													</div>
													<div class="col">
														<td><input type="password" name="Tea_Password" id="txt_TeaPW" value="" class="form-control" placeholder="(Leave blank to keep the current password)" minlength="5">
														</td>
													</div>
												</tr>
											</div>
										<div class="row">
											<tr>
												<div class="col">
													<td>Staff Admin?</td>
												</div>
												<div class="col">
													<td><select name="Tea_StaffAdmin" id="select" class="form-control" required>
														<?php
														if($r->Tea_StaffAdmin === 'Yes' ) {
															echo "<option value='Yes' selected>Yes</option>
															<option value='No'>No</option>";
														}
														else {
															echo "<option value='No' selected>No</option><option value='Yes'>Yes</option>";
														}
														?>
													</select>
												</td>
											</div>
										</tr>
									</div>
								</div>
								<div class="row">
									<tr>
										<div class="col">
										
									</div>
									<div class="col">
										<td width="100"><input type="submit" name="update" id="BUpdate" value="Update Record" class="btn btn-success" onclick="return confirm('Are you sure you want to update the Record? (Press OK to continue, Cancel to return.)')">
										</td>
									</div>
								</form>
								<form method="post" action="<?php echo base_url().'index.php/teacherscontroller/teacher'?>">
									<div class="col">
										<td width="100"><input type="submit" name="back" value="Back" class="btn btn-secondary">
										</td>
									</div>
								</form>
									</tr>
								</div>
							</tbody>
						</table>
					</div>
				</form>
			<?php } ?>
		</div>
		<div class="col"></div>
	</div>
</div>
</body>

</html>