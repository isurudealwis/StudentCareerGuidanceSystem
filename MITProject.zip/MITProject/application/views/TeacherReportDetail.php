<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Teacher Detail Report</title>

		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>

		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>   


<!-- To Show the 1st Overall Productivity Score Chart -->
		<script type="text/javascript">
			google.charts.load('current', {'packages':['gauge']});
			google.charts.setOnLoadCallback(drawChart);

			function drawChart() {
				var data = google.visualization.arrayToDataTable([
					['Label', 'Value'],
					['Overall', <?php foreach($OverallPerformance as $r) {echo $r->MARKS_AVERAGE;}?>]
					]);

				var options = {
					width: 600, height: 180,
					redFrom: 0, redTo: 40,
					yellowFrom:40, yellowTo: 70,
					greenFrom:70, greenTo: 100,
					minorTicks: 5
				};

				var chart = new google.visualization.Gauge(document.getElementById('overall_performance'));
				chart.draw(data, options);
			}
		</script>


<!--To show the Yearly Performance Chart -->
<script type="text/javascript">
			google.charts.load('current', {'packages':['corechart']});
			google.charts.setOnLoadCallback(drawVisualization);

			function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
        	['Year', 'Score (Average)'],
        	<?php foreach($YearlyPerformance as $Y) {
        		echo "['".$Y->Exam_Year."', ".$Y->MARKS_AVERAGE."],";	} ?>
        		]);

        var options = {
        	title : 'Yearly Performance (Last 5 years)',
        	vAxis: {title: 'Score (Average)', maxValue: 100, minValue: 0},
        	hAxis: {title: 'Year'},
        	seriesType: 'bars',
        	series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('Yearly_Performance'));
        chart.draw(data, options);
      }
    </script>

<!--To show the subject-wise performance -->
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Year' <?php foreach($DistinctSubjects as $DS) {echo ",'".$DS->SUBJECT_NAME."'";}?>],
          <?php foreach($YearTerm as $Y) {
          		echo "['".$Y->EXAM_YEAR." - ".$Y->Exam_Term."'";
          		foreach($DistinctSubjects as $DS) {
          			foreach($L3EP2 as $LP) {
           	if($Y->EXAM_YEAR==$LP->EXAM_YEAR && $Y->Exam_Term == $LP->Exam_Term && $DS->Sub_ID==$LP->Sub_ID) {
           		echo ",".$LP->AVERAGE_MARKS." ";}}}echo "],";
          	}?>
          	
        ]);

        var options = {
          title: 'Subject-wise Performance',
          vAxis: {title: 'Year/Term'},
          hAxis: {title: 'Score'},
          seriesType: 'bars',
          series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('L3YP2History'));
        chart.draw(data, options);
      }
    </script>


<!-- To show the Multiple Intelligence Performance Chart -->
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year' <?php foreach($DistinctMI as $MI) {echo ",'".$MI->MulInt_Name."'";}?>],
          <?php foreach($DistinctYear as $Y) {echo "['".$Y->Exam_Year."'";?>
           <?php foreach($DistinctMI as $MI) {
           foreach($MIAttributes as $AT) {
           	if($Y->Exam_Year==$AT->Exam_Year && $MI->MulInt_ID==$AT->MulInt_ID) {
           		echo ",".$AT->AVERAGE_SCORE." ";}}}echo "],";}
           		?>
        ]);

        var options = {
          title: 'Multiple Intelligence Performance',
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0, maxValue: 100}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('MIHistory'));
        chart.draw(data, options);
      }
    </script>
		
<!-- To show the Multiple Intelligence Attributes chart -->
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Multiple Intelligence Type', 'Score (Average)'],
          <?php foreach ($DistinctMI as $MI) {
          	echo "['".$MI->MulInt_Name."',".$MI->AVERAGE_SCORE."],";}?>
          
        ]);

        var options = {
          title: 'Multiple Intelligence Attributes'
        };

        var chart = new google.visualization.PieChart(document.getElementById('MIAttributes'));

        chart.draw(data, options);
      }
    </script>




  </head>

  <body>
  	<div class="container">
  		<div class="row">
  			<div class="col">
  				<h2 align="center">Teacher Detail Report</h2>
  			</div>
  			<div class="col">
  				<form method="post" action="<?php echo base_url().'index.php/TeacherReportController/ShowReport'?>">
  					<input type="submit" name="back" value="Back" class="btn btn-primary">
  				</div>
  			</div>
  		</div>
  		<hr>

  		<div class="container">
  			<div class="row">
  				<h3>Overall Result</h3>
  			</div>
  			<div class="row">
  				<table class="table table-striped table-hover">
  					<tbody>
  						<?php foreach ($Teacher_Details as $r) {
  							echo "<tr><td>Teacher ID</td><td><strong><em>".$r->Tea_ID."</em></strong></td>";
  							echo "<td>First Name</td><td><strong><em>".$r->Tea_First_Name."</em></strong></td></tr>";
  							echo "<tr><td>Last Name</strong></td><td><strong><em>".$r->Tea_Last_Name."</em></strong></td>";
  							echo "<td>E-mail</strong></td><td><strong><em>".$r->Tea_Email."</em></strong></td></tr>";
  						}?>
  					</tbody>
  				</table>
  			</div>
  			<hr>
  			<div class="row">
  				<div class="col">
  					<h4 class="display-6">Overall Productivity Score</h4>
  				</div>
  				<div class="col">
  					<?php foreach($OverallPerformance as $r) {
  						echo "<h5 class=\"display-6\">".$r->MARKS_AVERAGE."%</h5>";}?>
  					</div>
  					<div class="col">
  						<?php foreach($OverallPerformance as $r) {
  							if ($r->MARKS_AVERAGE<=40) {
  								echo "<h5 class=\"text-danger display-6\">Low</h5>"; }
  								else if ($r->MARKS_AVERAGE<=70) {
  									echo "<h5 class=\"text-warning display-6\">Medium</h5>";}
  									else {echo"<h5 class=\"text-success display-6\">High</h5>";}
  								} ?>
  							</div>
  							<div class="col">
  								<div id="overall_performance" style="width: 400px; height: 120px;"></div>
  							</div>
  						</div>
  						<br>
  						<hr>
  					</div>

  					<div class="container bg-light text-black rounded" >
  						<div class="row">
  							<div class="col">
  								<h6 class="display-6" align="center">Yearly Performance</h6>
  							</div>
  						</div>
  						<div class="row">
  							<div class="col">
  								<table class="table table-bordered table-sm table-primary">
  									<thead>
  										<tr>
  											<th scope="col">Year</th>
  											<th scope="col">Score</th>
  										</tr>
  									</thead>
  									<tbody>
  										<?php foreach ($YearlyPerformance as $s) {
  											echo "<tr> <th scope=\"row\">".$s->Exam_Year."</th><td class=\"table-info\">".$s->MARKS_AVERAGE."</td></tr>";
  										}?>
  									</tbody>
  								</table>
  							</div>
  							<div class="col">
  								<div id="Yearly_Performance" style="width: 400px; height: 250px;"></div>
  							</div>
  						</div>
  						<br>
  						<div class="row">
  							<div class="col">
  								<h6 class="display-6">Last Year Performance</h6>
  							</div>
  							<div class="col">
  								<h6 class="display-6">Subjects Teach</h6>
  							</div>
  						</div>
  						<div class="row">
  							<div class="col">
  								<table class="table table-bordered table-sm table-primary">
  									<thead>
  										<tr>
  											<th scope="col">Year + Term</th>
  											<th scope="col">Subject</th>												
  											<th scope="col">Average</th>
  										</tr>
  									</thead>
  									<tbody>
  										<?php foreach ($L3EP as $s) {
  											echo "<tr> <th scope=\"row\">".$s->EXAM_YEAR." - Term ".$s->Exam_Term."</th><td scope=\"row\">".$s->SUBJECT_NAME."</td><td>".$s->AVERAGE_MARKS."</td></tr>";
  										}?>
  									</tbody>
  								</table>
  							</div>
  							<div class="col">
  								<table class="table table-bordered table-sm table-primary">
  									<tbody>
  										<?php foreach ($DistinctSubjects as $s) {
  											echo "<tr><td>".$s->SUBJECT_NAME."</td></tr>";
  										}?>
  									</tbody>
  								</table>
  							</div>
  						</div>
  					</div>
  					<hr>
  					<div class="container bg-light text-black rounded">
  						<div class="row">
  							<div class="col">
  								<h6 class="display-6" align="center">Subject-wise Performance</h6>
  							</div>
  						</div>
  						<div class="row">
  							<div class="col">
  								<table class="table table-success table-hover table-sm">
  									<thead class="thead-dark">
  										<tr>
  											<th scope="col">Year</th>
  											<th scope="col">Term</th>
  											<th scope="col">Subject</th>
  											<th scope="col">score %</th>
  										</tr>
  									</thead>
  									<tbody>
  										<?php foreach ($L3EP2 as $r) {
  											echo "<tr><td>" . $r->EXAM_YEAR . "</td>";
  											echo "<td>" . $r->Exam_Term . "</td>";
  											echo "<td>" . $r->SUBJECT_NAME . "</td>";
  											echo "<td>" . $r->AVERAGE_MARKS . "</td></tr>";
  										}?>
  									</tbody>
  								</table>
  							</div>
  							<div class="col">
  								<div id="L3YP2History" style="width: 100%; height: 250px;"></div>
  								</div>
  							</div>
  						</div>



  						<hr>



  						<div class="container">
  						<div class="row">
  							<div class="col">
  								<h6 class="display-6" align="center">Multiple Intelligence Performance</h6>
  							</div>
  						</div>
  						<div class="row">
  							<div class="col">
  								<table class="table table-success table-hover table-sm">
  									<thead class="thead-dark">
  										<tr>
  											<th scope="col">Year</th>
  											<th scope="col">ID</th>
  											<th scope="col">Multiple Intelligence Score</th>
  											<th scope="col">Score</th>
  										</tr>
  									</thead>
  									<tbody>
  										<?php foreach ($MIAttributes as $r) {
  											echo "<tr><td>" . $r->Exam_Year . "</td>";
  											echo "<td>" . $r->MulInt_ID . "</td>";
  											echo "<td>" . $r->MulInt_Name . "</td>";
  											echo "<td>" . $r->AVERAGE_SCORE . "</td></tr>";
  										}?>
  									</tbody>
  								</table>
  							</div>
  							<div class="col">
  								<div id="MIHistory" style="width: 100%; height: 250px;"></div>
  								</div>
  							</div>
  					</div>
  					<hr>
  					<div class="container bg-light text-black rounded">
  						<div class="row">
  							<div class="col">
  								<h6 class="display-6" align="center">Multiple Intelligence Attributes</h6>
  							</div>
  						</div>
  						<div class="row">
  							<div class="col">
  								<table class="table table-success table-hover table-sm">
  									<thead class="thead-dark">
  										<tr>
  											<th scope="col">ID</th>
  											<th scope="col">Multiple Intelligence Type</th>
  											<th scope="col">Score</th>
  										</tr>
  									</thead>
  									<tbody>
  										<?php foreach ($DistinctMI as $r) {
  											echo "<tr><td>" . $r->MulInt_ID . "</td>";
  											echo "<td>" . $r->MulInt_Name . "</td>";
  											echo "<td>" . $r->AVERAGE_SCORE . "</td></tr>";
  										}?>
  									</tbody>
  								</table>
  							</div>
  							<div class="col">
  								<div id="MIAttributes" style="width: 450px; height: 250px;">
  								</div>
  							</div>
  						</div>
  						
         
  					</form>
  				</body>
  				</html>

