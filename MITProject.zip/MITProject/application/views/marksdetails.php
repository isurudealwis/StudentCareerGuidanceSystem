<!doctype html>

	<html>
	<head>
		<meta charset="utf-8">
		<title>Students Details</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

	</head>

	<body>
		
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Marks Details</h2>
				</div>
				<div class="col col-md-3 offset-md-5">
					<form method="post" action="<?php echo base_url().'index.php/markscontroller/marks'?>">
						<input type="submit" name="selection" value="Back to Selection" class="btn btn-primary">
					</form>
				</div>
			</div>
		</div>
		<hr>
		<div class="container">
			<div class="row">
				<?php foreach($students as $r){?>
					<div class="col-sm-3">
						<h5><b>Year:</b> <?php echo $r->Exam_Year; ?></h5>
					</div>
					<div class="col-sm-3">
						<h5><b>Term:</b> <?php echo $r->Exam_Term;?></h5>
					</div>
					<div class="col-sm-3">
						<h5><b>Class:</b> <?php echo $r->Cls_Name;?></h5>
					</div>
					<div class="col-sm-3">
						<h5><b>Subject:</b> <?php echo $r->Sub_Name;break;}?></h5>
					</div>
				</div>
			</div>
			<hr>
			<div class="container">
				<div class="form-group">
					<div class="table-responsive-sm">
						<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col">Student ID</th>
									<th scope="col">Student Admission No.</th>
									<th scope="col">Student Full Name</th>
									<th scope="col">Marks</th>
									<th scope="col" colspan="2">Actions</th>

								</tr>
							</thead>
							<tbody>
								<?php
								if(empty($students)) {
									echo "<td> No record found. </td>";
								}
								else {

									foreach ( $students as $stu ) {?>
										<form method="get" action="<?php echo base_url().'index.php/markscontroller/insertupdatemark'?>">
											<tr>
												<input type="hidden" name="examid" value="<?php echo $stu->Exam_ID; ?>">
												<input type="hidden" name="stusubid" value="<?php echo $stu->StuSub_ID; ?>">
												<td scope="row"><?php echo $stu->Stu_ID; ?></td>
												<td scope="row"><?php echo $stu->Stu_Index_No; ?></td>
												<td scope="row"><?php echo $stu->Stu_Full_Name; ?></td>
												<td><input type="number" name="mark" min="0" max="100" class="form-control" value="<?php echo $stu->Mrk_Mark; ?>"></td>
												<input type="hidden" name="markid" value="<?php echo $stu->Mrk_ID; ?>">
												<td><input type="submit" class="btn btn-success" name="update" value="Update"></td>
											</tr>
										</form>
									<?php } }?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</body>
			</html>