<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Teacher-Subject-Class Management</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
				document.getElementById("selecttype").value="";
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Teacher-Subject-Class Management</h2>
				</div>
			</div>
			<div class="row"><br><hr></div>
		</div>
		<form method="post" action="<?php echo base_url().'index.php/TSCController/TSC'?>">
		<div class="container">
			<div class="row">
				<div class="col">
					<input type="text" class="form-control" name="keyword" placeholder="Enter Keyword..." value="<?php echo $_SESSION['keyword'] ?>">
				</div>
				<div class="col-sm-3">
					<select name="column" class="form-control">
						<option value=''>From Entire Table</option>
						<option value='TeaSub_ID'>Teacher-Subject ID</option>
						<option value='TeaSub_Year'>Teacher-Subject Year</option>
						<option value='tbl_teacher_subject_class.Tea_ID'>Teacher ID</option>
						<option value='Tea_First_Name'>Teacher First Name</option>
						<option value='Tea_Last_Name'>Teacher Last Name</option>
						<option value='Sub_Name'>Subject Name</option>
						<option value='Cls_Name'>Class</option>
					</select>
				</div>
				<div class="col">
					<input type="submit" name="find" value="Find Record" class="btn btn-primary">
				</div>
				<div class="col">
					<input type="submit" name="clear" value="Clear Search" class="btn btn-light" onclick="cleartabs()">
				</div>
					<div class="col">
						<input type="submit" name="insert" value="Insert Record" class="btn btn-primary">
					</div>
				</div>
			</div>
		</form>
		<hr>
		<div class="container">
			<div class="form-group">
				<div class="table-responsive-sm">
					<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
						<thead class="thead-dark">
							<tr>
								<th scope="col">Teacher Subject ID</th>
								<th scope="col">Year</th>
								<th scope="col">Teacher ID</th>
								<th scope="col">First Name</th>
								<th scope="col">Last Name</th>
								<th scope="col">Subject</th>
								<th scope="col">Class</th>
								<th scope="col" colspan="2"><center>Actions</center></th>
							</tr>
						</thead>
						<tbody>
							<?php
							if(empty($data)) {
								echo "<td> No record found. </td>";
							}
							else {
								foreach ( $data as $row ) {?>
									<form method="get" action="<?php echo base_url().'index.php/TSCController/update'?>">
										<?php echo "<tr>";
										echo "<td scope=\"row\">" . $row->TeaSub_ID . "</td>";
										echo "<td>" . $row->TeaSub_Year . "</td>";
										echo "<td>" . $row->Tea_ID . "</td>";
										echo "<td>" . $row->Tea_First_Name . "</td>";
										echo "<td>" . $row->Tea_Last_Name . "</td>";
										echo "<td>" . $row->Sub_Name . "</td>";
										echo "<td>" . $row->Cls_Name . "</td>";
										echo "<td><a href='update?TeaSub_ID=".$row->TeaSub_ID."'>
										<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></td>";
										echo "<td><a href='delete?TeaSub_ID=".$row->TeaSub_ID."'>
										<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->TeaSub_ID."?')) {return false}\"></a></td>";
										echo "</tr>";
										echo "</form>";
									}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</body>
	</html>

?>