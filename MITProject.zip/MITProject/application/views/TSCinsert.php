
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Insert Teacher Subject Class Record</title>
		    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Insert Teacher-Subject-Class Record </h4><br>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/TSCController/insert'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Teacher-Subject ID: </td>
											</div>
											<div class="col">
												<td><input type="text" name="TeaSub_ID" value="<?php echo $id;?>"
												readonly class="form-control">
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Year</td>
											</div>
											<div class="col">
													<td><select name="TeaSub_Year" class="form-control">
													<option value="" selected disabled required>Select the year</option>
													<?php
													$c=date("Y");
													while($c>=date("Y")-14)
													{
														echo "<option value='".$c."'>".$c."</option>;";
														$c--;
													}
													?>
												</select>
											</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Teacher Name</td>
											</div>
											<div class="col">
											<td><select name="Tea_ID" class="form-control">
												<option value='' selected disabled required>Select...</option>
												<?php
												foreach ( $teacherlist as $listitem ) {
													echo "<option value='" . $listitem->Tea_ID . "'>" . $listitem->Tea_ID . " - ".$listitem->Tea_First_Name." ".$listitem->Tea_Last_Name."</option>";
													}
												?>
											</select>
										</td>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Class</td>
											</div>
											<div class="col">
											<td><select name="Cls_ID" class="form-control">
												<option value='' selected disabled required>Select...</option>
												<?php
												foreach ( $classlist as $listitem ) {
													echo "<option value='" . $listitem->Cls_ID . "'>" . $listitem->Cls_Name . "</option>";
													}
												?>
											</select>
										</td>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Subject</td>
											</div>
											<div class="col">
											<td><select name="Sub_ID" class="form-control">
												<option value='' selected disabled required>Select...</option>
												<?php
												foreach ( $subjectlist as $listitem ) {
													echo "<option value='" . $listitem->Sub_ID . "'>" . $listitem->Sub_Name . "</option>";
													}
												?>
											</select>
										</td>
									</div>
										</tr>
									</div>

								</div>
								<div class="row">
									<tr>
										<div class="col">
											<td width="100"><input type="submit" name="save" id="BInsert" value="Insert Record" class="btn btn-success" onclick="return confirm('Are you sure you want to add the Record? (Press OK to continue, Cancel to return.)')">
												</td>
										</div>
									</form>
									<form method="post" action="<?php echo base_url().'index.php/TSCController/TSC'?>">
										<div class="col">
											<td width="113"><input type="submit" name="back" value="Back" class="btn btn-secondary">
											</td>
										</div>
									</form>
									</tr>
								</div>
							</tbody>
						</table>
					</div>
			</div>
			<div class="col"></div>
		</div>
	</div>
</body>

</html>