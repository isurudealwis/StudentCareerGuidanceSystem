
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Insert Teacher Record</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Insert Teacher Record</h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/teacherscontroller/insert'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Serial No: </td>
											</div>
											<div class="col">
												<?php
												if(empty($current)) {
													$newid='T0001';
												}
												else {
													foreach($current as $r) {
														$id=substr($r->Tea_ID,1);
														$newvalue=$id+1;
														$newid='T'.str_pad($newvalue,4,"0",STR_PAD_LEFT);}}?>
														<td><input type="text" name="Tea_ID" id="textfield2" value="<?php echo $newid?>" readonly class="form-control">
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>First Name</td>
													</div>
													<div class="col">
														<td><input type="text" name="Tea_First_Name" id="Tea_FName" value="" class="form-control" required>
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>Last Name</td>
													</div>
													<div class="col">
														<td><input type="text" name="Tea_Last_Name" id="Tea_LName" value="" class="form-control" required>
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>NIC No.</td>
													</div>
													<div class="col">
														<td><input type="text" name="Tea_NIC_No" id="Tea_NICNo" value="" class="form-control" maxlength="12" required>
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>Date of Birth</td>
													</div>
													<div class="col">
														<td><input type="date" name="Tea_DOB" id="Tea_DOB" value="" max="" class="form-control" required>
														</td>
													</div>
												</tr>
											</div>

											<div class="row">
												<tr>
													<div class="col">
														<td>Telephone No. (Home)</td>
													</div>
													<div class="col">
														<td><input type="tel" name="Tea_Home_Tel" id="txt_Tea_HomeTel" value="" pattern="[0-9]{9}" class="form-control" required maxlength="9" placeholder="Ex: 112345678">
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>Telephone No. (Mobile)</td>
													</div>
													<div class="col">
														<td><input type="tel" name="Tea_Mobile_Tel" id="txt_Tea_MobTel" value="" pattern="[0-9]{9}" class="form-control" required maxlength="9" placeholder="Ex: 777123456">
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>Email Address</td>
													</div>
													<div class="col">
														<td><input type="email" name="Tea_Email" id="txt_TeaEmail" value="" class="form-control" required placeholder="Ex: abc@gmail.com">
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>New Password</td>
													</div>
													<div class="col">
														<td><input type="password" name="Tea_Pass" id="Tea_Password" value="" class="form-control" required minlength="5">
														</td>
													</div>
												</tr>
											</div>
											<div class="row">
												<tr>
													<div class="col">
														<td>Staff Admin?</td>
													</div>
													<div class="col">
														<td><select name="Tea_StaffAdmin" id="select" class="form-control" required>
															<option value='Yes'>Yes</option>
															<option value='No'>No</option>
														</select>
													</td>
												</div>
											</tr>
										</div>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td width="250"><input type="submit" name="save" id="BInsert" value="Insert Record" class="btn btn-success" onclick="return confirm('Are you sure you want to add the Record? (Press OK to continue, Cancel to return.)')">
												</td>
											</div>
											<div class="col">
												<td width="400"><input type="reset" class="btn btn-secondary">
												</td>
											</div>
										</form>
										<div class="col">
											<form method="post" action="<?php echo base_url().'index.php/teacherscontroller/teacher'?>">
												<td><input type="submit" name="back" id="BBack" value="Back" class="btn btn-secondary">
												</td>
											</form>
										</div>
									</tr>
								</div>
							</tbody>
						</table>
					</div>
				</form>
			</div>
		</div>
	</body>
	</html>

	<script type="text/javascript">
		var today = new Date();
		var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
	dd = '0' + dd;
}

if (mm < 10) {
	mm = '0' + mm;
} 

today = yyyy + '-' + mm + '-' + dd;
document.getElementById("Tea_DOB").setAttribute("max", today);
</script>