<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Student Behaviour / Extra Curricular Activities Management</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
				document.getElementById("selecttype").value="";
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Student Behaviour / Extra Curricular Activities Management</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/StudentBehaviourAssignmentController/StudentBehaviourAssignment'?>">
						
					</div>
				</div>
				<div class="row"><br><hr></div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col">
						<input type="text" class="form-control" name="keyword" placeholder="Enter Keyword..." value="<?php echo $_SESSION['keyword'] ?>">
					</div>
					<div class="col-sm-3">
						<select name="column" class="form-control">
							<option value=''>From Entire Table</option>
							<option value='StuExt_ID'> StuExt ID </option>
							<option value='tbl_stu_extbehactivity.Stu_ID'> Student ID </option>
							<option value='Stu_Index_No'> Student Admission No. </option>
							<option value='Stu_Full_Name'> Student Name </option>
							<option value='tbl_stu_extbehactivity.BehAct_ID'> Behavioural Activity ID </option>
							<option value='BehAct_Name'> Behavioural Activity Name </option>
							<option value='StuExt_Points'> Points </option>


						</select>
					</div>
					<div class="col">
						<input type="submit" name="find" value="Find Record" class="btn btn-primary"> </div>
						<div class="col">
							<input type="submit" name="clear" value="Clear Search" class="btn btn-light" onclick="cleartabs()"></div>
							<div class="col">
								<input type="submit" name="insert" value="Insert Record" class="btn btn-primary"> </div>
							</div>
						</div>
					</form>
						<hr>
						<div class="container">
							<div class="form-group">
								<div class="table-responsive-sm">
									<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
										<thead class="thead-dark">
											<tr>
												<th scope="col">StuExt ID</th>
												<th scope="col">Student ID</th>
												<th scope="col">Student Admission No.</th>
												<th scope="col">Student Name</th>
												<th scope="col">Behavioural ID</th>
												<th scope="col">Behavioural/Extra Curricular Type</th>
												<th scope="col">Points</th>
												<th scope="col" colspan="2">Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(empty($data)) {
												echo "<td> No record found. </td>";
											}
											else {
												foreach ( $data as $row ) {?>
												<form method="get" action="<?php echo base_url().'index.php/StudentBehaviourAssignmentController/StudentBehaviourAssignment'?>">
													<?php echo "<tr>";
													echo "<td scope=\"row\">" . $row->StuExt_ID . "</td>";
													echo "<td scope=\"row\">" . $row->Stu_ID . "</td>";
													echo "<td scope=\"row\">" . $row->Stu_Index_No . "</td>";
													echo "<td scope=\"row\">" . $row->Stu_Full_Name . "</td>";
													echo "<td scope=\"row\">" . $row->BehAct_ID . "</td>";
													echo "<td scope=\"row\">" . $row->BehAct_Name . "</td>";

													echo "<td>" . $row->StuExt_Points . "</td>";
													echo "<td><a href='update?StuExt_ID=".$row->StuExt_ID."'>
													<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></td>";
													echo "<td><a href='delete?StuExt_ID=".$row->StuExt_ID."'>
													<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->StuExt_ID."?')) {return false}\"></a></td>";
													echo "</tr>";
												echo "</form>";
												}
											}
											?>
										</tbody>
									</form>
									</table>
								</div>
							</div>
						</div>
					</form>
				</body>
				</html>

?>