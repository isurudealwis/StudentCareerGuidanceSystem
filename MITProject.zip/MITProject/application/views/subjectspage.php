<!doctype html>

	<?php
//session_start();
	?>
	<html>
	<head>
		<meta charset="utf-8">
		<title>Subject Details</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Subject Details </h2><br>
				</div>
			</div>
		</div>
		<form method="post" action="<?php echo base_url().'index.php/classesandsubjectscontroller/subject'?>">
			<div class="container">
				<div class="row">
					<div class="col">
						<input type="text" class="form-control" id="findtext" name="find" placeholder="Enter Keyword..." value="<?php echo $keyword ?>">
					</div>
					<div class="col">
						<input type="submit" name="findrecord" value="Find" class="btn btn-secondary">
					</div>
					<div class="col">
						<input type="submit" name="clearsearch" value="Clear" class="btn btn-light" onclick="cleartabs()">
					</div>
					<div class="col">
						<input type="submit" name="insertsubject" value="Add New Subject" class="btn btn-primary">
					</div> 
				</div>
			</div>



			<div class="container">
				<div class="form-group">
					<div class="table-responsive-sm">
						<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col"><center>Subject ID</center></th>
									<th scope="col"><center>Subject Name</center></th>
									<th scope="col" colspan="2"><center>Actions</center></th>
								</tr>
							</thead>
							<tbody>
								<?php
								if(empty($data)) {
									echo "<td> No record found. </td>";
								}
								else {
									foreach ( $data as $row ) {
										echo "<tr>";
										echo "<td scope=\"row\">" . $row->Sub_ID . "</td>";
										echo "<td>" . $row->Sub_Name . "</td>";
										echo "<td><center><a href='updatesubjectrecord?Sub_ID=".$row->Sub_ID."'>
										<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></center></td>";
										echo "<td><center><a href='deletesubjectrecord?Sub_ID=".$row->Sub_ID."'>
										<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->Sub_ID."?')) {return false}\"></a></center></td>";
										echo "</tr>";
									}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</body>
	</html>