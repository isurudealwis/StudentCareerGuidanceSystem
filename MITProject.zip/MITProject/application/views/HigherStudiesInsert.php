
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Insert Higher Studies Record</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Insert Higher Studies Record </h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/HigherStudiesController/insert'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Higher Studies ID: </td>
											</div>
											<div class="col">
												<td><input type="text" name="HighStd_ID" value="<?php echo $id;?>"
												readonly class="form-control">
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Higher Studies Name</td>
											</div>
											<div class="col">
												<td><input type="text" name="HighStd_Name" value="" class="form-control" required>
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Description</td>
											</div>
											<div class="col">
												<td><input type="text" name="HighStd_Desc" value="" class="form-control" required>
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Multiple Intelligence Type</td>
											</div>
											<div class="col">
											<td><select name="MulInt_ID" class="form-control" required>
												<option value='' selected disabled>Select...</option>
												<?php
												foreach ( $mulintlist as $listitem ) {
													echo "<option value='" . $listitem->MulInt_ID . "'>" . $listitem->MulInt_Name . "</option>";
													}
												?>
											</select>
										</td>
									</div>
										</tr>
									</div>

								</div>
								<div class="row">
									<tr>
									<div class="col">
										<td></td>
									</div>
									<div class="col">
										<td width="600"><input type="submit" name="save" id="BInsert" value="Insert Record" class="btn btn-success" onclick="return confirm('Are you sure you want to add the Record? (Press OK to continue, Cancel to return.)')">

										</td>
									</div>
								</form>
								<form method="post" action="<?php echo base_url().'index.php/HigherStudiesController/HigherStudies'?>">
									<div class="col">
										<td width="100"><input type="submit" name="back" value="Back" class="btn btn-secondary">
										</td>
									</div>
								</form>
							</tr>
								</div>
							</tbody>
						</table>
					</div>
			</div>
			<div class="col"></div>
		</div>
	</div>
</body>

</html>