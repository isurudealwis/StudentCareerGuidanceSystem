<!doctype html>

	<?php
//session_start();
	?>
	<html>
	<head>
		<meta charset="utf-8">
		<title>Teachers Details</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
				document.getElementById("select").value="";
			}
		</script>

	</head>

	<body>
		<form method="post" action="<?php echo base_url().'index.php/teacherscontroller/teacher'?>">
			<div class="container">
				<div class="row">
					<div class="col">
						<h2>Teacher Management</h2>
					</div>
				</div>
				<div class="row"><hr></div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col">
						<input type="text" class="form-control" id="findtext" name="find" placeholder="Enter Keyword..." value="<?php echo $keyword ?>">
					</div>
					<div class="col">
						<select name="searchtype" id="select" class="form-control">
							<option value=''>From Entire Table</option>
							<option value='Tea_ID'>Teacher ID</option>
							<option value='Tea_First_Name'>First Name</option>
							<option value='Tea_Last_Name'>Last Name</option>
							<option value='Tea_NIC_No'>NIC No</option>
							<option value='Tea_DOB'>Date of Birth</option>
							<option value='Tea_Home_Tel'>Home Telephone No.</option>
							<option value='Tea_Mobile_Tel'>Mobile No.</option>
							<option value='Tea_Email'>Email Address</option>
							<option value='Tea_StaffAdmin'>Is an Admin? (Yes or No)</option>
						</select>
					</div>
					<div class="col-sm-1">
						<input type="submit" name="findrecord" value="Find" class="btn btn-secondary">
					</div>
					<div class="col-sm-1">
						<input type="submit" name="clearsearch" value="Clear" class="btn btn-light" onclick="cleartabs()">
					</div>
					<div class="col-sm-1">
						<input type="submit" name="insert" value="New Record" class="btn btn-primary">
					</div> 
				</div>
			</div>
			<hr>
			<div class="container">
				<div class="form-group">
					<div class="table-responsive-sm">
						<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col">Teacher ID</th>
									<th scope="col">First Name</th>
									<th scope="col">Last Name</th>
									<th scope="col">NIC No.</th>
									<th scope="col">Date of Birth</th>
									<th scope="col">Telephone No. (Home)</th>
									<th scope="col">Telephone No. (Mobile)</th>
									<th scope="col">Email Address</th>
									<th scope="col">Staff Admin?</th>
									<th scope="col" colspan="2">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php
								if(empty($data)) {
									echo "<td> No record found. </td>";
								}
								else {
									foreach ( $data as $row ) {
										echo "<tr>";
										echo "<td scope=\"row\">" . $row->Tea_ID . "</td>";
										echo "<td>" . $row->Tea_First_Name . "</td>";
										echo "<td>" . $row->Tea_Last_Name . "</td>";
										echo "<td>" . $row->Tea_NIC_No . "</td>";
										echo "<td>" . $row->Tea_DOB . "</td>";
										echo "<td>" . $row->Tea_Home_Tel . "</td>";
										echo "<td>" . $row->Tea_Mobile_Tel . "</td>";
										echo "<td>" . $row->Tea_Email . "</td>";
										echo "<td>" . $row->Tea_StaffAdmin . "</td>";
										echo "<td><a href='update?Tea_ID=".$row->Tea_ID."'>
													<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></td>";
													echo "<td><a href='delete?Tea_ID=".$row->Tea_ID."'>
													<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->Tea_ID."?')) {return false}\"></a></td>";
													echo "</tr>";
									}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</div>
</body>
</html>