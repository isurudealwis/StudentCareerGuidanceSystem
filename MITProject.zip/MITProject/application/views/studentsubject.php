<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Student - Subject Assignments</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
				document.getElementById("selecttype").value="";
				document.getElementById("selectyear").value="";
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Student - Subject Assignments</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/studentsubjectcontroller/studentsubject'?>">
					</div>
				</div>
				<div class="row"><br><hr></div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col">
						<input type="text" class="form-control" id="findtext" name="find" placeholder="Enter Keyword..." value="<?php echo $keyword ?>">
					</div>
					<div class="col"><select name="searchtype" id="selecttype" class="form-control">
						<option value=''>From Entire Table</option>
					<option value='tbl_student_subject.StuSub_ID'>Student-Subject ID</option>
						<option value='tbl_student_subject.Stu_ID'>Student ID</option>
						<option value='tbl_student.Stu_Index_No'>Student Admission No</option>
						<option value='tbl_student.Stu_Full_Name'>Student Full Name</option>
						<option value='tbl_student_subject.Sub_ID'>Subject Code</option>
						<option value='tbl_subject.Sub_Name'>Subject</option>
					</select> </div>
					<div class="col">
						<select name="year" id="selectyear" class="form-control">
							<option value=''>Year</option>
							<?php
							foreach ( $yearlist as $listitem ) {
								if ($listitem->StuSub_Year == $cs ) {
									echo "<option value='" . $listitem->StuSub_Year . "' selected>" . $listitem->StuSub_Year . "</option>";	
								}
								else {
									echo "<option value='" . $listitem->StuSub_Year . "'>" . $listitem->StuSub_Year . "</option>";
								}
							}
							?>
						</select>
					</div>
					<div class="col">
						<input type="submit" name="findstudents" value="Find Students" class="btn btn-primary"> </div>
						<div class="col">
							<input type="submit" name="clearsearch" value="Clear Search" class="btn btn-light" onclick="cleartabs()"></div>
							<div class="col">
								<input type="submit" name="insertrecord" value="Insert Record" class="btn btn-primary"> </div>
							</div>
						</div>
						<hr>
						<div class="container">
							<div class="form-group">
								<div class="table-responsive-sm">
									<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
										<thead class="thead-dark">
											<tr>
												<th scope="col">Student-Subject ID</th>
												<th scope="col">Year</th>
												<th scope="col">Student ID</th>
												<th scope="col">Student Admission No.</th>
												<th scope="col">Student Full Name</th>
												<th scope="col">Subject Code</th>
												<th scope="col">Subject</th>
												<th scope="col" colspan="2">Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(empty($data)) {
												echo "<td> No record found. </td>";
											}
											else {
												foreach ( $data as $row ) {
													echo "<tr>";
													echo "<td scope=\"row\">" . $row->StuSub_ID . "</td>";
													echo "<td>" . $row->StuSub_Year . "</td>";
													echo "<td>" . $row->Stu_ID . "</td>";
													echo "<td>" . $row->Stu_Index_No . "</td>";
													echo "<td>" . $row->Stu_Full_Name . "</td>";
													echo "<td>" . $row->Sub_ID . "</td>";
													echo "<td>" . $row->Sub_Name . "</td>";
													echo "<td><a href='update?StuSub_ID=".$row->StuSub_ID."'>
													<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></td>";
													echo "<td><a href='delete?StuSub_ID=".$row->StuSub_ID."'>
													<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->StuSub_ID."?')) {return false}\"></a></td>";
													echo "</tr>";
												}
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</form>
				</body>
				</html>

?>