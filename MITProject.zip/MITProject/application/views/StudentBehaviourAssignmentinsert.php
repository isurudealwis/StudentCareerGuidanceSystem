
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Behavioural / Extra Curricular Activity Assignments</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Behavioural / Extra Curricular Activity Assignments</h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/StudentBehaviourAssignmentController/insert'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Assignment ID: </td>
											</div>
											<div class="col">
												<td><input type="text" name="StuExt_ID" value="<?php echo $id;?>"
												readonly class="form-control">
												</td>
											</div>
										</tr>
									</div>
									<tr>
									<div class="col">
										<td>Student Admission No.</td>
									</div>
									<div class="col">
										<td><input type="text" name="admission_no" value="<?php foreach ($record as $r) { echo $r->Stu_Index_No;}?>" class="form-control" required>
										</td>
										
									</div>
									<div class="col">
										<td width="113"><input type="submit" name="GetStudent" value="Get Student" class="btn btn-secondary get_student">
										</td>
									</div>
								</tr>
							</div>
							<div class="row">
								<tr>
									<div class="col">
										<td>Student ID</td>
									</div>
									<div class="col">
										<td><input type="text" name="Stu_ID" id="textfield2" value="<?php foreach ($record as $r) { echo $r->Stu_ID;}?>" class="form-control" readonly required>
										</td>
									</div>
								</tr>
							</div>

							<div class="row">
								<tr>
									<div class="col">
										<td>Student Full Name</td>
									</div>
									<div class="col">
										<td><input type="text" name="Stu_Full_Name" id="textfield2" value="<?php foreach ($record as $r) { echo $r->Stu_Full_Name;}?>" class="form-control" readonly required>
										</td>
									</div>
								</tr>
							</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Activity Type</td>
											</div>
											<div class="col">
											<td><select name="BehAct_ID" class="form-control">
												<option value='' selected disabled>Select...</option>
												<?php
												foreach ( $behlist as $listitem ) {
													echo "<option value='" . $listitem->BehAct_ID . "'>" . $listitem->BehAct_Name . "</option>";
													}
												?>
											</select>
										</td>
									</div>
										</tr>

										<div class="row">
								<tr>
									<div class="col">
										<td>Points</td>
									</div>
									<div class="col">
										<td><input type="number" name="StuExt_Points" id="textfield2" value="" class="form-control" min="0" max="100">
										</td>
									</div>
								</tr>
							</div>
									</div>

								</div>
								<div class="row">
									<tr>
										<div class="col">
											<td></td>
										</div>
										<div class="col">
											<td width="600"><input type="submit" name="save" id="BInsert" value="Insert Record" class="btn btn-success" onclick="return confirm('Are you sure you want to add the Record? (Press OK to continue, Cancel to return.)')">
											</td>
										</div>
									</form>
									<form method="post" action="<?php echo base_url().'index.php/StudentBehaviourAssignmentController/StudentBehaviourAssignment'?>">
										<div class="col">
											<td width="100"><input type="submit" name="back" value="Back" class="btn btn-secondary">
											</td>
										</div>
									</form>
									</tr>
								</div>
							</tbody>
						</table>
					</div>
			</div>
		</div>
	</div>
</body>

</html>