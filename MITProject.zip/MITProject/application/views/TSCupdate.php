
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Update Teacher Subject Class Record</title>
		    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Update Teacher Subject Class Record</h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/TSCController/update'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Teacher Subject ID: </td>
											</div>
											<div class="col">
												<td><input type="text" name="TeaSub_ID" value="<?php foreach ($record as $r) {echo $r->TeaSub_ID;}?>"
												readonly class="form-control">
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Year: </td>
											</div>
											<div class="col">
													<td><select name="TeaSub_Year" class="form-control">
													<option value="" disabled required>Select the year</option>
													<?php
													$c=date("Y");
													while($c>=date("Y")-14)
													{
														foreach ($record as $r) {
															if ($r->TeaSub_Year==$c) {
																echo "<option value='".$c."' selected>".$c."</option>;";		
															}
															else {
																echo "<option value='".$c."'>".$c."</option>;";
															}
														}
														$c--;
													}
													?>
												</select>
											</td>
											</div>
										</tr>
									</div>
									<div class="col">
										<tr>
											<div class="col">
												<td>Teacher Name</td>
											</div>
											<td><select name="Tea_ID" class="form-control">
												<option value='' selected disabled required>Subject</option>
												<?php
												foreach ( $teacherlist as $listitem ) {
													foreach ($record as $r) {
														if ($listitem->Tea_ID == $r->Tea_ID) {
														echo "<option value='" . $listitem->Tea_ID . "' selected>" . $listitem->Tea_ID . " - ".$listitem->Tea_First_Name." ".$listitem->Tea_Last_Name."</option>";	
													}
													else {
														echo "<option value='" . $listitem->Tea_ID . "'>" . $listitem->Tea_ID . " - ".$listitem->Tea_First_Name." ".$listitem->Tea_Last_Name."</option>";
													}
												}
												}
												?>
											</select>
										</td>
									</div>
									</tr>
								</div>
									<div class="col">
										<tr>
											<div class="col">
												<td>Class</td>
											</div>
											<td><select name="Cls_ID" class="form-control">
												<option value='' selected disabled required>Subject</option>
												<?php
												foreach ( $classlist as $listitem ) {
													foreach ($record as $r) {
														if ($listitem->Cls_ID == $r->Cls_ID) {
														echo "<option value='" . $listitem->Cls_ID . "' selected>" . $listitem->Cls_Name . "</option>";	
													}
													else {
														echo "<option value='" . $listitem->Sub_ID . "'>" . $listitem->Cls_Name . "</option>";	
													}
												}
												}
												?>
											</select>
										</td>
									</div>
									</tr>
								</div>
								<div class="col">
										<tr>
											<div class="col">
												<td>Subject</td>
											</div>
											<td><select name="Sub_ID" class="form-control">
												<option value='' selected disabled required>Subject</option>
												<?php
												foreach ( $subjectlist as $listitem ) {
													foreach ($record as $r) {
														if ($listitem->Sub_ID == $r->Sub_ID) {
														echo "<option value='" . $listitem->Sub_ID . "' selected>" . $listitem->Sub_Name . "</option>";	
													}
													else {
														echo "<option value='" . $listitem->Sub_ID . "'>" . $listitem->Sub_Name . "</option>";	
													}
												}
												}
												?>
											</select>
										</td>
									</div>
									</tr>
								</div>
								<div class="row">
									<tr>
										<div class="col">
											<td width="103"><input type="submit" name="update" id="BUpdate" value="Update Record" class="btn btn-success" onclick="return confirm('Are you sure you want to update the record no <?php echo $r->TeaSub_ID?>?')">
											</td>
										</div>
									</form>
									<form method="post" action="<?php echo base_url().'index.php/TSCController/TSC'?>">
										<div class="col">
											<td width="113"><input type="submit" name="back" value="Back" class="btn btn-secondary">
											</td>
										</div>
									</form>
									</tr>
								</div>
							</tbody>
						</table>
					</div>
			</div>
			<div class="col"></div>
		</div>
	</div>
</body>

</html>