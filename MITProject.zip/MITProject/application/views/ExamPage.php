<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Examinations</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
		<script>
			function cleartabs() {
				document.getElementById("findtext").value="";
				document.getElementById("selecttype").value="";
				document.getElementById("selectyear").value="";
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Examination Management</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/ExamController/exam'?>">
					</div>
				</div>
				<div class="row"><br><hr></div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col">
						<input type="text" class="form-control" id="findtext" name="find" placeholder="Enter Keyword..." value="<?php echo $keyword ?>">
					</div>
					<div class="col"><select name="searchcolumn" id="selecttype" class="form-control">
						<option value=''>From Entire Table</option>
						<option value='tbl_examination.Exam_ID'>Exam ID</option>
						<option value='tbl_examination.Exam_Term'>Exam Term</option>
						<option value='tbl_examination.Sub_ID'>Subject ID</option>
						<option value='tbl_subject.Sub_Name'>Subject</option>
						<option value='tbl_examination.MulInt_ID'>Mult. Int. ID</option>
						<option value='tbl_mulint_categories.MulInt_Name'>Mult. Int. Type</option>
					</select> </div>
					<div class="col">
						<select name="year" id="year" class="form-control">
							<option value=''>Year</option>
							<?php
							foreach ( $yearlist as $listitem ) {
								if ($listitem->Exam_Year == $cs ) {
									echo "<option value='" . $listitem->Exam_Year . "' selected>" . $listitem->Exam_Year . "</option>";	
								}
								else {
									echo "<option value='" . $listitem->Exam_Year . "'>" . $listitem->Exam_Year . "</option>";
								}
							}
							?>
						</select>
					</div>
					<div class="col">
						<input type="submit" name="findexam" value="Find Exam" class="btn btn-primary"> </div>
						<div class="col">
							<input type="submit" name="clearsearch" value="Clear Search" class="btn btn-light" onclick="cleartabs()"></div>
							<div class="col">
								<input type="submit" name="insertrecord" value="Insert Record" class="btn btn-primary"> </div>
							</div>
						</div>
						<hr>
						<div class="container">
							<div class="form-group">
								<div class="table-responsive-sm">
									<table border='1' align="center" id="table" class="table table-striped table-hover table-sm">
										<thead class="thead-dark">
											<tr>
												<th scope="col">Exam ID</th>
												<th scope="col">Exam Year</th>
												<th scope="col">Exam Term</th>
												<th scope="col">Subject Code</th>
												<th scope="col">Subject</th>
												<th scope="col">Multiple Intel. ID</th>
												<th scope="col">Multiple Intel. Type</th>
												<th scope="col" colspan="2">Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(empty($data)) {
												echo "<td> No record found. </td>";
											}
											else {
												foreach ( $data as $row ) {
													echo "<tr>";
													echo "<td scope=\"row\">" . $row->Exam_ID . "</td>";
													echo "<td>" . $row->Exam_Year . "</td>";
													echo "<td>" . $row->Exam_Term . "</td>";
													echo "<td>" . $row->Sub_ID . "</td>";
													echo "<td>" . $row->Sub_Name . "</td>";
													echo "<td>" . $row->MulInt_ID . "</td>";
													echo "<td>" . $row->MulInt_Name . "</td>";
													echo "<td><a href='update?Exam_ID=".$row->Exam_ID."'>
													<input type=\"button\" class=\"btn btn-success\" value=\"Update\"></a></td>";
													echo "<td><a href='delete?Exam_ID=".$row->Exam_ID."'>
													<input type=\"button\" class=\"btn btn-danger\" value=\"Delete\" onclick=\"if(! confirm('Are you sure you want to delete the record no ".$row->Exam_ID."?')) {return false}\"></a></td>";
													echo "</tr>";
												}
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</form>
				</body>
				</html>

?>