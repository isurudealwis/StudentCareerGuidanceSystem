<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Students Report Details</title>

		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>

		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>   
		<script type="text/javascript">
			google.charts.load('current', {'packages':["corechart"]});
			google.charts.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = google.visualization.arrayToDataTable([
					['Multiple Intelligence Name', 'Average'],	
					<?php foreach ($Overall_Details as $r) {
						echo "['".$r->MulInt_Name."', ".$r->AVERAGE_SCORE."],";
					} ?>
					]);

				var options = {
					title: 'Overall Score',
					is3D: true,
				};

				var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
				chart.draw(data, options);
			}
		</script>

		<script type="text/javascript">
			google.charts.load('current', {'packages':["corechart"]});
			google.charts.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = google.visualization.arrayToDataTable([
					['Multiple Intelligence Name', 'Average'],	
					<?php foreach ($Exam_Details as $r) {
						echo "['".$r->MulInt_Name."', ".$r->AVERAGE_SCORE."],";
					} ?>
					]);

				var options = {
					title: 'From Examinations',
					width: 400,
					height: 266,
					bar: {groupWidth: "95%"},
					legend: { position: "none" },
					is3D: true,
				};

				var chart = new google.visualization.ColumnChart(document.getElementById('barchart_3d_exam'));
				chart.draw(data, options);
			}
		</script>
		<script type="text/javascript">
			google.charts.load('current', {'packages':["corechart"]});
			google.charts.setOnLoadCallback(drawChart);
			function drawChart() {
				var data = google.visualization.arrayToDataTable([
					['Multiple Intelligence Name', 'Average'],	
					<?php foreach ($ExtCur_Details as $r) {
						echo "['".$r->MulInt_Name."', ".$r->AVERAGE_SCORE."],";
					} ?>
					]);

				var options = {
					title: 'From Behavioural Activities',
					width: 400,
					height: 266,
					bar: {groupWidth: "95%"},
					legend: { position: "none" },
				};

				var chart = new google.visualization.ColumnChart(document.getElementById('barchart_3d_extcur'));
				chart.draw(data, options);
			}
		</script>

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2 align="center">Detailed Student Report</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/StudentReportController/StudentReport'?>">
						<input type="submit" name="back" value="Back" class="btn btn-primary">
					</div>
				</div>
			</div>
			<hr>

			<div class="container">
				<div class="row">
					<h3>Overall Student Result</h3>
				</div>
				<div class="row">
					<table class="table table-striped table-hover">
						<tbody>
							<?php foreach ($Student_Details as $r) {
								echo "<tr><td>Student ID</td><td><strong><em>".$r->Stu_ID."</strong></em></td>";
								echo "<td>Student Index No</strong></td><td><strong><em>".$r->Stu_Index_No."</strong></em></td></tr>";
								echo "<tr><td>Student Full Name</strong></td><td><strong><em>".$r->Stu_Full_Name."</strong></em></td>";
								echo "<td>Student Date of Birth</strong></td><td><strong><em>".$r->Stu_DOB."</strong></em></td></tr>";
							}?>
						</tbody>
					</table>
				</div>
				<hr>
				<div class="row">
					<h3 class="display-4">Multiple Intelligences Report</h3>
				</div>
				<div class="row">
					<div class="col">
						<table class="table table-success table-hover">
							<thead class="thead-dark">
								<tr>
									<th scope="col">ID</th>
									<th scope="col">Multiple Intelligence Type</th>
									<th scope="col">Overall Score</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($Overall_Details as $r) {
									echo "<tr><td>" . $r->MulInt_ID . "</td>";
									echo "<td>" . $r->MulInt_Name . "</td>";
									echo "<td>" . $r->AVERAGE_SCORE . "</td></tr>";
								}?>
							</tbody>
						</table>
					</div>
					<div class="col">
						<div id="piechart_3d" style="width: 700px; height: 400px;"></div>
					</div>
				</div>
				<br><br><br><br><br>
				<hr>
				<div class="row">
					<h5 class="display-5" align="center">Report Breakdown</h5>
				</div>
				<hr>
				<div class="row">
					<div class="col">
						<h5 class="display-6">From Examination Details</h5>
					</div>
					<div class="col">
						<h5 class="display-6">From Extra Curricular / Behaviour Details</h5>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<table class="table table-success table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col">ID</th>
									<th scope="col">Multiple Intelligence Type</th>
									<th scope="col">Score</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($Exam_Details as $r) {
									echo "<tr><td>" . $r->MulInt_ID . "</td>";
									echo "<td>" . $r->MulInt_Name . "</td>";
									echo "<td>" . $r->AVERAGE_SCORE . "</td></tr>";
								}?>
							</tbody>
						</table>
					</div>
					<div class="col">
						<table class="table table-success table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col">ID</th>
									<th scope="col">Multiple Intelligence Type</th>
									<th scope="col">Score</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($ExtCur_Details as $r) {
									echo "<tr><td>" . $r->MulInt_ID . "</td>";
									echo "<td>" . $r->MulInt_Name . "</td>";
									echo "<td>" . $r->AVERAGE_SCORE . "</td></tr>";
								}?>
							</tbody>
						</table>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<div id="barchart_3d_exam" style="width: 400px; height: 228px;"></div>
					</div>
					
					<div class="col">
						<div id="barchart_3d_extcur" style="width: 400px; height: 228px;"></div>
					</div>
				</div>
			</div>

			<br><br><br><br><br><br><br><br><br>

				<hr>
				<div class="row">
					<h5 class="display-5" align="center">Higher Studies and Career Options</h5>
				</div>
				<hr>
				<div class="row">
					<div class="col">
						<h5 class="display-6">Study Options</h5>
					</div>
					<div class="col">
						<h5 class="display-6">Career Options</h5>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<table class="table table-success table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col"></th>
									<th scope="col">Higher Study Type</th>
									<th scope="col">Subjects</th>
								</tr>
							</thead>
							<tbody>
								<?php $count=1; foreach ($Overall_Details as $r) {
									echo "<tr><td>" . $count . "</td>";
									echo "<td>" . $r->HighStd_Name . "</td>";
									echo "<td>" . $r->HighStd_Desc . "</td></tr>";
									$count++;
								}?>
							</tbody>
						</table>
					</div>
					<div class="col">
						<table class="table table-success table-hover table-sm">
							<thead class="thead-dark">
								<tr>
									<th scope="col"></th>
									<th scope="col">Career Option Type</th>
									<th scope="col">Description</th>
								</tr>
							</thead>
							<tbody>
								<?php $count=1; foreach ($Overall_Details as $r) {
									echo "<tr><td>" . $count . "</td>";
									echo "<td>" . $r->CarPath_Name . "</td>";
									echo "<td>" . $r->CarPath_Desc . "</td></tr>";
									$count++;
								}?>
							</tbody>
						</table>
					</div>
			</div>
		</div>
	</form>
</body>
</html>