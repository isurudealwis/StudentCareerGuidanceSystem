<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Update Examination Details</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Update Examination Details</h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form id="updateexam" method="post" action="<?php echo base_url().'index.php/ExamController/update'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<tr>
										<div class="col">
											<td>Serial No: </td>
										</div>
										<div class="col">

											<td><input type="text" name="Exam_ID" id="textfield2" value="<?php foreach ($record as $r) { echo $r->Exam_ID;}?>" readonly class="form-control">
											</td>
										</div>
									</tr>
									<div class="row">
										<tr>
											<div class="col">
												<td>Exam Year</td>
											</div>
											<div class="col">
												<td><select name="Exam_Year" class="form-control" required>
													<?php foreach ($record as $r) {?>
														<option value='' selected disabled>Select year</option>
														<option value='2019' <?php if($r->Exam_Year=='2019') {echo "selected";}?> >2019</option>
														<option value='2020'<?php if($r->Exam_Year=='2020') {echo "selected";}?>>2020</option>
														<option value='2021' <?php if($r->Exam_Year=='2021') {echo "selected";}?>>2021</option>
														<option value='2022' <?php if($r->Exam_Year=='2022') {echo "selected";}?>>2022</option>
														<option value='2023' <?php if($r->Exam_Year=='2023') {echo "selected";}?>>2023</option>
													</select>
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Exam Term</td>
											</div>
											<div class="col">
												<td><select name="Exam_Term" class="form-control" required>
													<option value='' disabled>Select Term</option>
													<?php
													$c=1;
													while ($c<=3) {
													if($r->Exam_Term==$c) {
														echo "<option value='".$c."' selected>".$c."</option>";
													}
													else {
														echo "<option value='".$c."'>".$c."</option>";
													}
													$c++;
												}?>
												</select>
											</td>
										</div>
									</tr>
								</div>
							<?php } ?>
							<div class="row">
								<tr>
									<div class="col">
										<td>Subject ID</td>
									</div>
									<div class="col">
										<td><select name="Sub_ID" class="form-control">
											<option value='' selected disabled required>Subject</option>
											<?php
											foreach ( $subjectlist as $listitem ) {
												foreach ($record as $r) {
													if ($listitem->Sub_ID == $r->Sub_ID) {
														echo "<option value='" . $listitem->Sub_ID . "' selected>" . $listitem->Sub_Name . "</option>";	
													}
													else {
														echo "<option value='" . $listitem->Sub_ID . "'>" . $listitem->Sub_Name . "</option>";
													}
												}
											}
											?>
										</select>
									</td>
								</div>
							</tr>
						</div>
						<div class="row">
							<tr>
								<div class="col">
									<td>Multiple Intelligence Type</td>
								</div>
								<div class="col">
									<td><select name="MulInt_ID" class="form-control">
										<option value='' selected disabled required>Select Mul Int Type</option>
										<?php
										foreach ( $mulintlist as $listitem ) {
											foreach ($record as $r) {
												if ($listitem->MulInt_ID == $r->MulInt_ID) {
													echo "<option value='" . $listitem->MulInt_ID . "' selected>" . $listitem->MulInt_Name . "</option>";	
												}
												else {
													echo "<option value='" . $listitem->MulInt_ID . "'>" . $listitem->MulInt_Name . "</option>";
												}
											}
										}
										?>
									</select>
								</td>
							</div>
						</tr>
					</div>
					<div class="row">
							<tr>
									<div class="col">
										<td></td>
									</div>
									<div class="col">
										<td width="600"><input type="submit" name="update" id="BUpdate" value="Update Record" class="btn btn-success" onclick="return confirm('Are you sure you want to update the Record? (Press OK to continue, Cancel to return.)')">
										</td>
									</div>
								</form>
								<form method="post" action="<?php echo base_url().'index.php/ExamController/exam'?>">
									<div class="col">
										<td width="100"><input type="submit" name="back" value="Back" class="btn btn-secondary">
										</td>
									</div>
								</form>
							</tr>
					</div>
				</tbody>
			</table>
		</div>
	</form>

	<script>
	</script>
</body>
</html>