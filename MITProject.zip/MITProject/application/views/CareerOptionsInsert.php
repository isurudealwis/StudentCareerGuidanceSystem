
<!doctype html>
	<html>

	<head>
		<meta charset="utf-8">
		<title>Insert Career Path Record</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">
	</head>

	<body>

		<div class="container">
			<div class="row">
				<div class="col">
					<h4>Insert Career Path Record </h4><br>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/CareerOptionsController/insert'?>">
						<div class=".form-group">
							<table class="table table-borderless table-sm">
								<tbody>
									<div class="row">
										<tr>
											<div class="col">
												<td>Career Path ID: </td>
											</div>
											<div class="col">
												<td><input type="text" name="CarPath_ID" value="<?php echo $id;?>"
												readonly class="form-control">
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Career Path Name</td>
											</div>
											<div class="col">
												<td><input type="text" name="CarPath_Name" value="" class="form-control" required>
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Description</td>
											</div>
											<div class="col">
												<td><input type="text" name="CarPath_Desc" value="" class="form-control" required>
												</td>
											</div>
										</tr>
									</div>
									<div class="row">
										<tr>
											<div class="col">
												<td>Multiple Intelligence Type</td>
											</div>
											<div class="col">
											<td><select name="MulInt_ID" class="form-control" required>
												<option value='' selected disabled>Select...</option>
												<?php
												foreach ( $mulintlist as $listitem ) {
													echo "<option value='" . $listitem->MulInt_ID . "'>" . $listitem->MulInt_Name . "</option>";
													}
												?>
											</select>
										</td>
									</div>
										</tr>
									</div>

								</div>
								<div class="row">
									<tr>
									<div class="col">
										<td></td>
									</div>
									<div class="col">
										<td width="600"><input type="submit" name="save" id="BInsert" value="Insert Record" class="btn btn-success" onclick="return confirm('Are you sure you want to add the Record? (Press OK to continue, Cancel to return.)')">

										</td>
									</div>
								</form>
								<form method="post" action="<?php echo base_url().'index.php/CareerOptionsController/CareerOptions'?>">
									<div class="col">
										<td width="100"><input type="submit" name="back" value="Back" class="btn btn-secondary">
										</td>
									</div>
								</form>
							</tr>
								</div>
							</tbody>
						</table>
					</div>
			</div>
			<div class="col"></div>
		</div>
	</div>
</body>

</html>