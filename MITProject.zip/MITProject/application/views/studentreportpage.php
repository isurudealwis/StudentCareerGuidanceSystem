<!doctype html>

	<?php?>
	
	<html>
	<head>
		<meta charset="utf-8">
		<title>Students Report</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lumen/bootstrap.min.css" integrity="sha384-GzaBcW6yPIfhF+6VpKMjxbTx6tvR/yRd/yJub90CqoIn2Tz4rRXlSpTFYMKHCifX" crossorigin="anonymous">

	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="col">
					<h2>Students Report Page</h2>
				</div>
				<div class="col">
					<form method="post" action="<?php echo base_url().'index.php/StudentReportController/StudentReport'?>">
						<input type="submit" name="Home" value="Home" class="btn btn-primary">
					</div>
				</div>
			</div>
			<hr>

			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-lg-offset-4 center-block">
						<div class="input-group">
							<span> Enter Student Index No: </span>
							<span><input type="text" class="form-control" name="Stu_Index_No" /> </span>
							<span class="input-group-btn">
								<input type="submit" name="getstudent" value="Get Student" class="btn btn-success">
							</span>
						</div><!-- /input-group -->
					</div><!-- /.col-lg-4 -->
				</div><!-- /.row -->
					</div>



				</form>
			</body>
			</html>