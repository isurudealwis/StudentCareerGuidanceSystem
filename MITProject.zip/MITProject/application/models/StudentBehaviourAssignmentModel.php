        <?php
        class StudentBehaviourAssignmentModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }

        public function FetchData() {
            $query="";

            $column = $_SESSION['column'];
            $keyword = $_SESSION['keyword'];
            
            if (empty($column) && !empty($keyword)) {
                $query = "SELECT tbl_stu_extbehactivity.StuExt_ID AS StuExt_ID, tbl_stu_extbehactivity.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_stu_extbehactivity.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_stu_extbehactivity.StuExt_Points AS StuExt_Points
                FROM ((tbl_stu_extbehactivity AS tbl_stu_extbehactivity
                INNER JOIN tbl_student AS tbl_student ON ( tbl_stu_extbehactivity.Stu_ID  = tbl_student.Stu_ID  ))
                INNER JOIN tbl_behavioural_activities AS tbl_behavioural_activities ON ( tbl_behavioural_activities.BehAct_ID  = tbl_stu_extbehactivity.BehAct_ID  ))
                WHERE (
                tbl_stu_extbehactivity.StuExt_ID LIKE '%$keyword%' OR 
                tbl_stu_extbehactivity.Stu_ID LIKE '%$keyword%' OR 
                tbl_student.Stu_Full_Name LIKE '%$keyword%' OR 
                tbl_student.Stu_Index_No LIKE '%$keyword%' OR
                tbl_stu_extbehactivity.BehAct_ID LIKE '%$keyword%' OR
                tbl_behavioural_activities.BehAct_Name LIKE '%$keyword%' OR 
                tbl_stu_extbehactivity.StuExt_Points LIKE '%$keyword%' )
                ORDER BY  tbl_stu_extbehactivity.StuExt_ID";
           }

           else if (!empty($column) && !empty($keyword)) {
            $query = "SELECT tbl_stu_extbehactivity.StuExt_ID AS StuExt_ID, tbl_stu_extbehactivity.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_stu_extbehactivity.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_stu_extbehactivity.StuExt_Points AS StuExt_Points
                FROM ((tbl_stu_extbehactivity AS tbl_stu_extbehactivity
                INNER JOIN tbl_student AS tbl_student ON ( tbl_stu_extbehactivity.Stu_ID  = tbl_student.Stu_ID  ))
                INNER JOIN tbl_behavioural_activities AS tbl_behavioural_activities ON ( tbl_behavioural_activities.BehAct_ID  = tbl_stu_extbehactivity.BehAct_ID  ))
                WHERE ($column LIKE '%$keyword%')
                ORDER BY  tbl_stu_extbehactivity.StuExt_ID";
           }

        else {
             $query = "SELECT tbl_stu_extbehactivity.StuExt_ID AS StuExt_ID, tbl_stu_extbehactivity.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_stu_extbehactivity.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_stu_extbehactivity.StuExt_Points AS StuExt_Points
                FROM ((tbl_stu_extbehactivity AS tbl_stu_extbehactivity
                INNER JOIN tbl_student AS tbl_student ON ( tbl_stu_extbehactivity.Stu_ID  = tbl_student.Stu_ID  ))
                INNER JOIN tbl_behavioural_activities AS tbl_behavioural_activities ON ( tbl_behavioural_activities.BehAct_ID  = tbl_stu_extbehactivity.BehAct_ID  ))
                ORDER BY  tbl_stu_extbehactivity.StuExt_ID";
        }

        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }

    public function FetchBehaviouralActivity() {
        $query = "SELECT BehAct_ID, BehAct_Name FROM tbl_behavioural_activities";
        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }

    public function newid() {
        $query = "SELECT StuExt_ID FROM tbl_stu_extbehactivity ORDER BY StuExt_ID DESC LIMIT 1";
        $result=$this->db->query($query);
        if($result->num_rows()==0) {
            return 'SE0001';
        }
        else {
            foreach($result->result() as $r) {
                $id=substr($r->StuExt_ID,2);
                $newvalue=$id+1;
                $newid='SE'.str_pad($newvalue,4,"0",STR_PAD_LEFT);
                return $newid;
            }
            
        }
    }

    public function insert($id, $sid, $aid, $points, $tid) {
        $result="";
        $query="INSERT INTO tbl_stu_extbehactivity VALUES ('$id', '$sid', '$aid', '$points', '$tid', now())";
        if($this->db->query($query)) {
            $result = "Record Successfully added!";
        }
        else{
            $result= "Unable to add record. Please Re-check.";
        }
        return $result;
    }


    public function FetchRecord($StuExt_ID) {

            $query = "SELECT tbl_stu_extbehactivity.StuExt_ID AS StuExt_ID, tbl_stu_extbehactivity.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_stu_extbehactivity.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_stu_extbehactivity.StuExt_Points AS StuExt_Points
                FROM ((tbl_stu_extbehactivity AS tbl_stu_extbehactivity
                INNER JOIN tbl_student AS tbl_student ON ( tbl_stu_extbehactivity.Stu_ID  = tbl_student.Stu_ID  ))
                INNER JOIN tbl_behavioural_activities AS tbl_behavioural_activities ON ( tbl_behavioural_activities.BehAct_ID  = tbl_stu_extbehactivity.BehAct_ID  ))
                WHERE (tbl_stu_extbehactivity.StuExt_ID = '$StuExt_ID')";
        
        $result = $this->db->query($query);
        return $result->result();
    }

    public function update($id, $sid, $aid, $points, $tid) {
        $result="";
        $query="UPDATE tbl_stu_extbehactivity SET Stu_ID='$sid', BehAct_ID='$aid', StuExt_Points='$points', Tea_ID='$tid' WHERE StuExt_ID='$id'";
            if($this->db->query($query)){
                $result="Record updated successfully!";
            }
            else {
                $result="Unable to update record. Please try again.";
            }
            return $result;
    }

    public function delete($id) {
        $result="";
        $query="DELETE FROM tbl_stu_extbehactivity WHERE StuExt_ID='$id'";
        if($this->db->query($query)){
            $result = "Record deleted successfully!";
        }
        else {
            $result = "Unable to delete the record. Please try again.";
        }

        return $result;
    }


    public function FetchStudent() {
        $admissionno = $_SESSION['Stu_Index_No'];
        $query="SELECT * FROM tbl_student WHERE Stu_Index_No='$admissionno'";    
        $result = $this->db->query($query);
        return $result->result();
    }
    
}
