<?php
class MODELDB extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    //Login Check
    public function login( $details ) {
        $uid = $details[ 'userid' ];
        $pw = $details[ 'password' ];

        $query = "SELECT Tea_ID, Tea_First_Name, Tea_Last_Name, Tea_StaffAdmin FROM tbl_teacher WHERE(Tea_ID = '$uid' AND Tea_Password = md5('$pw'))";
        $DBResult = $this->db->query( $query );
        return $DBResult->result();
    }
//-------------------------------------------------------------------------------------------
    //Below all for students controller
    public function fetchstudentrecord($id) {
        $query="SELECT * FROM tbl_Student WHERE Stu_ID='$id'";   
        $result = $this->db->query($query);
        return $result->result();
    }

    public function fetchstudentindexno($id) {
        $query="SELECT Stu_Index_No FROM tbl_Student WHERE Stu_Index_No='$id'";   
        $result = $this->db->query($query);
        return $result->result();
    }

    public function currentstudentindexno($id) {
        $query="SELECT Stu_Index_No FROM tbl_Student WHERE Stu_ID='$id'";
        $result= $this->db->query($query);
        foreach($result->result() as $row){
            $result=$row->Stu_Index_No;
        }
        return $result;
    }

    public function insert($sid,$sfname,$siname,$sindno,$sdob,$stelhome,$stelmob,$semail) {
        $result="";
        if (($this->db->query("INSERT INTO tbl_student VALUES ('$sid','$sfname','$siname','$sindno','$sdob','$stelhome','$stelmob','$semail')"))){
            $result="Record added Successfully!";
        }
        else {
            $result="Unable to add the record. Please try again.";
        }
        return $result;
    }

    public function update($sid,$sfname,$siname,$sindno,$sdob,$stelhome,$stelmob,$semail) {
        $result="";
        if (($this->db->query("UPDATE tbl_student SET Stu_Full_Name='$sfname',Stu_Init_Name='$siname',Stu_Index_No='$sindno',Stu_DOB='$sdob', Stu_Home_Tel='$stelhome', Stu_Mobile_Tel='$stelmob', Stu_Email='$semail' WHERE Stu_ID='$sid';"))){
            $result="Record updated successfully!";
        }
        else {
            $result="Unable to update the record. Please try again.";
        }
        return $result;
    }

    public function delete($sid) {
        $result="";
        $query="DELETE FROM tbl_student WHERE Stu_ID='$sid'";
        if($this->db->query($query)) {
            $result="Record deleted successfully!";
        }
        else {
            $result="Unable to delete the record. Please try again.";
        }
        return $result;
    }

    public function fetchstudentid() {
        $query="SELECT Stu_ID FROM tbl_student ORDER BY stu_ID DESC LIMIT 1";
        $new_ID=$this->db->query($query);
        return $new_ID->result();
    }

    public function FetchStudentData($Details) {
        $query="";
        if($Details['keyword']=='') {
            $query = "SELECT * FROM tbl_Student ORDER BY Stu_ID";
        }
        elseif($Details['keyword']!='' && $Details['ColumnSelected']=='') {
            $keyword=$Details['keyword'];
            $query="SELECT * FROM tbl_student WHERE Stu_ID LIKE '%$keyword%' OR Stu_Full_Name LIKE '%$keyword%' OR Stu_Init_Name LIKE '%$keyword%' OR Stu_Index_No LIKE '%$keyword%' OR Stu_DOB LIKE '%$keyword%' OR Stu_Home_Tel LIKE '%$keyword%' OR Stu_Mobile_Tel LIKE '%$keyword%' OR Stu_Email LIKE '%$keyword%' ORDER BY Stu_ID";
        }
        elseif($Details['keyword']!='' && $Details['ColumnSelected']!='') {
            $keyword=$Details['keyword'];
            $column = $Details['ColumnSelected'];
            $query="SELECT * FROM tbl_Student WHERE $column LIKE '%$keyword%' ORDER BY Stu_ID";
        }
        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }

}
?>
