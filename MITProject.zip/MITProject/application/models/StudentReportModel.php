        <?php
        class StudentReportModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }


            public function CheckStudent ($id) {
                $query="SELECT * from tbl_student WHERE Stu_Index_No='$id'";
                $result=$this->db->query($query);
                if($result->num_rows>0) {
                    return true;
                }
                else {
                    return false;
                }
            }
            public function FetchStudentData($id) {
                $query="SELECT * from tbl_student WHERE Stu_Index_No='$id'";
                $result=$this->db->query($query);
                return $result->result();
            }


            public function FetchOverallData($id) {
                $query="SELECT Stu_ID, Stu_Index_No, Stu_Full_Name, Stu_DOB, MulInt_ID, MulInt_Name, ROUND(avg(AVERAGE_SCORE),2) AS AVERAGE_SCORE, HighStd_Name, HighStd_Desc, CarPath_Name, CarPath_Desc
                FROM (
                SELECT STU.STU_ID AS Stu_ID, STU.STU_INDEX_NO AS Stu_Index_No, STU.STU_FULL_NAME AS Stu_Full_Name, STU.STU_DOB AS Stu_DOB, EX.MULINT_ID AS MulInt_ID, MUL.MULINT_NAME AS MulInt_Name, ROUND(AVG(M.MRK_MARK),2) AS AVERAGE_SCORE, HS.HighStd_Name AS HighStd_Name, HS.HighStd_Desc AS HighStd_Desc, CP.CarPath_Name AS CarPath_Name, CP.CarPath_Desc AS CarPath_Desc
                FROM TBL_MARKS AS M
                INNER JOIN TBL_EXAMINATION AS EX ON EX.EXAM_ID = M.EXAM_ID
                INNER JOIN TBL_STUDENT_SUBJECT AS SS ON M.STUSUB_ID = SS.STUSUB_ID
                INNER JOIN TBL_SUBJECT AS S ON S.SUB_ID = SS.SUB_ID
                INNER JOIN TBL_STUDENT AS STU ON STU.STU_ID = SS.STU_ID
                INNER JOIN TBL_MULINT_CATEGORIES AS MUL ON EX.MULINT_ID = MUL.MULINT_ID
                LEFT JOIN TBL_HIGHERSTUDIES AS HS ON HS.MULINT_ID = EX.MULINT_ID
                LEFT JOIN TBL_CAREERPATHS AS CP ON CP.MULINT_ID = EX.MULINT_ID
                WHERE STU.STU_INDEX_NO = $id
                GROUP BY MULINT_ID
                UNION ALL
                SELECT STU.STU_ID AS Stu_ID, STU.STU_INDEX_NO AS Stu_Index_No, STU.STU_FULL_NAME AS Stu_Full_Name, STU.STU_DOB AS Stu_DOB, BEHACT.MULINT_ID AS MulInt_ID, MUL.MULINT_NAME AS MulInt_Name, ROUND(AVG(SEB.STUEXT_POINTS),2) AS AVERAGE_SCORE, HS.HighStd_Name AS HighStd_Name, HS.HighStd_Desc AS HighStd_Desc, CP.CarPath_Name AS CarPath_Name, CP.CarPath_Desc AS CarPath_Desc
                FROM TBL_STU_EXTBEHACTIVITY AS SEB
                INNER JOIN TBL_STUDENT AS STU ON STU.STU_ID = SEB.STU_ID
                INNER JOIN TBL_BEHAVIOURAL_ACTIVITIES AS BEHACT ON BEHACT.BEHACT_ID = SEB.BEHACT_ID
                INNER JOIN TBL_MULINT_CATEGORIES AS MUL ON MUL.MULINT_ID = BEHACT.MULINT_ID
                LEFT JOIN TBL_HIGHERSTUDIES AS HS ON HS.MULINT_ID = BEHACT.MULINT_ID
                LEFT JOIN TBL_CAREERPATHS AS CP ON CP.MULINT_ID = BEHACT.MULINT_ID
                WHERE STU.STU_INDEX_NO = $id
                GROUP BY MULINT_ID) S1
                GROUP BY MULINT_ID
                ORDER BY AVERAGE_SCORE DESC
                LIMIT 5
                ";
                $result=$this->db->query($query);
                return $result->result();
            }


            public function FetchExamData($id) {
                $query="SELECT STU.STU_ID AS Stu_ID, STU.STU_INDEX_NO AS Stu_Index_No, STU.STU_FULL_NAME AS Stu_Full_Name, STU.STU_DOB AS Stu_DOB, EX.MULINT_ID AS MulInt_ID, MUL.MULINT_NAME AS MulInt_Name, ROUND(AVG(M.MRK_MARK),2) AS AVERAGE_SCORE, HS.HighStd_Name AS HighStd_Name, HS.HighStd_Desc AS HighStd_Desc, CP.CarPath_Name AS CarPath_Name, CP.CarPath_Desc AS CarPath_Desc
                FROM TBL_MARKS AS M
                INNER JOIN TBL_EXAMINATION AS EX ON EX.EXAM_ID = M.EXAM_ID
                INNER JOIN TBL_STUDENT_SUBJECT AS SS ON M.STUSUB_ID = SS.STUSUB_ID
                INNER JOIN TBL_SUBJECT AS S ON S.SUB_ID = SS.SUB_ID
                INNER JOIN TBL_STUDENT AS STU ON STU.STU_ID = SS.STU_ID
                INNER JOIN TBL_MULINT_CATEGORIES AS MUL ON EX.MULINT_ID = MUL.MULINT_ID
                LEFT JOIN TBL_HIGHERSTUDIES AS HS ON HS.MULINT_ID = EX.MULINT_ID
                LEFT JOIN TBL_CAREERPATHS AS CP ON CP.MULINT_ID = EX.MULINT_ID
                WHERE STU.STU_INDEX_NO = $id
                GROUP BY MULINT_ID
                ORDER BY AVERAGE_SCORE DESC
                LIMIT 5";

                $result=$this->db->query($query);
                return $result->result();
            }


            public function FetchExtCurData($id) {
                $query="SELECT STU.STU_ID AS Stu_ID, STU.STU_INDEX_NO AS Stu_Index_No, STU.STU_FULL_NAME AS Stu_Full_Name, STU.STU_DOB AS Stu_DOB, BEHACT.MULINT_ID AS MulInt_ID, MUL.MULINT_NAME AS MulInt_Name, ROUND(AVG(SEB.STUEXT_POINTS),2) AS AVERAGE_SCORE, HS.HighStd_Name AS HighStd_Name, HS.HighStd_Desc AS HighStd_Desc, CP.CarPath_Name AS CarPath_Name, CP.CarPath_Desc AS CarPath_Desc
                FROM TBL_STU_EXTBEHACTIVITY AS SEB
                INNER JOIN TBL_STUDENT AS STU ON STU.STU_ID = SEB.STU_ID
                INNER JOIN TBL_BEHAVIOURAL_ACTIVITIES AS BEHACT ON BEHACT.BEHACT_ID = SEB.BEHACT_ID
                INNER JOIN TBL_MULINT_CATEGORIES AS MUL ON MUL.MULINT_ID = BEHACT.MULINT_ID
                LEFT JOIN TBL_HIGHERSTUDIES AS HS ON HS.MULINT_ID = BEHACT.MULINT_ID
                LEFT JOIN TBL_CAREERPATHS AS CP ON CP.MULINT_ID = BEHACT.MULINT_ID
                WHERE STU.STU_INDEX_NO = $id
                GROUP BY MULINT_ID
                ORDER BY AVERAGE_SCORE DESC";
                $result=$this->db->query($query);
                return $result->result();
            }

        }
    ?>