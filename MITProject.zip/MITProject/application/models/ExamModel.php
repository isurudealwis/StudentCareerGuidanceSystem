        <?php
        class ExamModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }

            //Load Data to the dropdownlists
            public function GetDropDownFields($field) {

                //Get Subject List
                if ($field=='subjectlist') {
                   $DBResult=$this->db->query("SELECT DISTINCT Sub_ID, Sub_Name FROM tbl_subject");
               }

               //Get Year List
               else if ($field=='yearlist') {
                $DBResult=$this->db->query("SELECT DISTINCT tbl_examination.Exam_Year AS Exam_Year FROM tbl_examination ORDER BY Exam_Year");
            }

              //Get Multiple Intelligence List
            else if ($field=='mulintlist') {
                $DBResult=$this->db->query("SELECT DISTINCT MulInt_ID, MulInt_Name FROM tbl_mulint_categories ORDER BY MulInt_ID");
            }

            return $DBResult->result();
        }


            //Load Examination Data to the ExamPage Main Table
        public function FetchExamData($Details) {
            $query="";

            $k = $Details['keyword'];
            $y = $Details['year'];
            $cs = $Details['ColumnSelected'];

            //Only Keyword is filled
            if($k!='' && $y=='' && $cs=='') {
             $query = "SELECT tbl_examination.Exam_ID AS Exam_ID, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_examination.Sub_ID AS Sub_ID, tbl_examination.MulInt_ID AS MulInt_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
             FROM ((tbl_examination AS tbl_examination
             INNER JOIN tbl_subject AS tbl_subject ON ( tbl_examination.Sub_ID  = tbl_subject.Sub_ID  ))
             INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_examination.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
             WHERE(
             tbl_examination.Exam_ID LIKE '%$k%' OR 
             tbl_examination.Exam_Term LIKE '%$k%' OR 
             tbl_examination.Sub_ID LIKE '%$k%' OR 
             tbl_subject.Sub_Name LIKE '%$k%' OR
             tbl_examination.MulInt_ID LIKE '%$k%' OR
             tbl_mulint_categories.MulInt_Name LIKE '%$k%')
             ORDER BY tbl_examination.Exam_ID DESC"; 
         }

            //Only year is filled
         else if($k=='' && $y!='' && $cs=='') {
             $query = "SELECT tbl_examination.Exam_ID AS Exam_ID, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_examination.Sub_ID AS Sub_ID, tbl_examination.MulInt_ID AS MulInt_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
             FROM ((tbl_examination AS tbl_examination
             INNER JOIN tbl_subject AS tbl_subject ON ( tbl_examination.Sub_ID  = tbl_subject.Sub_ID  ))
             INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_examination.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
             WHERE(tbl_examination.Exam_Year = '$y') ORDER BY Exam_ID DESC";
         }

            //Keyword and ColumnSelected is filled
         else if ($k!='' && $y=='' && $cs!='') {
            $query = "SELECT tbl_examination.Exam_ID AS Exam_ID, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_examination.Sub_ID AS Sub_ID, tbl_examination.MulInt_ID AS MulInt_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
            FROM ((tbl_examination AS tbl_examination
            INNER JOIN tbl_subject AS tbl_subject ON ( tbl_examination.Sub_ID  = tbl_subject.Sub_ID  ))
            INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_examination.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
            WHERE $cs LIKE '%$k%' ORDER BY Exam_ID DESC";
        }

            //All three (03) fields filled
        else if ($k!='' && $y!='' && $cs!='') {
            $query = "SELECT tbl_examination.Exam_ID AS Exam_ID, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_examination.Sub_ID AS Sub_ID, tbl_examination.MulInt_ID AS MulInt_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
            FROM ((tbl_examination AS tbl_examination
            INNER JOIN tbl_subject AS tbl_subject ON ( tbl_examination.Sub_ID  = tbl_subject.Sub_ID  ))
            INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_examination.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
            WHERE $cs LIKE '%$k%' AND Exam_Year='$y' ORDER BY Exam_ID DESC";
        }

            //All 3 fields blank
        else {
            $query = "SELECT tbl_examination.Exam_ID AS Exam_ID, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_examination.Sub_ID AS Sub_ID, tbl_examination.MulInt_ID AS MulInt_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
            FROM ((tbl_examination AS tbl_examination
            INNER JOIN tbl_subject AS tbl_subject ON ( tbl_examination.Sub_ID  = tbl_subject.Sub_ID  ))
            INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_examination.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
            ORDER BY Exam_ID DESC";
        }

        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }

    public function fetchexamid() {
        $query="SELECT Exam_ID FROM tbl_examination ORDER BY Exam_ID DESC LIMIT 1";
        $new_ID=$this->db->query($query);
        return $new_ID->result();
    }

    //For the Insert Page
    public function insertrecord($Exam_ID,$Exam_Year,$Exam_Term,$Sub_ID,$MulInt_ID) {
        $result="";
        $query="INSERT INTO tbl_examination VALUES ('$Exam_ID', '$Exam_Year', '$Exam_Term', '$Sub_ID', '$MulInt_ID',now())";
        if($this->db->query($query)){
            $result = "Record Added Successfully!";
        }
        else{
            $result = "Unable to add the record. Please Try again.";
        }
        return $result;
    }

    //For the Update page
    public function FetchUpdateData($Exam_ID) {
        $query = "SELECT tbl_examination.Exam_ID AS Exam_ID, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_examination.Sub_ID AS Sub_ID, tbl_examination.MulInt_ID AS MulInt_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
        FROM ((tbl_examination AS tbl_examination
        INNER JOIN tbl_subject AS tbl_subject ON ( tbl_examination.Sub_ID  = tbl_subject.Sub_ID  ))
        INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_examination.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
        WHERE Exam_ID='$Exam_ID' ORDER BY Exam_ID DESC LIMIT 1";

        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }

    public function update($Exam_ID,$Exam_Year,$Exam_Term,$Sub_ID,$MulInt_ID) {
        $result="";
        $query="UPDATE tbl_examination SET Exam_Year='$Exam_Year',Exam_Term='$Exam_Term',Sub_ID='$Sub_ID',MulInt_ID='$MulInt_ID' WHERE Exam_ID='$Exam_ID'";
        if($result=$this->db->query($query)){
            $result="Record updated successfully!";
        }
        else {
            $result="Unable to update the record. Please retry.";
        }
        return $result;
    }

    public function fetchexamrecord($id) {
        if($id=='') {
            $query="SELECT * FROM tbl_examination WHERE Exam_ID = '-1' ";    
        }
        else {
            $query="SELECT * FROM tbl_examination WHERE Exam_ID = '$id' LIMIT 1";    
        }

        $result = $this->db->query($query);
        return $result->result();
    }

        //To Delete
    public function examdelete($exid) {
        $result="";
        $query="DELETE FROM tbl_examination WHERE Exam_ID='".$exid."'";
        if($this->db->query($query)){
            $result = "Record deleted Successfully!";
        }
        else {
            $result= "Unable to delete the record.";
        }
        return $result;
    }

}