        <?php
        class TeacherReportModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }


            public function getteacherlist () {
            $query="SELECT * from tbl_teacher";
            $result=$this->db->query($query);
            return $result->result();
        }
        public function FetchTeacherData($id) {
            $query="SELECT * from tbl_teacher WHERE Tea_ID='$id'";
            $result=$this->db->query($query);
            return $result->result();
        }


        public function FetchData($id,$type) {
            if ($type=='GetOverallPerformance') {
                $query="SELECT ROUND(AVG(M.Mrk_Mark),2) AS MARKS_AVERAGE
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY T.Tea_ID";
            }

            else if ($type=='GetYearlyPerformance') {
                $query="SELECT EX.Exam_Year AS Exam_Year, ROUND(AVG(M.Mrk_Mark),2) AS MARKS_AVERAGE
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY Ex.Exam_Year
            ORDER BY Ex.Exam_Year ASC LIMIT 5";
            }

            else if ($type=='L3EP') {
                $query="SELECT EX.EXAM_YEAR AS EXAM_YEAR, EX.Exam_Term AS Exam_Term, EX.SUB_ID AS Sub_ID, SUB.SUB_NAME AS SUBJECT_NAME, ROUND(AVG(M.Mrk_Mark),2) AS AVERAGE_MARKS
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            EXAM_YEAR = YEAR(curdate())-1 AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY SS.SUB_ID, EX.EXAM_YEAR, EX.EXAM_TERM
            ORDER BY EX.Exam_Year DESC, EX.EXAM_TERM";
            }

            else if ($type=='L3EP2') {
                $query="SELECT EX.EXAM_YEAR AS EXAM_YEAR, EX.Exam_Term AS Exam_Term, EX.SUB_ID AS Sub_ID, SUB.SUB_NAME AS SUBJECT_NAME, ROUND(AVG(M.Mrk_Mark),2) AS AVERAGE_MARKS
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY SS.SUB_ID, EX.EXAM_YEAR, EX.EXAM_TERM
            ORDER BY EX.Exam_Year DESC, EX.EXAM_TERM";
            }

            elseif($type=='DistinctSubjects') {
                $query="SELECT DISTINCT SUB.SUB_NAME AS SUBJECT_NAME, SUB.Sub_ID as Sub_ID
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            ORDER BY SUBJECT_NAME";
            }

            elseif($type=="MIAttributes") {
                $query="SELECT EX.Exam_Year AS Exam_Year, MUL.MulInt_ID AS MulInt_ID, MUL.MulInt_Name AS MulInt_Name, ROUND(AVG(M.Mrk_Mark),2) AS AVERAGE_SCORE
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY Exam_Year, MulInt_ID
            ORDER BY Exam_Year DESC, MulInt_ID DESC, AVERAGE_SCORE DESC";
            }

            elseif($type=='DistinctYear') {
                $query="SELECT DISTINCT EX.Exam_Year AS Exam_Year
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY Exam_Year
            ORDER BY Exam_Year";
            }

            elseif($type=='YearTerm') {
                $query="SELECT DISTINCT EX.EXAM_YEAR AS EXAM_YEAR, EX.Exam_Term AS Exam_Term
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY SS.SUB_ID, EX.EXAM_YEAR, EX.EXAM_TERM
            ORDER BY EXAM_YEAR, Exam_Term";
            }

            elseif($type=='DistinctMI') {
                $query="SELECT DISTINCT MUL.MulInt_ID as MulInt_ID, MUL.MulInt_Name AS MulInt_Name, ROUND(AVG(M.Mrk_Mark),2) AS AVERAGE_SCORE
            FROM tbl_student_subject AS SS
            INNER JOIN tbl_student AS S ON ( S.Stu_ID  = SS.Stu_ID )
            INNER JOIN tbl_examination AS EX ON ( EX.Sub_ID  = SS.Sub_ID AND EX.Exam_Year = SS.StuSub_Year )
            INNER JOIN tbl_student_class AS SC ON ( SC.Stu_ID  = SS.Stu_ID  )
            INNER JOIN tbl_class AS C ON ( C.Cls_ID  = SC.Cls_ID AND EX.Exam_Year = SC.StuCls_Year  )
            INNER JOIN tbl_subject AS SUB ON ( SS.Sub_ID  = SUB.Sub_ID  )
            INNER JOIN tbl_teacher_subject_class AS TSC ON (TSC.Cls_ID = SC.Cls_ID  AND TSC.Sub_ID = EX.Sub_ID AND TSC.TeaSub_Year=EX.Exam_Year)            
            INNER JOIN tbl_teacher AS T ON (TSC.Tea_ID = T.Tea_ID)
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = EX.Exam_ID AND m.StuSub_ID = SS.StuSub_ID)
            INNER JOIN tbl_mulint_categories AS MUL on (mul.MulInt_ID = ex.MulInt_ID)
            WHERE(
            T.Tea_ID = '$id' AND
            M.Mrk_ID IS NOT NULL)
            GROUP BY MulInt_ID
            ORDER BY AVERAGE_SCORE desc";
            }


            $result=$this->db->query($query);
            return $result->result();
        }

}
?>