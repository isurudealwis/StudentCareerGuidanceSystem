<?php
class TeacherDB extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    //Get Teacher data to load to the table
    public function FetchTeacherData($Details) {
        $query="";
        if($Details['keyword']=='') {
            $query = "SELECT * FROM tbl_Teacher ORDER BY Tea_ID";
        }
        elseif($Details['keyword']!='' && $Details['ColumnSelected']=='') {
            $keyword=$Details['keyword'];
            $query="SELECT * FROM tbl_teacher WHERE Tea_ID LIKE '%$keyword%' OR Tea_First_Name LIKE '%$keyword%' OR Tea_Last_Name LIKE '%$keyword%' OR Tea_NIC_No LIKE '%$keyword%' OR Tea_DOB LIKE '%$keyword%' OR Tea_Home_Tel LIKE '%$keyword%' OR Tea_Mobile_Tel LIKE '%$keyword%' OR Tea_Email LIKE '%$keyword%' OR Tea_StaffAdmin LIKE '%$keyword%' ORDER BY Tea_ID";
        }
        elseif($Details['keyword']!='' && $Details['ColumnSelected']!='') {
            $keyword=$Details['keyword'];
            $column = $Details['ColumnSelected'];
            $query="SELECT * FROM tbl_Teacher WHERE $column LIKE '%$keyword%' ORDER BY Tea_ID";
        }
        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }

    //Get the last teacher ID for the Insert page
    public function fetchteacherid() {
        $query="SELECT Tea_ID FROM tbl_teacher ORDER BY Tea_ID DESC LIMIT 1";
        $new_ID=$this->db->query($query);
        return $new_ID->result();
    }


    public function fetchteacherrecord($id) {
        $query="SELECT * FROM tbl_Teacher WHERE Tea_ID='$id'";   
        $result = $this->db->query($query);
        return $result->result();
    }


    public function insert($tid,$tfname,$tlname,$tnicno,$tdob,$ttelhome,$ttelmob,$temail, $tadmin, $tpw) {
        $result="";
        if($this->db->query("INSERT INTO tbl_teacher VALUES ('$tid','$tfname','$tlname','$tnicno','$tdob','$ttelhome','$ttelmob','$temail','$tpw','$tadmin')")){
            $result="Record added Successfully!";
        }
        else {
            $result="Unable to add the record. Please try again.";
        }
        return $result;
    }

    public function update($tid,$tfname,$tlname,$tdob,$ttelhome,$ttelmob,$temail,$tpw,$tadmin) {
        $result="";
        $query="";
        //1. Check whether the password has changed.
        if($tpw==""){
            $query="UPDATE tbl_teacher SET Tea_First_Name='$tfname',Tea_Last_Name='$tlname',Tea_DOB='$tdob', Tea_Home_Tel='$ttelhome', Tea_Mobile_Tel='$ttelmob', Tea_Email='$temail', Tea_StaffAdmin='$tadmin' WHERE Tea_ID='$tid';";
        }
        else {
            $query="UPDATE tbl_teacher SET Tea_First_Name='$tfname',Tea_Last_Name='$tlname',Tea_DOB='$tdob', Tea_Home_Tel='$ttelhome', Tea_Mobile_Tel='$ttelmob', Tea_Email='$temail', Tea_Password=md5('$tpw'), Tea_StaffAdmin='$tadmin' WHERE Tea_ID='$tid';";   
        }

        //2. Execute the query     
        if(($this->db->query($query))) {
            $result="Record updated successfully!";
        }
        else {
            $result="Unable to update the record. Please try again.";
        }
        return $result;
    }


    public function delete($tid) {
        
        $result="";
        if($this->db->query("DELETE FROM tbl_teacher WHERE Tea_ID='".$tid."'")){
            $result="Record deleted Successfully!";
        }
        else {
            $result="Unable to delete the record. Please try again.";
        }
        return $result;
    }


    

}
?>
