        <?php
        class CareerOptionsModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }

            public function FetchData() {
                $query="";

                $column = $_SESSION['column'];
                $keyword = $_SESSION['keyword'];
                
                if (empty($column) && !empty($keyword)) {
                    $query = "SELECT tbl_careerpaths.CarPath_ID AS CarPath_ID, tbl_careerpaths.CarPath_Name AS CarPath_Name, tbl_careerpaths.CarPath_Desc AS CarPath_Desc, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
                    FROM (tbl_careerpaths AS tbl_careerpaths
                    INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_careerpaths.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
                    WHERE(
                    tbl_careerpaths.CarPath_ID LIKE '%$keyword%' OR 
                    tbl_careerpaths.CarPath_Name LIKE '%$keyword%' OR 
                    tbl_careerpaths.CarPath_Desc LIKE '%$keyword%' OR 
                    tbl_mulint_categories.MulInt_Name LIKE '%$keyword%' )
                    ORDER BY  tbl_careerpaths.CarPath_ID";
                }

                else if (!empty($column) && !empty($keyword)) {
                    $query = "SELECT tbl_careerpaths.CarPath_ID AS CarPath_ID, tbl_careerpaths.CarPath_Name AS CarPath_Name, tbl_careerpaths.CarPath_Desc AS CarPath_Desc, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
                    FROM (tbl_careerpaths AS tbl_careerpaths
                    INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_careerpaths.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
                    WHERE(
                    $column LIKE '%$keyword%')
                    ORDER BY  tbl_careerpaths.CarPath_ID";
                }

                else {
                   $query = "SELECT tbl_careerpaths.CarPath_ID AS CarPath_ID, tbl_careerpaths.CarPath_Name AS CarPath_Name, tbl_careerpaths.CarPath_Desc AS CarPath_Desc, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
                   FROM (tbl_careerpaths AS tbl_careerpaths
                   INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_careerpaths.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
                   ORDER BY  tbl_careerpaths.CarPath_ID";
               }

               $DBResult=$this->db->query($query);
               return $DBResult->result();
           }


           public function newid() {
            $query = "SELECT CarPath_ID FROM tbl_careerpaths ORDER BY CarPath_ID DESC LIMIT 1";
            $result=$this->db->query($query);
            if($result->num_rows()==0) {
                return 'CP001';
            }
            else {
                foreach($result->result() as $r) {
                    $id=substr($r->CarPath_ID,2);
                    $newvalue=$id+1;
                    $newid='CP'.str_pad($newvalue,3,"0",STR_PAD_LEFT);
                    return $newid;
                }
                
            }
        }

        public function insert($id, $name, $desc, $mulint) {
            $result="";
            $query="INSERT INTO tbl_careerpaths VALUES ('$id', '$name', '$desc', '$mulint')";
            if($this->db->query($query)){
                $result="Record added Successfully!";
            }
            else{
                $result="Unable to add record. Please Re-check the details.";
            }
            return $result;
        }


        public function getrecord($id) {
            $query = "SELECT * FROM tbl_careerpaths WHERE CarPath_ID = '$id'";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function getmulintlist() {
            $query = "SELECT MulInt_ID, MulInt_Name FROM tbl_mulint_categories";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function update($id, $name, $desc, $mulint) {
            $result="";
            $query="UPDATE tbl_careerpaths SET CarPath_Name='$name', CarPath_Desc='$desc', MulInt_ID='$mulint' WHERE CarPath_ID='$id'";
            $result = $this->db->query($query);
            if($this->db->query($query)){
                $result="Record updated Successfully!";
            }
            else{
                $result="Unable to update the record. Please Re-check the details.";
            }
            return $result;
        }

        public function delete($id) {
            $result="";
            $query="DELETE FROM tbl_careerpaths WHERE CarPath_ID='$id'";
            if($this->db->query($query)){
                $result="Record deleted Successfully!";
            }
            else{
                $result="Unable to delete record. Please Re-check the details.";
            }
            return $result;
        }
        
    }
