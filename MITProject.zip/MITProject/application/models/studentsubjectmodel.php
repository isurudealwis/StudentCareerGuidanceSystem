<?php
class StudentSubjectModel extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

            //Fill Dropdown Lists (ON Main Page)
    public function GetDropDownFields($field) {
        if ($field=='subjectlist') {
         $DBResult=$this->db->query("SELECT DISTINCT Sub_ID, Sub_Name FROM tbl_subject");
     }

     else if ($field=='yearlist') {
        $DBResult=$this->db->query("SELECT DISTINCT tbl_student_subject.StuSub_Year AS StuSub_Year FROM tbl_student_subject ORDER BY StuSub_Year");
    }

    return $DBResult->result();
}


public function FetchStudentSubjectData($Details) {
    $query="";

    $k = $Details['keyword'];
    $y = $Details['year'];
    $cs = $Details['ColumnSelected'];

            //Only Keyword is filled
    if($k!='' && $y=='' && $cs=='') {
       $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
       FROM ((tbl_student_subject AS tbl_student_subject
       INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
       INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
       WHERE
       tbl_student_subject.StuSub_ID LIKE '%$k' OR tbl_student_subject.Stu_ID LIKE '%$k' OR tbl_student.Stu_Index_No LIKE '%$k' OR tbl_student.Stu_Full_Name LIKE '%$k' OR tbl_student_subject.Sub_ID LIKE '%$k%' OR tbl_subject.Sub_Name LIKE '%$k' 
       ORDER BY StuSub_ID DESC"; 
   }

            //Only year is filled
   else if($k=='' && $y!='' && $cs=='') {
       $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
       FROM ((tbl_student_subject AS tbl_student_subject
       INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
       INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
       WHERE tbl_student_subject.StuSub_Year LIKE '%$y%' ORDER BY StuSub_ID DESC";
   }

            //Keyword and ColumnSelected is filled
   else if ($k!='' && $y=='' && $cs!='') {
    $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
    FROM ((tbl_student_subject AS tbl_student_subject
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
    INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
    WHERE $cs LIKE '%$k%' ORDER BY StuSub_ID DESC";
}

            //Keyword and Year is filled
   else if ($k!='' && $y!='' && $cs=='') {
    $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
    FROM ((tbl_student_subject AS tbl_student_subject
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
    INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
    WHERE tbl_subject.Sub_Name LIKE '%$k%' AND tbl_student_subject.StuSub_Year = '$y' ORDER BY StuSub_ID DESC";
}

            //All three (03) fields filled
else if ($k!='' && $y!='' && $cs!='') {
    $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
    FROM ((tbl_student_subject AS tbl_student_subject
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
    INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
    WHERE $cs LIKE '%$k%' AND tbl_student_subject.StuSub_Year='$y' ORDER BY StuSub_ID DESC";
}

                //All 3 fields blank
else {
    $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
    FROM ((tbl_student_subject AS tbl_student_subject
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
    INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
    ORDER BY StuSub_ID DESC";
}


$DBResult=$this->db->query($query);
return $DBResult->result();
}

public function fetchstudentsubjectid() {
    $query="SELECT StuSub_ID FROM tbl_student_subject ORDER BY StuSub_ID DESC LIMIT 1";
    $new_ID=$this->db->query($query);
    return $new_ID->result();
}

            //For Insert
public function insert($ssid,$ssyear,$stuid,$subid) {
        $result="";
    $query="INSERT INTO tbl_student_subject VALUES ('$ssid','$ssyear','$stuid','$subid')";
    if($this->db->query($query)) {
        $result = "Record added successfully!";
    }
    else {
        $result = "Unable to add the record. Please try again.";
    }
    return $result;
}

public function FetchUpdateData($Details) {
    $k = $Details['keyword'];
    $cs = $Details['ColumnSelected'];
    if(!empty($k) || !empty($cs)) {
        $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
        FROM ((tbl_student_subject AS tbl_student_subject
        INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
        INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
        WHERE $cs LIKE '%$k%' ORDER BY StuSub_ID DESC";
    }

    else {
       $query = "SELECT tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_student_subject.StuSub_Year AS StuSub_Year, tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_student_subject.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_student.Stu_Init_Name AS Stu_Init_Name 
       FROM ((tbl_student_subject AS tbl_student_subject
       INNER JOIN tbl_student AS tbl_student ON ( tbl_student_subject.Stu_ID  = tbl_student.Stu_ID  ))
       INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_student_subject.Sub_ID  ))
       WHERE tbl_student_subject.StuSub_ID = '-1' ORDER BY StuSub_ID DESC LIMIT 1";   

   }
   $DBResult=$this->db->query($query);
   return $DBResult->result();
}


            //For Update
public function update($ssid,$ssyear,$stuid,$subid) {

    $result="";
    $query="UPDATE tbl_student_subject SET StuSub_ID='$ssid',StuSub_Year='$ssyear',Stu_ID='$stuid',Sub_ID='$subid' WHERE StuSub_ID='$ssid';";
    if($this->db->query($query)) {
        $result = "Record updated successfully!";
    }
    else {
        $result = "Unable to update the record. Please try again.";
    }
    return $result;
}

        //To Delete
public function delete($ssid) {
    $result="";
    $query="DELETE FROM tbl_student_subject WHERE StuSub_ID='$ssid'";
    if($this->db->query($query)) {
        $result = "Record updated successfully!";
    }
    else {
        $result = "Unable to update the record. Please try again.";
    }
    return $result;
}

            //Fetch previous record ID
public function fetchpreviousrecordid() {
    $query="SELECT StuSub_ID FROM tbl_student_subject ORDER BY StuSub_ID DESC LIMIT 1";
    $new_ID=$this->db->query($query);
    return $new_ID->result();
}

            //For Insert Page
public function fetchstudentsubjectrecord($id) {
    if($id=='') {
        $query="SELECT * FROM tbl_student WHERE Stu_Index_No = '-1' ";    
    }
    else {
        $query="SELECT * FROM tbl_student WHERE Stu_Index_No = '$id' LIMIT 1";    
    }

    $result = $this->db->query($query);
    return $result->result();
}
}
