        <?php
        class ReportModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }

            public function FetchStudent() {

                $query = "SELECT STU.STU_ID, STU.STU_INDEX_NO, STU.STU_FULL_NAME, EX.MULINT_ID, MUL.MULINT_NAME, AVG(M.MRK_MARK) AS AVERAGE_SCORE
                FROM TBL_MARKS AS M
                INNER JOIN TBL_EXAMINATION AS EX ON EX.EXAM_ID = M.EXAM_ID
                INNER JOIN TBL_STUDENT_SUBJECT AS SS ON M.STUSUB_ID = SS.STUSUB_ID
                INNER JOIN TBL_SUBJECT AS S ON S.SUB_ID = SS.SUB_ID
                INNER JOIN TBL_STUDENT AS STU ON STU.STU_ID = SS.STU_ID
                INNER JOIN TBL_MULINT_CATEGORIES AS MUL ON EX.MULINT_ID = MUL.MULINT_ID
                WHERE STU.STU_ID = 'S0002'
                GROUP BY EX.MULINT_ID
                ORDER BY AVERAGE_SCORE DESC ";


                $DBResult=$this->db->query($query);
                return $DBResult->result();
            }
        }   
    ?>
