<?php
class classesandsubjectsdb extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

// Model functions related to the 'Class' table
    public function fetchclassrecord($id) {
        $query="SELECT * FROM tbl_Class WHERE Cls_ID='$id'";   
        $result = $this->db->query($query);
        return $result->result();
    }

    public function insertclassrecord($cid,$cname,$cgrade,$cthreshold) {
        $result="";
        if($this->db->query("INSERT INTO tbl_class VALUES ('$cid','$cname','$cgrade',$cthreshold)")){
            $result="Class added successfully!";
        }
        else{
            $result="Unable to add the class. Please re-check.";   
        }
        return $result;
    }

    public function updateclassrecord($cid,$cname,$cgrade,$cthreshold) {
        $result="";
        if($this->db->query("UPDATE tbl_class SET Cls_Name='$cname',Grade='$cgrade', Cls_Threshold='$cthreshold' WHERE Cls_ID='$cid';")){
            $result="Class updated successfully!";
        }
        else{
            $result="Unable to update the class. Please re-check.";   
        }
        return $result;
    }

    public function deleteclassrecord($cid) {
        $this->db->query("DELETE FROM tbl_class WHERE Cls_ID='".$cid."'");
    }

    public function fetchclassid() {
        $query="SELECT Cls_ID FROM tbl_class ORDER BY Cls_ID DESC LIMIT 1";
        $new_ID=$this->db->query($query);
        return $new_ID->result();
    }

    public function FetchClassData($Details) {
        $query="";
        if($Details['keyword']=='') {
            $query = "SELECT * FROM tbl_Class ORDER BY Cls_ID";
        }
        else{
            $keyword=$Details['keyword'];
            $query="SELECT * FROM tbl_class WHERE Cls_ID LIKE '%$keyword%' OR Cls_Name LIKE '%$keyword%' ORDER BY Cls_ID";
        }
        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }


// Model Functions Related to the 'Subjects' table
    public function fetchsubjectrecord($id) {
        $query="SELECT * FROM tbl_Subject WHERE Sub_ID='$id'";   
        $result = $this->db->query($query);
        return $result->result();
    }


    public function insertsubjectrecord($subid,$subname) {
        $result="";
        if($this->db->query("INSERT INTO tbl_subject VALUES ('$subid','$subname')")){
            $result="Subject added successfully!";
        }
        else{
            $result="Unable to add the subject. Please re-check.";   
        }
        return $result;
    }

    public function updatesubjectrecord($subid,$subname) {
        $result="";
        if($this->db->query("UPDATE tbl_subject SET Sub_Name='$subname' WHERE Sub_ID='$subid';")){
            $result="Subject updated successfully!";
        }
        else{
            $result="Unable to update the subject. Please re-check.";   
        }
        return $result;
    }

    public function deletesubjectrecord($subid) {
        $this->db->query("DELETE FROM tbl_subject WHERE Sub_ID='".$subid."'");
    }

    public function fetchsubjectid() {
        $query="SELECT Sub_ID FROM tbl_subject ORDER BY Sub_ID DESC LIMIT 1";
        $new_ID=$this->db->query($query);
        return $new_ID->result();
    }


    public function FetchSubjectData($Details) {
        $query="";
        if($Details['keyword']=='') {
            $query = "SELECT * FROM tbl_Subject ORDER BY Sub_ID";
        }
        else{
            $keyword=$Details['keyword'];
            $query="SELECT * FROM tbl_Subject WHERE Sub_ID LIKE '%$keyword%' OR Sub_Name LIKE '%$keyword%' ORDER BY Sub_ID";
        }
        $DBResult=$this->db->query($query);
        return $DBResult->result();
    }


}
?>
