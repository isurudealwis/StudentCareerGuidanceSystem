        <?php
        class BehaviouralActivitiesModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }


            public function FetchData() {
                $query="";
                $column = $_SESSION['column'];
                $keyword = $_SESSION['keyword'];

                if (empty($column) && !empty($keyword)) {
                    $query = "SELECT tbl_behavioural_activities.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_behavioural_activities.BehAct_Desc AS BehAct_Desc, tbl_behavioural_activities.MulInt_ID AS MulInt_ID, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
                    FROM (tbl_behavioural_activities AS tbl_behavioural_activities
                    INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_behavioural_activities.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
                    WHERE (
                    tbl_behavioural_activities.BehAct_ID LIKE '%$keyword%' OR 
                    tbl_behavioural_activities.BehAct_Name LIKE '%$keyword%' OR 
                    tbl_behavioural_activities.BehAct_Desc LIKE '%$keyword%' OR 
                    tbl_behavioural_activities.MulInt_ID LIKE '%$keyword%' OR 
                    tbl_mulint_categories.MulInt_Name LIKE '%$keyword%' )
                    ORDER BY  tbl_behavioural_activities.BehAct_ID";
                }

                else if (!empty($column) && !empty($keyword)) {

                    $query = "SELECT tbl_behavioural_activities.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_behavioural_activities.BehAct_Desc AS BehAct_Desc, tbl_behavioural_activities.MulInt_ID AS MulInt_ID, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
                    FROM (tbl_behavioural_activities AS tbl_behavioural_activities
                    INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_behavioural_activities.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
                    WHERE ($column LIKE '%$keyword%')
                    ORDER BY  tbl_behavioural_activities.BehAct_ID";
                }

                else {
                   $query = "SELECT tbl_behavioural_activities.BehAct_ID AS BehAct_ID, tbl_behavioural_activities.BehAct_Name AS BehAct_Name, tbl_behavioural_activities.BehAct_Desc AS BehAct_Desc, tbl_behavioural_activities.MulInt_ID AS MulInt_ID, tbl_mulint_categories.MulInt_Name AS MulInt_Name 
                   FROM (tbl_behavioural_activities AS tbl_behavioural_activities
                   INNER JOIN tbl_mulint_categories AS tbl_mulint_categories ON ( tbl_behavioural_activities.MulInt_ID  = tbl_mulint_categories.MulInt_ID  ))
                   ORDER BY  tbl_behavioural_activities.BehAct_ID";
               }

               $DBResult=$this->db->query($query);
               return $DBResult->result();
           }


           public function newid() {
            $query = "SELECT BehAct_ID FROM tbl_behavioural_activities ORDER BY BehAct_ID DESC LIMIT 1";
            $result=$this->db->query($query);
            if($result->num_rows()==0) {
                return 'BEH001';
            }
            else {
                foreach($result->result() as $r) {
                    $id=substr($r->BehAct_ID,3);
                    $newvalue=$id+1;
                    $newid='BEH'.str_pad($newvalue,3,"0",STR_PAD_LEFT);
                    return $newid;
                }

            }
        }

        public function insert($id, $name, $desc, $mulint) {
            $result="";
            $query="INSERT INTO tbl_behavioural_activities VALUES ('$id', '$name', '$desc', '$mulint')";
            if($this->db->query($query)){
                $result="Record added Successfully!";
            }
            else{
                $result="Unable to add record. Please Re-check the details.";
            }
            return $result;
        }


        public function getrecord($id) {
            $query = "SELECT * FROM tbl_behavioural_activities WHERE BehAct_ID = '$id'";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function getmulintlist() {
            $query = "SELECT MulInt_ID, MulInt_Name FROM tbl_mulint_categories";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function update($id, $name, $desc, $mulint) {
            $result="";
            $query="UPDATE tbl_behavioural_activities SET BehAct_Name='$name', BehAct_Desc='$desc', MulInt_ID='$mulint' WHERE BehAct_ID='$id'";
            if($this->db->query($query)){
                $result="Record updated Successfully!";
            }
            else{
                $result="Unable to update the record. Please Re-check the details.";
            }
            return $result;
        }

        public function delete($id) {
            $result="";
            $query="DELETE FROM tbl_behavioural_activities WHERE BehAct_ID='$id'";
            if($this->db->query($query)){
                $result="Record deleted Successfully!";
            }
            else{
                $result="Unable to delete record. Please Re-check the details.";
            }
            return $result;
        }


    }
