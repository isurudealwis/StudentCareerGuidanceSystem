        <?php
        class MarksModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }

            //Load Data to the dropdownlists
            public function GetDropDownFields($field) {

                //Get Subject List
                if ($field=='subjectlist') {
                   $DBResult=$this->db->query("SELECT DISTINCT Sub_ID, Sub_Name FROM tbl_subject");
               }

               //Get Year List
               else if ($field=='yearlist') {
                $DBResult=$this->db->query("SELECT DISTINCT Exam_Year FROM tbl_examination ORDER BY Exam_Year");
            }

              //Get Term List
            else if ($field=='termlist') {
                $DBResult=$this->db->query("SELECT DISTINCT Exam_Term FROM tbl_examination ORDER BY Exam_Term");
            }

            //Get Class List
            else if ($field=='classlist') {
                $DBResult=$this->db->query("SELECT DISTINCT Cls_ID, Cls_Name FROM tbl_class ORDER BY Cls_ID");
            }            

            return $DBResult->result();
        }

        //To load Table data in the 'marksdetails' page
        //This will load the Student_ID, Student Admission No and the Student Full Name to the table
        public function getstudents($data) {
            $y=$data['YearSelected'];
            $t=$data['TermSelected'];
            $s=$data['SubjectSelected'];
            $c=$data['ClassSelected'];

            $query="SELECT tbl_student_subject.Stu_ID AS Stu_ID, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student.Stu_Full_Name AS Stu_Full_Name, tbl_examination.Exam_Year AS Exam_Year, tbl_examination.Exam_Term AS Exam_Term, tbl_class.Cls_Name AS Cls_Name, tbl_subject.Sub_Name AS Sub_Name, tbl_student_subject.StuSub_ID AS StuSub_ID, tbl_examination.Exam_ID AS Exam_ID, m.Mrk_Mark AS Mrk_Mark, m.Mrk_ID AS Mrk_ID
            FROM tbl_student_subject AS tbl_student_subject
            INNER JOIN tbl_student AS tbl_student ON ( tbl_student.Stu_ID  = tbl_student_subject.Stu_ID )
            INNER JOIN tbl_examination AS tbl_examination ON ( tbl_examination.Sub_ID  = tbl_student_subject.Sub_ID AND tbl_examination.Exam_Year = tbl_student_subject.StuSub_Year )
            INNER JOIN tbl_student_class AS tbl_student_class ON ( tbl_student_class.Stu_ID  = tbl_student_subject.Stu_ID  )
            INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID AND tbl_examination.Exam_Year = tbl_student_class.StuCls_Year  )
            INNER JOIN tbl_subject AS tbl_subject ON ( tbl_student_subject.Sub_ID  = tbl_subject.Sub_ID  )
            LEFT JOIN tbl_marks AS M on (m.Exam_ID = tbl_examination.Exam_ID AND m.StuSub_ID = tbl_student_subject.StuSub_ID)
            WHERE(
            tbl_examination.Exam_Year = '$y' AND 
            tbl_examination.Exam_Term = '$t' AND 
            tbl_class.Cls_ID = '$c' AND 
            tbl_examination.Sub_ID = '$s' )";

            $result = $this->db->query($query);
            return $result->result();
        }

        //Get Marks
        public function getmarks() {
            $query="SELECT * FROM tbl_marks";
            $result = $this->db->query($query);
            return $result->result();
        }

        //Fetch Marks ID to see whether the mark is already available
        public function fetchmarksid($StuSub_ID, $Exam_ID) {
            $query="SELECT Mrk_ID FROM tbl_marks WHERE StuSub_ID = '$StuSub_ID' AND Exam_ID = '$Exam_ID'";
            $result = $this->db->query($query);
            if($result->num_rows()>0) {
                return true;
            }
            else {
                return false;
            }
        }

        //Update Marks Table
        public function updatemarks($Exam_ID, $StuSub_ID, $Mrk_Mark, $Tea_ID, $Mrk_ID) {

            $TID=$Tea_ID;
            $query = "UPDATE tbl_marks SET Exam_ID='$Exam_ID', StuSub_ID='$StuSub_ID', Mrk_Mark='$Mrk_Mark', Tea_ID='$TID', Mrk_DateTime=now() WHERE Mrk_ID='$Mrk_ID';";
            if($this->db->query($query)){
                return true;    
            }
            else {
                return false;
            }
            
        }

        public function insertmarks($Exam_ID, $StuSub_ID, $Mrk_Mark, $Tea_ID) {
            $EID = $Exam_ID;
            $SSID = $StuSub_ID;
            $MM = $Mrk_Mark;
            $TID = $Tea_ID;
            $markid = '';
            $curid='';


            //Check whether the marks table is empty
            $query = "SELECT Mrk_ID FROM tbl_marks ORDER BY Mrk_ID DESC LIMIT 1";
            $result = $this->db->query($query);
            if(empty($result)) {
                $markid = 'M00001';
            }
            else {
                foreach($result->result_array() as $r) {
                    $curid = $r['Mrk_ID'];    
                }
                
                $newvalue=substr($curid,3)+1;
                $markid='MRK'.str_pad($newvalue,7,"0",STR_PAD_LEFT);
            }

                $query = "INSERT INTO tbl_marks VALUES ('$markid','$EID','$SSID','$MM','$TID',now())";
                $result = $this->db->query($query);
                $query2 = "SELECT * FROM tbl_marks WHERE Mrk_ID='$markid'";
                $result = $this->db->query($query2);
                if ($result->num_rows()>0) {
                    return true;
                }
                else {
                    return false;
                }
        }

        // public function deletemark($data) {
        //     $markid = $data['markid'];
        //     $query = "DELETE FROM tbl_marks WHERE Mrk_ID='".$markid."'";
        //     $result = $this->db->query($query);
        // }

    }
?>