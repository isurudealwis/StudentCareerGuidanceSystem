<?php
class StudentClassModel extends CI_Model {
    public function __construct() {
        parent::__construct();
    }


    public function GetDropDownFields($field) {
        if ($field=='classlist') {
         $DBResult=$this->db->query("SELECT DISTINCT Cls_ID, Cls_Name FROM tbl_class");
     }

     else if ($field=='yearlist') {
        $DBResult=$this->db->query("SELECT DISTINCT tbl_student_class.StuCls_Year AS StuCls_Year FROM tbl_student_class ORDER BY StuCls_Year");
    }
    else if ($field == 'studentlist') {
        $DBResult=$this->db->query("SELECT DISTINCT tbl_student.Stu_Index_No AS Stu_Index_No FROM tbl_student ORDER BY Stu_Index_No");
    }

    return $DBResult->result();
}


//Fetch Student-Class Data
public function FetchStudentClassData($Details) {
    $query="";

    $k = $Details['keyword'];
    $y = $Details['year'];
    $cs = $Details['ColumnSelected'];

    //Only Keyword is filled
    if($k!='' && $y=='' && $cs=='') {
       $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
       FROM ((tbl_student_class AS tbl_student_class
       INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
       INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
       WHERE tbl_student_class.StuCls_ID LIKE '%$k%' OR tbl_student_class.StuCls_Year LIKE '%$k%' OR tbl_student_class.Stu_ID LIKE '%$k%' OR tbl_student.Stu_Init_Name LIKE '%$k%' OR tbl_student.Stu_Index_No LIKE '%$k%' OR tbl_student_class.Cls_ID LIKE '%$k%' OR tbl_class.Cls_Name LIKE '%$k%' ORDER BY StuCls_ID DESC"; 
   }

    //Only year is filled
   else if($k=='' && $y!='' && $cs=='') {
       $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
       FROM ((tbl_student_class AS tbl_student_class
       INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
       INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
       WHERE tbl_student_class.StuCls_Year LIKE '%$y%' ORDER BY StuCls_ID DESC";
   }

    //Keyword and ColumnSelected is filled
   else if ($k!='' && $y=='' && $cs!='') {
    $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
    FROM ((tbl_student_class AS tbl_student_class
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
    INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
    WHERE $cs LIKE '%$k%' ORDER BY StuCls_ID DESC";
}

    //Keyword and Year is filled
else if ($k!='' && $y!=='' && $cs=='') {
    $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
    FROM ((tbl_student_class AS tbl_student_class
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
    INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
    WHERE tbl_class.Cls_Name LIKE '%$k%' AND tbl_student_class.StuCls_Year = '$y' ORDER BY StuCls_ID DESC";
}

    //All three (03) fields filled
else if ($k!='' && $y!='' && $cs!='') {
    $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
    FROM ((tbl_student_class AS tbl_student_class
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
    INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
    WHERE $cs LIKE '%$k%' AND tbl_student_class.StuCls_Year='$y' ORDER BY StuCls_ID DESC";
}

        //All 3 fields blank
else {
    $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
    FROM ((tbl_student_class AS tbl_student_class
    INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
    INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  )) ORDER BY StuCls_ID DESC";
}

$DBResult=$this->db->query($query);
return $DBResult->result();
}


public function fetchstudentclassid() {
    $query="SELECT StuCls_ID FROM tbl_student_class ORDER BY StuCls_ID DESC LIMIT 1";
    $new_ID=$this->db->query($query);
    return $new_ID->result();
}

    //Fetch previous record ID
public function fetchpreviousrecordid() {
    $query="SELECT StuCls_ID FROM tbl_student_class ORDER BY stuCls_ID DESC LIMIT 1";
    $new_ID=$this->db->query($query);
    return $new_ID->result();
}

    //For Insert Page
public function fetchstudentclassrecord($id) {
    if($id=='') {
        $query="SELECT * FROM tbl_student WHERE Stu_Index_No = '-1' ";    
    }
    else {
        $query="SELECT * FROM tbl_student WHERE Stu_Index_No = '$id' LIMIT 1";    
    }

    $result = $this->db->query($query);
    return $result->result();
}

    //For Insert
public function insert($scid,$scyear,$sid,$cid) {
    $result="";
    $query="INSERT INTO tbl_student_class VALUES ('$scid',$scyear,'$sid','$cid');";
    if($this->db->query($query)) {
        $result = "Record added successfully!";
    }
    else {
        $result = "Unable to add the record. Please try again.";
    }
    return $result;
}

    //For Update
public function update($scid,$scyear,$sid,$cid) {
    $result="";
    $query="UPDATE tbl_student_class SET StuCls_ID='$scid',StuCls_Year='$scyear',Stu_ID='$sid',Cls_ID='$cid' WHERE StuCls_ID='$scid';";
    if($this->db->query($query)) {
        $result = "Record updated successfully!";
    }
    else {
        $result = "Unable to update the record. Please try again.";
    }
    return $result;
}

    //To Delete
public function delete($scid) {
    $result="";
    $query="DELETE FROM tbl_student_class WHERE StuCls_ID='$scid'";
    if($this->db->query($query)) {
        $result = "Record updated successfully!";
    }
    else {
        $result = "Unable to update the record. Please try again.";
    }
    return $result;
}

public function fetchstudentdata($indexno) {
    $query="SELECT * FROM tbl_student WHERE Stu_Index_No='".$indexno."'";
    $result=$this->db->query($query);
    return $result->result();
}

public function FetchUpdateData($Details) {
    $k = $Details['keyword'];
    $cs = $Details['ColumnSelected'];
    if(!empty($k) || !empty($cs)) {
        $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
        FROM ((tbl_student_class AS tbl_student_class
        INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
        INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
        WHERE $cs LIKE '%$k%' ORDER BY StuCls_ID DESC LIMIT 1";
    }
    else {
       $query = "SELECT tbl_student_class.StuCls_ID AS StuCls_ID, tbl_student_class.StuCls_Year AS StuCls_Year, tbl_student_class.Stu_ID AS Stu_ID, tbl_student.Stu_Init_Name AS Stu_Init_Name, tbl_student.Stu_Index_No AS Stu_Index_No, tbl_student_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name, tbl_student.Stu_Full_Name AS Stu_Full_Name 
       FROM ((tbl_student_class AS tbl_student_class
       INNER JOIN tbl_student AS tbl_student ON ( tbl_student_class.Stu_ID  = tbl_student.Stu_ID))
       INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_student_class.Cls_ID  ))
       WHERE tbl_student_class.StuCls_ID = '-1' ORDER BY StuCls_ID DESC LIMIT 1";   

   }
   $DBResult=$this->db->query($query);
   return $DBResult->result();
}

    public function fetchclassthrehold($cls_id) {
        $query="SELECT Cls_Threshold FROM tbl_class WHERE cls_id='$cls_id';";
        $result=$this->db->query($query);
        return $result->result();
    }

    public function studentcount($cls_id,$year) {
        $query = "SELECT COUNT(Stu_ID) AS COUNT from tbl_student_class WHERE Cls_ID='$cls_id' AND StuCls_Year='$year';";
        $result=$this->db->query($query);
        return $result->result();
    }





}
?>
