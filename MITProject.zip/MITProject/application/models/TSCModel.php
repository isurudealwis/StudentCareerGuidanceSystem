        <?php
        class TSCModel extends CI_Model {
            public function __construct() {
                parent::__construct();
            }

            public function FetchData() {
                $query="";

                $column = $_SESSION['column'];
                $keyword = $_SESSION['keyword'];

                if (empty($column) && !empty($keyword)) {
                    $query = "SELECT tbl_teacher_subject_class.TeaSub_ID AS TeaSub_ID, tbl_teacher_subject_class.TeaSub_Year AS TeaSub_Year, tbl_teacher_subject_class.Tea_ID AS Tea_ID, tbl_teacher.Tea_First_Name AS Tea_First_Name, tbl_teacher.Tea_Last_Name AS Tea_Last_Name, tbl_teacher_subject_class.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name FROM (((tbl_teacher_subject_class AS tbl_teacher_subject_class
                    INNER JOIN tbl_teacher AS tbl_teacher ON ( tbl_teacher.Tea_ID  = tbl_teacher_subject_class.Tea_ID  ))
                    INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_teacher_subject_class.Sub_ID  ))
                    INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_teacher_subject_class.Cls_ID  ))
                    WHERE(
                    tbl_teacher_subject_class.TeaSub_ID LIKE '%$keyword%' OR 
                    tbl_teacher_subject_class.TeaSub_Year LIKE '%$keyword%' OR 
                    tbl_teacher_subject_class.Tea_ID LIKE '%$keyword%' OR 
                    tbl_teacher.Tea_First_Name LIKE '%$keyword%' OR 
                    tbl_teacher.Tea_Last_Name LIKE '%$keyword%' OR 
                    tbl_subject.Sub_Name LIKE '%$keyword%' OR 
                    tbl_class.Cls_Name LIKE '%$keyword%' )
                    ORDER BY  tbl_teacher_subject_class.TeaSub_ID";
                }

                else if (!empty($column) && !empty($keyword)) {
                    $query = "SELECT tbl_teacher_subject_class.TeaSub_ID AS TeaSub_ID, tbl_teacher_subject_class.TeaSub_Year AS TeaSub_Year, tbl_teacher_subject_class.Tea_ID AS Tea_ID, tbl_teacher.Tea_First_Name AS Tea_First_Name, tbl_teacher.Tea_Last_Name AS Tea_Last_Name, tbl_teacher_subject_class.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name FROM (((tbl_teacher_subject_class AS tbl_teacher_subject_class
                    INNER JOIN tbl_teacher AS tbl_teacher ON ( tbl_teacher.Tea_ID  = tbl_teacher_subject_class.Tea_ID  ))
                    INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_teacher_subject_class.Sub_ID  ))
                    INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_teacher_subject_class.Cls_ID  ))
                    WHERE(
                    $column LIKE '%$keyword%')
                    ORDER BY  tbl_teacher_subject_class.TeaSub_ID";
                }

                else {
                   $query = "SELECT tbl_teacher_subject_class.TeaSub_ID AS TeaSub_ID, tbl_teacher_subject_class.TeaSub_Year AS TeaSub_Year, tbl_teacher_subject_class.Tea_ID AS Tea_ID, tbl_teacher.Tea_First_Name AS Tea_First_Name, tbl_teacher.Tea_Last_Name AS Tea_Last_Name, tbl_teacher_subject_class.Sub_ID AS Sub_ID, tbl_subject.Sub_Name AS Sub_Name, tbl_class.Cls_ID AS Cls_ID, tbl_class.Cls_Name AS Cls_Name FROM (((tbl_teacher_subject_class AS tbl_teacher_subject_class
                   INNER JOIN tbl_teacher AS tbl_teacher ON ( tbl_teacher.Tea_ID  = tbl_teacher_subject_class.Tea_ID  ))
                   INNER JOIN tbl_subject AS tbl_subject ON ( tbl_subject.Sub_ID  = tbl_teacher_subject_class.Sub_ID  ))
                   INNER JOIN tbl_class AS tbl_class ON ( tbl_class.Cls_ID  = tbl_teacher_subject_class.Cls_ID  ))
                   ORDER BY  tbl_teacher_subject_class.TeaSub_ID";
               }

               $DBResult=$this->db->query($query);
               return $DBResult->result();
           }

           public function getsubjectlist() {
            $query = "SELECT * FROM tbl_subject";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function getclasslist() {
            $query = "SELECT * FROM tbl_class";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function getteacherlist() {
            $query = "SELECT * FROM tbl_teacher ORDER BY Tea_ID";
            $result = $this->db->query($query);
            return $result->result();
        }  

        public function newid() {
            $query = "SELECT TeaSub_ID FROM tbl_teacher_subject_class ORDER BY TeaSub_ID DESC LIMIT 1";
            $result=$this->db->query($query);
            if($result->num_rows()==0) {
                return 'TS0001';
            }
            else {
                foreach($result->result() as $r) {
                    $id=substr($r->TeaSub_ID,2);
                    $newvalue=$id+1;
                    $newid='TS'.str_pad($newvalue,4,"0",STR_PAD_LEFT);
                    return $newid;
                }

            }
        }

        public function insert($id, $year, $teaid, $subid, $clsid) {
            $result="";
            $query="INSERT INTO tbl_teacher_subject_class VALUES ('$id', '$year', '$teaid', '$subid', '$clsid')";
            if($this->db->query($query)){
                $result='Record added Successfully!';
            }
            else {
                $result = 'Unable to add the record. Please Re-Check.';
            }
            return $result;
        }



        public function getrecord($id) {
            $query = "SELECT * FROM tbl_teacher_subject_class WHERE TeaSub_ID = '$id'";
            $result = $this->db->query($query);
            return $result->result();
        }

        public function update($id, $year, $teaid, $subid, $clsid) {
            $result="";
            $query="UPDATE tbl_teacher_subject_class SET TeaSub_Year='$year', Tea_ID='$teaid', Sub_ID='$subid', Cls_ID='$clsid' WHERE TeaSub_ID='$id'";
            if($this->db->query($query)){
                $result="Record Added Successfully!";
            }
            else {
                $result="Unable to update the record. Please Re-Check.";
            }
            return $result;
        }

        public function delete($id) {
            $result="";
            $query="DELETE FROM tbl_teacher_subject_class WHERE TeaSub_ID='$id'";
            
            if($this->db->query($query)) {
                $result='Record Deleted Successfully!';
            }
            else {
                $result='Unable to Delete the record.';
            }
            return $result;
        }

    }
